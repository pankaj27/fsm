<script>
  $(document).ready(function(){

      $("#submit").click(function(event){
      var fn_regx = /^[-a-zA-Z\s]+$/;
      var phn_regx= /^[0-9]+$/;
      //var date_regx=/^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$;
      var uname_regx= /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
      var error_code=0;
      /*---------------------------------------------------------------------
      --                FISRST NAME VALIDATION
      --
      ---------------------------------------------------------------------*/
      var fn=$("#fn").val();
      if(fn==null || fn==""){
          $("#fn").closest("div").parent().addClass("has-error");
          $("#error_firstname").text("Please Enter First Name.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fn").text("");
          if (!fn.match(fn_regx) ) {
              $("#fn").closest("div").parent().addClass("has-error");
              $('#error_firstname').html(" Please Enter Valid <b>First</b> Name  Ex - Abhijit ");
              error_code++;
            //return false;
          }
          else{
            $("#fn").closest("div").parent().removeClass("has-error");

            $("#error_firstname").text("");
          }


        }


      /*---------------------------------------------------------------------
      --                LAST NAME VALIDATION
      --
      ---------------------------------------------------------------------*/
        var ln=$("#ln").val();
      if(ln==null || ln==""){
          $("#ln").closest("div").parent().addClass("has-error");
          $("#error_lastname").text("Please Enter Last Name.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           if (!ln.match(fn_regx) ) {
              $("#ln").closest("div").parent().addClass("has-error");
              $('#error_ln').html(" Please Enter Valid <b>Last Name</b> Ex - Sanyal ");
            //return false;
            error_code++;
          }
          else{
             $("#ln").closest("div").parent().removeClass("has-error");

            $("#error_ln").text("");
          }
        }
        
        /*---------------------------------------------------------------------
      --                datepicker VALIDATION
      --
      ---------------------------------------------------------------------*/
        var ln=$("#ln").val();
      if(ln==null || ln==""){
          $("#datepicker").closest("div").parent().addClass("has-error");
          $("#error_dob").text("Please Enter DOB.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#datepicker").closest("div").parent().removeClass("has-error");

            $("#error_dob").text("");
          
        }
		 

      /*---------------------------------------------------------------------
      --                PHONE NO VALIDATION
      --
      ---------------------------------------------------------------------*/
        var phn=$("#mobile").val();
      if(phn==null || phn==""){
          $("#mobile").closest("div").parent().addClass("has-error");
          $("#error_mobile").text("Please Enter Phone No.");
           error_code++;
          //return false;
        }
        else{
          //$("#error_phn").text("");
           if (!phn.match(phn_regx)) {
              $("#mobile").closest("div").parent().addClass("has-error");
              $('#error_mobile').html(" Please Enter valid <b>Phone No.</b> Ex - 9800XXXXXX ");
               error_code++;
            //return false;
          }
          else{
             //alert(phn.length);
             //$("#phn").closest("div").parent().removeClass("has-error");
           // $("#error_phn").text("");
              if (phn.length<10) {
                  $("#mobile").closest("div").parent().addClass("has-error");
                  $('#error_mobile').html(" Please Enter valid <b>Phone No(10 digit).</b> Ex - 9800XXXXXX ");
                   error_code++;
                //return false;
              }
              else{
                 //alert(phn.length);
                 $("#mobile").closest("div").parent().removeClass("has-error");
                $("#error_mobile").text("");
              }
          }
        }

      /*---------------------------------------------------------------------
      --                Address VALIDATION
      --
      ---------------------------------------------------------------------*/
        var address=$("#address").val();
      if(address==null || address==""){
          $("#address").closest("div").parent().addClass("has-error");
          $("#error_address").text("Please Enter Address.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#address").closest("div").parent().removeClass("has-error");

            $("#error_address").text("");
          
        }
	 /*---------------------------------------------------------------------
      --                Account type  VALIDATION
      --
      ---------------------------------------------------------------------*/
        var acctype=$("#acctype").val();
      if(acctype==null || acctype==""){
          $("#acctype").closest("div").parent().addClass("has-error");
          $("#error_acctype").text("Please Select Account type");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#acctype").closest("div").parent().removeClass("has-error");

            $("#error_acctype").text("");
          
        }
        
        /*---------------------------------------------------------------------
      --                Account No  VALIDATION
      --
      ---------------------------------------------------------------------*/
        var accno=$("#accno").val();
      if(accno==null || accno==""){
          $("#accno").closest("div").parent().addClass("has-error");
          $("#error_accno").text("Please Enter Account No.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#accno").closest("div").parent().removeClass("has-error");

            $("#error_accno").text("");
          
        }
        
        
      /*---------------------------------------------------------------------
      --                Opening Balance validations
      --error_opbalance
      ---------------------------------------------------------------------*/
        var opbalance=$("#opbalance").val();
        var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      if(opbalance==null || opbalance==""){
          $("#opbalance").closest("div").parent().addClass("has-error");
          $("#error_opbalance").text("Please Enter Opening Balance.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!opbalance.match(currency_regx) ) {
              $("#opbalance").closest("div").parent().addClass("has-error");
              $('#error_opbalance').html(" Please Enter valid <b>Opening Balance</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#opbalance").closest("div").parent().removeClass("has-error");
            $("#error_opbalance").text("");
          }
        }
        
        /*---------------------------------------------------------------------
      --                Monthly installment validations
      --error_opbalance
      ---------------------------------------------------------------------*/
        var mi=$("#mi").val();
        //var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      if(mi==null || mi==""){
          $("#mi").closest("div").parent().addClass("has-error");
          $("#error_mi").text("Please Enter Monthly Installment.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!mi.match(currency_regx) ) {
              $("#mi").closest("div").parent().addClass("has-error");
              $('#error_mi').html(" Please Enter valid <b>Monthly Installment</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#mi").closest("div").parent().removeClass("has-error");
            $("#error_mi").text("");
          }
        }

       /*---------------------------------------------------------------------
      --                Interest rate validations
      --error_opbalance
      ---------------------------------------------------------------------*/
        var interest=$("#interest").val();
        //var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      if(interest==null || interest==""){
          $("#interest").closest("div").parent().addClass("has-error");
          $("#error_interest").text("Please Enter Interest Rate.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!interest.match(currency_regx) ) {
              $("#interest").closest("div").parent().addClass("has-error");
              $('#error_interest').html(" Please Enter valid <b>Interest Rate</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#interest").closest("div").parent().removeClass("has-error");
            $("#error_interest").text("");
          }
        }

      
     
      /*---------------------------------------------------------------------
      --                PINCODE VALIDATION
      --
      ---------------------------------------------------------------------*/
       var pin=$("#pin").val();
      if(pin==null || pin==""){
          $("#pincode").closest("div").parent().addClass("has-error");
          $("#error_pincode").text("Please Enter Pincode.");
           error_code++;
         // return false;
        }
        else{
          //$("#error_pin").text("");
           if (!pin.match(phn_regx)) {
              $("#pincode").closest("div").parent().addClass("has-error");
              $('#error_pincode').html(" Please Enter Valid <b>PINCODE</b> Ex:-721648 ");
               error_code++;
           // return false;
          }
          else{
             //alert(phn.length);
            // $("#pin").closest("div").parent().removeClass("has-error");
            //$("#error_pin").text("");
            if (pin.length<7 ) {
                $("#pincode").closest("div").parent().addClass("has-error");
                $('#error_pincode').html(" Please Enter 7 digit <b>PINCODE</b>");
                 error_code++;
              //return false;
            }
            else{
              $("#pincode").closest("div").parent().removeClass("has-error");
              $("#error_pincode").text("");
            }

          }
        }
  
        if(error_code>0){

          return false;

        }else{
          return true;

        }





      });
	  $("#state").change(function(){
		  
		  var state=$("#state").val();
		  $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>manage_accounts/NewAccounts/get_district",
  			data :{'state':state},
  			success : function(data){
  				//console.log(data);
				$("#district").html(data);
  			  
              }  
           });
		  
	  });
      function readURL(input) {

      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function(e) {
          $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
      }
    }

    $("#image").change(function() {
      readURL(this);
    });
    })
</script>