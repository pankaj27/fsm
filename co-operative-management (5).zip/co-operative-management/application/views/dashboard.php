<?php $this->load->view('header-style.php'); ?>
<style>
  	.se-pre-con {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('<?php echo base_url(); ?>assets/image/loading.gif') center no-repeat #fff;
}
  </style>
<script src="<?php echo base_url(); ?>assets/dist/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dist/js/modernizr.js"></script>
<script>
//paste this code under the head tag or in a separate js file.
	// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");;
	});
	</script>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="se-pre-con"></div>
<div class="wrapper">

  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
     	<div class="row">
     		<center><h1>WELCOME TO FINANCIAL MANAGEMENT SYSTEM</h1></center>
     		
     	</div>
     	
     </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php $this->load->view('footer-script.php');  ?>
