<?php $this->load->view('insurence/ins_style.php'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Pay Insurence
      </h1>
       
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Transaction</a></li>
        <li><a href="#">Pay Insurence</a></li>
        <li class="active">Add</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-6">
          <!-- Horizontal Form -->
          <div class="box box-danger">
            
           <?php $query3=$this->db->query("select * from account_master where status='1'"); ?>
			<?php  $res3=$query3->result(); ?>
            <div class="box-header with-border">
              <h3 class="box-title">Insurance  Information</h3>
            </div>
            <form action="<?php echo base_url(); ?>manage_accounts/NewAccounts/save_loan_apply"  method="post" enctype="multipart/form-data">
            
             <div class="form-horizontal">
              <div class="box-body">
                <?php $query4=$this->db->query("select * from customer_master where status='1'"); ?>
			    <?php  $res4=$query4->result(); ?>
                
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Account No <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <select id="accno" class="form-control select2" style="width: 100%;" name="accno"  >
                    	 <option  value="">Select Any Accno</option>
		                  <?php if(isset($res4) && !empty($res4)){ ?>
		                  	          
							<?php foreach($res4 as $val4){ ?>
							    
								      <option  value="<?php echo $val4->accno; ?>" ><?php echo $val4->accno ; ?></option>
							    
		                  
							<?php } } ?> 
		                </select><span class="help-block" id="error_accno"></span>
                  </div>
                </div>
                
	          <!--<div class="form-group">
                  <label for="Opening Balance" class="col-sm-3 control-label">Loan Amount <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="loanamount" placeholder="Loan Amount " name="loanamount" value="<?php if(isset($loanaccountinfo[0]->loan_amount) && !empty($loanaccountinfo[0]->loan_amount)){ echo $loanaccountinfo[0]->loan_amount ;} ?>">
                    <span class="help-block" id="error_loanamount"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="opdate" class="col-sm-3 control-label">Loan Date <span class="text-red">*</span></label>

                  <div class="col-sm-9">
	                    <div class="input-group date">
	                  <div class="input-group-addon">
	                    <i class="fa fa-calendar"></i>
	                  </div>
	                  <input type="text" class="form-control pull-right" id="datepicker3" name="loandate" readonly="readonly" value="<?php if(isset($loanaccountinfo[0]->loan_date) && !empty($loanaccountinfo[0]->loan_date)){ echo $loanaccountinfo[0]->loan_date ;} ?>" >
	                  
	                </div>
	                <span class="help-block" id="error_loandate"></span>
                  </div>
                </div>
                
                <?php $query5=$this->db->query("select * from trem_master where status='1'"); ?>
			    <?php  $res5=$query5->result(); ?>
                <div class="form-group">
	                <label for="Account type" class="col-sm-3 control-label">Loan Term <span class="text-red">*</span></label>
	                <div class="col-sm-9">
		                <select id="loanterm" class="form-control select2" style="width: 100%;" name="loanterm" >
		                  <?php if(isset($res5) && !empty($res5)){ ?>
		                  	          <option  value="">Select Any Term</option>
							<?php foreach($res5 as $val5){ ?>
							    
								      <option  value="<?php echo $val5->term; ?>" <?php if(isset($loanaccountinfo[0]->period) && !empty($loanaccountinfo[0]->period)){ if($loanaccountinfo[0]->period==$val5->term){echo "Selected"; } } ?>><?php echo $val5->term." ".$val5->termunit ; ?></option>
							    
		                  
							<?php } } ?> 
		                </select>
		                <span class="help-block" id="error_loanterm"></span>
		               </div>
                </div>
                
                 <?php $query6=$this->db->query("select * from interest_calculate where status='1'"); ?>
			    <?php  $res6=$query6->result(); ?>
                <div class="form-group">
	                <label for="Account type" class="col-sm-3 control-label">Interest Calculate? </label>
	                <div class="col-sm-9">
		                <select id="interestcalculation" class="form-control select2" style="width: 100%;" name="interest_calculate" >
		                  <?php if(isset($res6) && !empty($res6)){ ?>
		                  	          
							<?php foreach($res6 as $val6){ ?>
							    
								      <option  value="<?php echo $val6->name; ?>" <?php if(isset($loanaccountinfo[0]->interest_calculate) && !empty($loanaccountinfo[0]->interest_calculate)){ if($loanaccountinfo[0]->interest_calculate==$val6->name){echo "Selected"; } } ?>><?php echo $val6->name ; ?></option>
							    
		                  
							<?php } } ?> 
		                </select>
		                <span class="help-block" id="error_interest_calculation"></span>
		               </div>
                </div>
                
                
                
                <div class="form-group">
                  <label for="Interest Rate" class="col-sm-3 control-label">Interest Rate(%) <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" name="loaninterest" class="form-control" id="loaninterest" placeholder="Loan Interest Rate(%) " value="<?php if(isset($loanaccountinfo[0]->interest_rate) && !empty($loanaccountinfo[0]->interest_rate)){ echo $loanaccountinfo[0]->interest_rate ; } ?>" >
                    <span class="help-block" id="error_loaninterest"></span>
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="Monthly Installment" class="col-sm-3 control-label">Monthly Interest <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="miloan" id="miloan" placeholder="Monthly Installment " value="<?php if(isset($loanaccountinfo[0]->monthly_installment) && !empty($loanaccountinfo[0]->monthly_installment)){ echo $loanaccountinfo[0]->monthly_installment ; } ?>"  >
                    <span class="help-block" id="error_miloan"></span>
                  </div>
                </div>
                
                <div class="form-group" id="insrate_new">
                  <label for="Insurance Rate" class="col-sm-3 control-label">Insurance Rate(%) </label>

                  <div class="col-sm-9">
                    <input type="number" min="1"  step=any class="form-control" name="insrate" id="insrate" placeholder="Insurance Rate" value="<?php if(isset($insurance_master[0]->insurance_rate)){ echo $insurance_master[0]->insurance_rate; }else{ echo 1; } ?>"  >
                    <span class="help-block" id="error_insrate"></span>
                  </div>
                </div>
                <div class="form-group" id="insamount_new">
                  <label for="Insurance Rate" class="col-sm-3 control-label">Insurance Amount <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="insamount" id="insamount" placeholder="Insurance Amount" value="<?php  if(isset($insurance_master[0]->insurance_amount)){ echo $insurance_master[0]->insurance_amount; } ?>" readonly >
                    <span class="help-block" id="error_insamount"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Insurance Rate" class="col-sm-3 control-label">Adjustment Date </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="adjust" id="adjust" placeholder="Adjustment date" value="<?php  if(isset($loanaccountinfo[0]->loan_adjust_date)){ echo $loanaccountinfo[0]->loan_adjust_date; } ?>" readonly >
                    <span class="help-block" id="error_adjust"></span>
                  </div>
                </div>-->
                
                
              </div>
              
              
              <!-- /.box-body -->
              <!--<div class="box-footer">
                <button type="reset" class="btn btn-default">Cancel</button>
                <button type="submit" id="submit" class="btn btn-info pull-right"> Submit</button>
              </div>-->
             </div>
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
          
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
        <div class="col-md-6" id="mesage">
        	
        </div>
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php //$this->load->view('newaccounts/newaccounts-script.php');  ?>
<?php $this->load->view('insurence/ins_script.php');  ?>
<script>
  $(document).ready(function(){
	
	 
      $("#submit").click(function(event){
      	//alert('hello');return false;
      	var error_code=0;
        /*---------------------------------------------------------------------
      --                Account No  VALIDATION
      --
      ---------------------------------------------------------------------*/
        var accno=$("#accno").val();
      if(accno==null || accno==""){
          $("#accno").closest("div").parent().addClass("has-error");
          $("#error_accno").text("Please Enter Account No.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#accno").closest("div").parent().removeClass("has-error");

            $("#error_accno").text("");
          
        }
    
  /*--------------------------------  Loan Calculation---------------------------------------------  */
  var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
  var loanamount=$("#loanamount").val();
  var datepicker3=$("#datepicker3").val();
  var loaninterest=$("#loaninterest").val();
  var miloan=$("#miloan").val();
  var loanterm=$("#loanterm").val();
  
  //if((loanterm==null || loanterm=="" ) && (loanamount==null || loanamount=="")&&(datepicker3==null || datepicker3=="") && (loaninterest==null || loaninterest=="") && (miloan==null ||miloan=="")){
  	
 // }else{
  	
  	if(loanamount==null || loanamount==""){
          $("#loanamount").closest("div").parent().addClass("has-error");
          $("#error_loanamount").text("Please Enter Loan Amount.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
          }
        }
        
         if(datepicker3==null || datepicker3==""){
          $("#datepicker3").closest("div").parent().addClass("has-error");
          $("#error_loandate").text("Please Enter Loan Date");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#datepicker3").closest("div").parent().removeClass("has-error");

            $("#error_loandate").text("");
          
        }
  	
  	
  	  if(loaninterest==null || loaninterest==""){
          $("#loaninterest").closest("div").parent().addClass("has-error");
          $("#error_loaninterest").text("Please Enter Loan Interest rate.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!loaninterest.match(currency_regx) ) {
              $("#loaninterest").closest("div").parent().addClass("has-error");
              $('#error_loaninterest').html(" Please Enter valid <b>Loan Interest Amount</b>. Ex - 5.12 ");
              error_code++;
           // return false;
          }
          else{
            $("#loaninterest").closest("div").parent().removeClass("has-error");
            $("#error_loaninterest").text("");
          }
        }
  	
  	   if(miloan==null || miloan==""){
          $("#miloan").closest("div").parent().addClass("has-error");
          $("#error_miloan").text("Please Enter Loan Monthly Rate.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!miloan.match(currency_regx) ) {
              $("#miloan").closest("div").parent().addClass("has-error");
              $('#error_miloan').html(" Please Enter valid <b>Loan Monthly Amount</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#miloan").closest("div").parent().removeClass("has-error");
            $("#error_miloan").text("");
          }
        }
  	
  	
  	 if(loanterm==null || loanterm==""){
          $("#loanterm").closest("div").parent().addClass("has-error");
          $("#error_loanterm").text("Please Select Loan Term");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#loanterm").closest("div").parent().removeClass("has-error");

            $("#error_loanterm").text("");
          
        }
  	
  //}
         /*---------------------------------------------------------------------
      --                Insurance rate validations
      --error_opbalance
      ---------------------------------------------------------------------*/
        var insrate=$("#insrate").val();
        //var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      if(insrate==null || insrate==""){
          $("#insrate").closest("div").parent().addClass("has-error");
          $("#error_insrate").text("Please Enter Insurance Rate.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!insrate.match(currency_regx) ) {
              $("#insrate").closest("div").parent().addClass("has-error");
              $('#error_insrate').html(" Please Enter valid <b>Insurance Rate</b>. Ex - 2.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#insrate").closest("div").parent().removeClass("has-error");
            $("#error_insrate").text("");
          }
        }

      
  
        if(error_code>0){

          return false;

        }else{
          return true;

        }





      });
      
      $("#loanamount").keyup(function(){
      	//alert('hh');
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#insrate").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#insamount").val("");
      	}else{
      		var insrate=$("#insrate").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#insamount").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#insamount").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            $("#insamount").val(insm.toFixed(2));
            
            
          }
        }
      	
      });
      
      
      
      //monthly install ment calculation
      $("#loanamount").keyup(function(){
      	//alert('hh');
      	var intscalcul=$("#interestcalculation").val();
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#loaninterest").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#miloan").val("");
      	}else{
      		var insrate=$("#loaninterest").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#miloan").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#miloan").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            
            if(intscalcul=="Yearly"){
            	var insm=((parseFloat(loanamount)*parseFloat(insrate))/100)/12;
            	$("#miloan").val(insm.toFixed(2));
            }else{
            	var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            	$("#miloan").val(insm.toFixed(2));
            }
            
            
            
          }
        }
      	
      });
      
      
      //interest calculation 
      
      $("#loaninterest").blur(function(){
      	//alert('hh');
      	var intscalcul=$("#interestcalculation").val();
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#loaninterest").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#miloan").val("");
      	}else{
      		var insrate=$("#loaninterest").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#miloan").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#miloan").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            
            if(intscalcul=="Yearly"){
            	var insm=((parseFloat(loanamount)*parseFloat(insrate))/100)/12;
            	$("#miloan").val(insm.toFixed(2));
            }else{
            	var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            	$("#miloan").val(insm.toFixed(2));
            }
            
            
            
          }
        }
      	
      });
      
      $("#interestcalculation").change(function(){
      	//alert('hh');
      	var intscalcul=$("#interestcalculation").val();
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#loaninterest").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#miloan").val("");
      	}else{
      		var insrate=$("#loaninterest").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#miloan").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#miloan").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            
            if(intscalcul=="Yearly"){
            	var insm=((parseFloat(loanamount)*parseFloat(insrate))/100)/12;
            	$("#miloan").val(insm.toFixed(2));
            }else{
            	var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            	$("#miloan").val(insm.toFixed(2));
            }
            
            
            
          }
        }
      	
      });
      
      
      
      
      $("#insrate").blur(function(){
      	//alert('hh');
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#insrate").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#insamount").val("");
      	}else{
      		var insrate=$("#insrate").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#insamount").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#insamount").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            $("#insamount").val(insm.toFixed(2));
            
            
          }
        }
      	
      });
     
      $("#loanterm,#datepicker3").change(function(){
	  	var dat=$("#datepicker3").val();
	  	//alert(dat);
	  	//console.log(dat);
	  	var opbal=$("#opbalance").val();
	  	var period=$("#loanterm").val();
	  	if((period!="" || period!=null) ){

	  		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>manage_accounts/NewAccounts/get_matdate",
  			data :{'dat':dat,'period':period},
  			success : function(data){
  				//console.log(data);
				$("#adjust").val(data);
  			  
              }  
           });
	  	}else{
	  		$("#adjust").val("");
	  	}
	  	
	  	
	  });
	  
	  
      function readURL(input) {

      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function(e) {
          $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
      }
    }
    
    $("#accno").change(function(){
    	var accno=$("#accno").val();
    	//console.log(accno);
    	// var accno=$("#accno").val();
      if(accno==null || accno==""){
          $("#accno").closest("div").parent().addClass("has-error");
          $("#error_accno").text("Please Enter Account No.");
          $("#mesage").html("");
          $("#loanamount").val("");
		  $("#datepicker3").val("");
		  $("#loaninterest").val("");
		  $("#miloan").val("");
		  $("#loanterm").val("");
		  $("#insrate").val("1");
		  $("#insamount").val("");
		  $("#adjust").val("");
          return false;
          //error_code++;
          
          
          
          
          
          
          
          
          
        }
        else{
          //$("#error_ln").text("");
           
             $("#accno").closest("div").parent().removeClass("has-error");

            $("#error_accno").text("");
             $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>insurance/Insurance_controller/get_all_ins_take_info",
  			data :{'accno':accno},
  			success : function(data){
  				//console.log(data);
				//$("#district").html(data);
				var json=JSON.parse(data);
				if(json=="" || json==null){
					$("#loanamount").val("");
					$("#datepicker3").val("");
					$("#loaninterest").val("");
					$("#miloan").val("");
					$("#loanterm").val("");
					$("#insrate").val("1");
					$("#insamount").val("");
					$("#adjust").val("");
					$("#mesage").hide();
					
					
				}else{
					
					  var loanamount=json.loan_amount;
					  var datepicker3=json.loan_date;
					  var loaninterest=json.interest_rate;
					  var miloan=json.monthly_installment;
					  var loanterm=json.period;
					  var insurancerate=json.insurance_rate;
					  var insurance=json.insurance_amount;
					  var adjust=json.adjustment;
					  var tbl=json.tabl;
					  var msg="Accno-<b>"+accno+"</b> has already taken a loan agreement. please see left side for details info.You can update all details from left side panel ";
					  /*$("#loanamount").val(loanamount);
						$("#datepicker3").val(datepicker3);
						$("#loaninterest").val(loaninterest);
						$("#miloan").val(miloan);
						$("#loanterm").val(loanterm);
						$("#insrate").val(insurancerate);
						$("#insamount").val(insurance);
						$("#adjust").val(adjust);*/
						$("#loanamount").val("");
						$("#datepicker3").val("");
						$("#loaninterest").val("");
						$("#miloan").val("");
						$("#loanterm").val("");
						$("#insrate").val("1");
						$("#insamount").val("");
						$("#adjust").val("");
						//$("#mesage").hide();
						
					    //$("#mesage").html('<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> Alert!</h4>'+msg+'</div>');
						$("#mesage").html(tbl);
					
					
					
					
					
				}
  			  
              }  
           });
            
            
            
            
            
            
            
            
            
          
        }
    
    	
    });
    
    
    
    

    $("#image").change(function() {
      readURL(this);
    });
    })
    function getval(){
    	alert('hhh');
    }
</script>
