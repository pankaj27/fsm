<?php $this->load->view('statement/list_style.php'); ?>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Statement Details 
        <small>List</small> &nbsp;
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Statement</a></li>
        <li class="active">Statement List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      
      
      <div class="row">
      	<div class="col-md-3">
      		<div class="box box-info">
		            <div class="box-header with-border">
		              	<h3 class="box-title">Accounts Information</h3>
		            </div>
		            <div class="form-horizontal">
			              <div class="box-body">
			              	    <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Accno</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="accno" id="accno" placeholder="Enter Accno" value="" required="required" onblur="gettransac();" >
				                    <span class="help-block" id="error_accno"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">ID</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="custid" id="custid" placeholder="Customer ID" value="" readonly>
				                    <span class="help-block" id="error_custid"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Name</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="name" id="name" placeholder="Name Details" value="" readonly>
				                    <span class="help-block" id="error_name"></span>
				                  </div>
				                </div>
				                
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Dep. Ins</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="depinst" id="depinst" placeholder="Installments" value="" readonly style="text-align: right;">
				                    <span class="help-block" id="error_depinst"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Principle</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="principal" id="principal" placeholder="Principle" value="" readonly style="text-align: right;">
				                    <span class="help-block" id="error_principal"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Interest</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="interest" id="interest" placeholder="Interest" value="" readonly  style="text-align: right;">
				                    <span class="help-block" id="error_interest"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Balance</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="balance" id="balance" placeholder="Balance" value="" readonly style="text-align: right;" >
				                    <span class="help-block" id="error_balance"></span>
				                  </div>
				                </div>
				                <!--<div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Loan</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="collectby" id="collectby" placeholder="Collected By" value="" required="required" >
				                    <span class="help-block" id="error_collectby"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Interest</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="collectby" id="collectby" placeholder="Collected By" value="" required="required" >
				                    <span class="help-block" id="error_collectby"></span>
				                  </div>
				                </div>-->
				                <!--<div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Deposit</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="deposit" id="deposit" placeholder="Deposit" value="" readonly>
				                    <span class="help-block" id="error_deposit"></span>
				                  </div>
				                </div>-->
				                <!--<div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Loan</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="loan" id="loan" placeholder="Loan amount" value="" readonly>
				                    <span class="help-block" id="error_loan"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Loan Inst</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="loan_inst" id="loan_inst" placeholder="Loan Installment" value="" readonly>
				                    <span class="help-block" id="error_loan_inst"></span>
				                  </div>
				                </div>-->
				               <!-- <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Paid</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="paid" id="paid" placeholder="Paid amount" value="" readonly>
				                    <span class="help-block" id="error_paid"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Due</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="due" id="due" placeholder="Due amount" value="" readonly>
				                    <span class="help-block" id="error_due"></span>
				                  </div>
				                </div>-->
					      </div>
				     </div>
	           </div>
      	</div>
      	<div class="col-md-9">
	      	<div class="nav-tabs-custom">
	            <ul class="nav nav-tabs">
	              <li class="active"><a href="#tab_1" data-toggle="tab" aria-expanded="true">Recurring </a></li>
	              <li class=""><a href="#tab_2" data-toggle="tab" aria-expanded="false">Loan </a></li>
	              
	              
	            </ul>
	            <div class="tab-content">
	              <div class="tab-pane active" id="tab_1">
	                <b>Recurring Details:</b>
	
		                <table id="example1" class="table table-bordered table-striped" >
		                <thead>
		                <tr>
		                  <th style="width: 100px;">Date</th>
		                  <th style="width: 300px;">Particulars</th>
		                  <th style="width: 100px;text-align: right;">Withdrawn</th>
		                  <th style="width: 100px;text-align: right">Deposit</th>
		                  <th style="width: 100px;text-align: right">Balance</th>
		                  
		                </tr>
		                </thead>
		                <tbody>
		                
		                </tbody>
		                <tfoot>
		                <tr>
		                  <th style="width: 100px;">Date</th>
		                  <th style="width: 300px;">Particulars</th>
		                  <th style="width: 100px;text-align: right;">Withdrawn</th>
		                  <th style="width: 100px;text-align: right">Deposit</th>
		                  <th style="width: 100px;text-align: right">Balance</th>
		                  
		                </tr>
		                </tfoot>
		              </table>
	              </div>
	              <!-- /.tab-pane -->
	              <div class="tab-pane" id="tab_2">
	                <table id="example11" class="table table-bordered table-striped" >
		                <thead>
		                <tr>
		                  <th>Date</th>
		                  <th>Loan</th>
		                  <th>Received</th>
		                  <th>Due</th>
		                  <th>Interest</th>
		                  <th>Received</th>
		                  <th>Due</th>
		                  <th>Total</th>
		                  
		                </tr>
		                </thead>
		                <tbody>
		                
		                </tbody>
		                <tfoot>
		                <tr>
		                  <th>Date</th>
		                  <th>Loan</th>
		                  <th>Received</th>
		                  <th>Due</th>
		                  <th>Interest</th>
		                  <th>Received</th>
		                  <th>Due</th>
		                  <th>Total</th>
		                </tr>
		                </tfoot>
		              </table>
	              </div>
	              <!-- /.tab-pane -->
	              
	              <!-- /.tab-pane -->
	            </div>
	            <!-- /.tab-content -->
	          </div>
         </div>
        
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
   <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php $this->load->view('statement/list_script.php');  ?>
<script>
	$(document).ready(function(){
		//Date picker
	       /*$( ".datepicker1" ).datepicker({
	  	 	    changeMonth: true,
	            changeYear: true,
	            showButtonPanel: true,
	            dateFormat: 'dd-mm-yy'
	  	 });*/
		$("#accno").blur(function(){
			//alert('hello');
			var accno=$("#accno").val();
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>statement/Statement_controller/get_acc_details",
  			data :{'accno':accno},
  			success : function(data){
  				console.log(data);
  				
  				var json=JSON.parse(data);
  				if(json=="" || json==null){
	  					$("#custid").val();
		  				$("#name").val();
		  				$("#principal").val();
		  				$("#interest").val();
		  				$("#balance").val();
		  				$("#depinst").val();
  					
  				}else{
  					var id=json.id;
  				//console.log(id);
  				var fname=json.first_name;
  				var mname=json.middle_name;
  				var lname=json.last_name;
  				var nam=fname+" "+mname+" "+lname;
  				var principal=json.deposit;
  				var interest=json.interest;
  				var total=parseFloat(principal)+parseFloat(interest);
  				//var opbal=json.opening_balance;
  				//var opening_date=json.opening_date;
  				var monthly_installment=json.monthly_installment;
  				//var accopen=json.accopdte;
  				$("#custid").val(id);
  				$("#name").val(nam);
  				$("#principal").val(principal);
  				$("#interest").val(interest);
  				$("#balance").val(total.toFixed(2));
  				$("#depinst").val(monthly_installment);
  				}
  				
  				
  				//$("#depsiyby").text(data);
  			  //$("#msg").val(data);
  			   
              }  
           });
		});
		
	});
	function gettransac(){
		//alert('hello');
		
		var accno=$("#accno").val();
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>statement/Statement_controller/get_recurring_info",
  			data :{'accno':accno},
  			success : function(data){
  				$("#tab_1").html(data);
              }  
           });
           
           $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>statement/Statement_controller/get_loan_info",
  			data :{'accno':accno},
  			success : function(data){
  				$("#tab_2").html(data);
              }  
           });
           
           
	}
	</script>
