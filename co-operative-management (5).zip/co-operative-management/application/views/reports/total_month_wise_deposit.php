<?php $this->load->view('reports/total_month_wise_deposit_style.php'); ?>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Month Wise Total Deposit
        <small>List</small> &nbsp;
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Manage Accounts</a></li>
        <li class="active">Monthwise Deposit</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    	<div class="row">
    		<div class="col-xs-12">
    			<div class="box box-info">
			            <div class="box-header">
			              Select Month Wise Deposit
			            </div>
			            <div class="box-body">
			            	<div class="col-md-4">
			            		<?php
								  // Sets the top option to be the current year. (IE. the option that is chosen by default).
								  $currently_selected = date('Y'); 
								  // Year to start available options at
								  $earliest_year = 1950; 
								  // Set your latest year you want in the range, in this case we use PHP to just set it to the current year.
								  $latest_year = date('Y'); 
								
								  print '<select class="form-control" id="year">';
								  print '<option value="">--select--</option>';
								  // Loops over each int[year] from current year, back to the $earliest_year [1950]
								  foreach ( range( $latest_year, $earliest_year ) as $i ) {
								    // Prints the option with the next year in range.
								    print '<option value="'.$i.'"'.($i === $currently_selected ? ' selected="selected"' : '').'>'.$i.'</option>';
								  }
								  print '</select>';
								  ?>
			            	</div>
			            	<div class="col-md-4">
			            		<select name="month" size='1' class="form-control" id="month">
			            			
								    <?php
								    echo "<option value=''>--select--</option>";
								    for ($i = 0; $i < 12; $i++) {
								        $time = strtotime(sprintf('%d months', $i));   
								        $label = date('F', $time);   
								        $value = date('n', $time);
								        echo "<option value='$value'>$label</option>";
								    }
								    ?>
								</select>
			            	</div>
			            	<div class="col-md-4">
			            		<a href="#"><button class="btn btn-primary" onclick="get_result()">Search</button></a>
			            	</div>
			            </div>
    			</div>
    	</div>
    </div>
      <div class="row">
      	<div class="col-xs-6">
      		<div class="box box-primary">
	            <div class="box-header">
	              <h3 class="box-title">Total Deposit Information</h3>
	            </div>
	            <!-- /.box-header -->
	            <div class="box-body" >
	            </div>
          </div>
      	</div>
        <div class="col-xs-6">
        	
          <div class="box box-primary">
            <div class="box-header">
              <h3 class="box-title">Accountwise Details Information</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" >
              <table id="example1" class="table table-bordered table-striped" >
                <thead>
                <tr>
                  <th>Sl No.</th>
                  <th>Accno</th>
                  <th>Month</th>
                  <th>Deposit Amount</th>
                  
                </tr>
                </thead>
                <tbody>
                
		                  <tr>
		                  		<td></td>
		                  		<td></td>
		                  		<td></td>
		                  		<td></td>
						</tr>
                </tbody>
                <tfoot>
                <tr>
                  <th>Sl No.</th>
                  <th>Accno</th>
                  <th>Month</th>
                  <th>Deposit Amount</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
   <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php $this->load->view('reports/total_month_wise_deposit_script.php');  ?>
<script>
	function get_result(){
		//alert('hello');
		var year=$("#year").val();
		var mnth=$("#month").val();
		
		if(year=="" || year==null){
			alert('please select year');
			return false;
		}
		
		if(mnth=="" || mnth==null){
			alert('please select month');
			return false;
			
		}
		
		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>reports/reports_controller/get_results",
  			data :{'dat':dat,'period':period},
  			success : function(data){
  				//console.log(data);
				$("#mtdate").val(data);
  			  
              }  
           });
		
		
	}
</script>
