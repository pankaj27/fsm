<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo base_url();   ?>assets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $this->session->userdata('username');  ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                  <i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="treeview menu">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Manage Accounts</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>manage_accounts/NewAccounts/addNewaccounts"><i class="fa fa-circle-o"></i> New Accounts</a></li>
            <li><a href="<?php echo base_url(); ?>manage_accounts/NewAccounts/list_view"><i class="fa fa-circle-o"></i> View</a></li>
            
            <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          </ul>
        </li>
        <li>
          <a href="<?php echo base_url(); ?>manage_accounts/NewAccounts/apply_for_loan/">
            <i class="fa fa-folder-o"></i> <span class="text-red">Apply for Loan</span>
            
          </a>
        </li>
        <!-- <li class="treeview menu">
          <a href="#">
            <i class="fa fa-table"></i> <span>Recurring</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="#"><i class="fa fa-circle-o"></i> Details</a></li>
            
            <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          <!-- </ul>
        </li>
        <li class="treeview menu">
          <a href="#">
            <i class="fa fa-rupee"></i> <span>Loan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="#"><i class="fa fa-circle-o"></i> Apply New</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Details</a></li>
            
            <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          <!-- </ul>
        </li>-->
        <li class="treeview menu">
          <a href="#">
            <i class="fa fa-money"></i> <span>Transaction</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>transaction/Transaction/add_new_transaction"><i class="fa fa-circle-o"></i> Add</a></li>
            <li><a href="<?php echo base_url(); ?>insurance/Insurance_controller/pay_insurence"><i class="fa fa-circle-o"></i> Pay Insurance</a></li>
            
            <!--<li><a href="<?php echo base_url(); ?>transaction/Transaction/transaction_list"><i class="fa fa-circle-o"></i> List</a></li>-->
            
            <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          </ul>
        </li>
        <li>
          <a href="<?php echo base_url(); ?>statement/Statement_controller/">
            <i class="fa fa-tasks"></i> <span>Statement</span>
            
          </a>
        </li>
        <li class="treeview menu">
          <a href="#">
            <i class="fa fa-database"></i> <span>Settlement</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>settlement/Settlement/ddsettlement/"><i class="fa fa-circle-o"></i> Recurring Settlement</a></li>
            <li><a href="<?php echo base_url(); ?>settlement/Settlement/loan_settlement/"><i class="fa fa-circle-o"></i> Loan Settlement</a></li>
            
            <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          </ul>
        </li>
        <li class="treeview menu">
          <a href="#">
            <i class="fa fa-print"></i> <span>Reports</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>reports/Reports_controller/get_total_month_wise_deposit/"><i class="fa fa-circle-o"></i> Total Deposit Per Month</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Total Loan Per Month</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Interest Pay for DD</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Interest Receive for Loan</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Penalty Total</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Monthwise Interest Discount</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Dead No Repay</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Monthwise Interest Discount</a></li>
            
            <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          </ul>
        </li>
       <!--  <li class="treeview menu">
          <a href="#">
            <i class="fa fa-print"></i> <span>Reports</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="#"><i class="fa fa-circle-o"></i> Print Recurring</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Print Loan</a></li>
            
            <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          <!-- </ul>
        </li>-->
        <li class="header">MASTER SETTINGS</li>
        <li class="treeview menu">
          <a href="#">
            <i class="fa fa-bank"></i> <span>Account Master</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url();  ?>master_setting/Master_setting/"><i class="fa fa-circle-o"></i>List</a></li>
             <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          </ul>
        </li>
        <!-- <li class="treeview menu">
          <a href="#">
            <i class="fa fa-users"></i> <span>User Master</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url();  ?>master_setting/Master_setting/user_list"><i class="fa fa-circle-o"></i>List</a></li>
             <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          <!-- </ul>
        </li>-->
        <!--<li class="active treeview menu-open">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Manage Transaction</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>manage_accounts/NewAccounts/addNewaccounts"><i class="fa fa-circle-o"></i> New Accounts</a></li>
            <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          <!--</ul>
        </li>
        <li class="active treeview menu-open">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Settings</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>manage_accounts/NewAccounts/addNewaccounts"><i class="fa fa-circle-o"></i> New Accounts</a></li>
            <!--<li class="active"><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>-->
          <!--</ul>
        </li>
        <!--<li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>Tables</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/tables/simple.html"><i class="fa fa-circle-o"></i> Simple tables</a></li>
            <li><a href="pages/tables/data.html"><i class="fa fa-circle-o"></i> Data tables</a></li>
          </ul>
        </li>
        <li>
          <a href="pages/calendar.html">
            <i class="fa fa-calendar"></i> <span>Calendar</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-red">3</small>
              <small class="label pull-right bg-blue">17</small>
            </span>
          </a>
        </li>-->
        
        
        
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>