<?php $this->load->view('settlement/dd_settlement_style.php'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        D/D Settlement
       </h1>
       
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Manage Settlement</a></li>
        <li><a href="#">D/D Settlement</a></li>
        <li class="active">Add</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-6">
          <!-- Horizontal Form -->
          <div class="box box-danger">
            
           <?php $query3=$this->db->query("select * from account_master where status='1'"); ?>
			<?php  $res3=$query3->result(); ?>
            <div class="box-header with-border">
              <h3 class="box-title">D/D Account Information</h3>
            </div>
            <form action="<?php echo base_url(); ?>settlement/settlement/dd_settlement_save"  method="post" enctype="multipart/form-data">
            
             <div class="form-horizontal">
              <div class="box-body">
                <?php $query4=$this->db->query("select * from customer_recurring_master where status='1'"); ?>
			    <?php  $res4=$query4->result(); ?>
                
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Account No <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <select id="accno" class="form-control select2" style="width: 100%;" name="accno"  >
                    	 <option  value="">Select Any Accno</option>
		                  <?php if(isset($res4) && !empty($res4)){ ?>
		                  	          
							<?php foreach($res4 as $val4){ ?>
							    
								      <option  value="<?php echo $val4->accno; ?>" ><?php echo $val4->accno ; ?></option>
							    
		                  
							<?php } } ?> 
		                </select><span class="help-block" id="error_accno"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Total Deposit </label>

                  <div class="col-sm-9">
                    <input type="text" name="total_dd" class="form-control" readonly="readonly" id="total_dd"/>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Interest Rate </label>

                  <div class="col-sm-9">
                    <input type="text" name="interest_rate" class="form-control" readonly="readonly" id="interest_rate"/>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Period </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="time" readonly="readonly" id="time"/>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Interest Amount </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="interest" readonly="readonly" id="interest"/>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Opening  Date </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="opd" readonly="readonly" id="opd"/>
                    <input type="hidden" id="othp" name="othp">
                  </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Maturity  Date </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="mdt" readonly="readonly" id="mdt"/>
                  </div>
                </div>
	          
              </div>
              
              
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="reset" class="btn btn-default">Cancel</button>
                <button type="submit" id="submit" class="btn btn-info pull-right"> Process for settlment</button>
              </div>
             </div>
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
          
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
        <div class="col-md-6" id="mesage">
        	
        </div>
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php //$this->load->view('newaccounts/newaccounts-script.php');  ?>
<?php $this->load->view('settlement/dd_settlement_script.php');  ?>
<script>
  $(document).ready(function(){
	
	 
      $("#submit").click(function(event){
      	//alert('hello');return false;
      	var error_code=0;
        /*---------------------------------------------------------------------
      --                Account No  VALIDATION
      --
      ---------------------------------------------------------------------*/
        var accno=$("#accno").val();
      if(accno==null || accno==""){
          $("#accno").closest("div").parent().addClass("has-error");
          $("#error_accno").text("Please Enter Account No.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#accno").closest("div").parent().removeClass("has-error");

            $("#error_accno").text("");
          
        }
    
    
      
      
  
        if(error_code>0){

          return false;

        }else{
          return true;

        }





      });
      
      
      
      
      
      
      
      
      
	  
     
    $("#accno").change(function(){
    	var accno=$("#accno").val();
    	console.log(accno);
    	// var accno=$("#accno").val();
      if(accno==null || accno==""){
          $("#accno").closest("div").parent().addClass("has-error");
          $("#error_accno").text("Please Enter Account No.");
          $("#mesage").html("");
          $("#total_dd").val("");
		  $("#interest_rate").val("");
		  $("#time").val("");
		  $("#interest").val("");
		  $("#opd").val("");
		  $("#mdt").val("");
		  $("#othp").val("");
		  //$("#insamount").val("");
		  //$("#adjust").val("");
          return false;
          //error_code++;
          
          
          
          
          
          
          
          
          
        }
        else{
          //$("#error_ln").text("");
           
             $("#accno").closest("div").parent().removeClass("has-error");

            $("#error_accno").text("");
             $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>settlement/settlement/get_all_dd_info",
  			data :{'accno':accno},
  			success : function(data){
  				var json=JSON.parse(data);
				if(json=="" || json==null){
					  $("#total_dd").val("");
					  $("#interest_rate").val("");
					  $("#time").val("");
					  $("#interest").val("");
					  $("#opd").val("");
					  $("#mdt").val("");
					  $("#othp").val("");
					  $("#mesage").html();
					
					
				}else{
					
					  var total_dd=json.total_dd;
					  var interest_rate=json.interest_rate;
					  var time=json.time;
					  var interest=json.interest;
					  var opd=json.opd;
					  var mdt=json.mdt;
					  var tbl=json.tbl;
					  var othp=json.othp;
					  var msg="Detail about Accno-<b>"+accno+"</b> info . please see left & below  for details info. ";
					  $("#total_dd").val(total_dd);
					  $("#interest_rate").val(interest_rate);
					  $("#time").val(time+ " Months");
					  $("#interest").val(interest);
					  $("#opd").val(opd);
					  $("#othp").val(othp);
					  $("#mdt").val(mdt);
					  $("#mesage").html('<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> Alert!</h4>'+msg+'</div>');
					  $("#mesage").append(tbl);
					
				}
  			  
              }  
           });
            
            
        }
    
    	
    });
    
    
    
    

    
    })
   
</script>
