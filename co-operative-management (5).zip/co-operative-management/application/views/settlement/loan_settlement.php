<?php $this->load->view('settlement/loan_settlement_style.php'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Loan Settlement
       </h1>
       
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Manage Settlement</a></li>
        <li><a href="#">Loan Settlement</a></li>
        <li class="active">Add</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-6">
          <!-- Horizontal Form -->
          <div class="box box-danger">
            
           <?php $query3=$this->db->query("select * from account_master where status='1'"); ?>
			<?php  $res3=$query3->result(); ?>
            <div class="box-header with-border">
              <h3 class="box-title">Loan Account Information</h3>
            </div>
            <form action="<?php echo base_url(); ?>settlement/settlement/loan_settlement_save"  method="post" enctype="multipart/form-data">
            
             <div class="form-horizontal">
              <div class="box-body">
                <?php $query4=$this->db->query("select * from customer_loan_master where status='1'"); ?>
			    <?php  $res4=$query4->result(); ?>
                
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Account No <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <select id="accno" class="form-control select2" style="width: 100%;" name="accno"  >
                    	 <option  value="">Select Any Accno</option>
		                  <?php if(isset($res4) && !empty($res4)){ ?>
		                  	          
							<?php foreach($res4 as $val4){ ?>
							    
								      <option  value="<?php echo $val4->accno; ?>" ><?php echo $val4->accno ; ?></option>
							    
		                  
							<?php } } ?> 
		                </select><span class="help-block" id="error_accno"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Total Loan </label>

                  <div class="col-sm-9">
                    <input type="text" name="total_loan" class="form-control" readonly="readonly" id="total_loan"/>
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Period </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="time" readonly="readonly" id="time"/>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Interest </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="interest" readonly="readonly" id="interest"/>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Last Payment Date </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="lpd" readonly="readonly" id="lpd"/>
                  </div>
                </div>
	          
	           <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Total Paid </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="totpay" readonly="readonly" id="totpay"/>
                  </div>
                </div>
                
                
                  <div class="form-group">
	                <label for="Account type" class="col-sm-3 control-label">Type of settlement </label>
	                <div class="col-sm-9">
		                <select id="interestcalculation" class="form-control select2" style="width: 100%;" name="typeofsettlement" >
		                  	    <option  value="" >Select type of settlement</option>
		                  	     <option  value="1" >Loan amount fully paid</option>
		                  	     <option  value="2" >Loan Preclosure</option>
		                  	     <option  value="3" >Loan repayment not done timely</option>
		                  	     <option  value="4" >Emergency like death,</option>
		                  	       
					    </select>
		                <span class="help-block" id="error_interestcalculation"></span>
		               </div>
                </div>
                
                <div class="form-group" id="settlemnt">
	                
                </div>
                <div class="form-group" id="ulti">
	                
                </div>
                <div class="form-group" id="death">
	                
                </div>
                
                
                
                
                
                
                
                
              </div>
              
              
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="reset" class="btn btn-default">Cancel</button>
                <button type="submit" id="submit" class="btn btn-info pull-right"> Process for settlment</button>
              </div>
             </div>
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
          
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
        <div class="col-md-6" id="mesage">
        	
        </div>
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php //$this->load->view('newaccounts/newaccounts-script.php');  ?>
<?php $this->load->view('settlement/loan_settlement_script.php');  ?>
<script>
  $(document).ready(function(){
	
	 
      $("#submit").click(function(event){
      	//alert('hello');return false;
      	var error_code=0;
        /*---------------------------------------------------------------------
      --                Account No  VALIDATION
      --
      ---------------------------------------------------------------------*/
        var accno=$("#accno").val();
      if(accno==null || accno==""){
          $("#accno").closest("div").parent().addClass("has-error");
          $("#error_accno").text("Please Enter Account No.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#accno").closest("div").parent().removeClass("has-error");

            $("#error_accno").text("");
          
        }
    
    var interestcalculation=$("#interestcalculation").val();
    if(interestcalculation==null || interestcalculation==""){
          $("#interestcalculation").closest("div").parent().addClass("has-error");
          $("#error_interestcalculation").text("Please Select Settlement type");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#interestcalculation").closest("div").parent().removeClass("has-error");

            $("#error_interestcalculation").text("");
            
            
            
            
            
            
            
            
          
        }
      
      
  
        if(error_code>0){

          return false;

        }else{
          return true;

        }





      });
      
      
      
      
      //monthly install ment calculation
      
      //interest calculation 
      $("#interestcalculation").change(function(){
      	
      	var interestcalculation=$("#interestcalculation").val();
		    if(interestcalculation==null || interestcalculation==""){
		          $("#interestcalculation").closest("div").parent().addClass("has-error");
		          $("#error_interestcalculation").text("Please Select Settlement type");
		          $("#settlemnt").html("");
		            	$("#ulti").html("");
		            	$("#death").html("");
		          //return false;
		          error_code++;
		        }
		        else{
		          //$("#error_ln").text("");
		           
		             $("#interestcalculation").closest("div").parent().removeClass("has-error");
		
		            $("#error_interestcalculation").text("");
		             var html="";
		             var html2="";
		             if(interestcalculation==1){
		            	
		            	$("#settlemnt").html("");
		            	$("#ulti").html("");
		            	$("#death").html("");
		            }
		            if(interestcalculation==2){
		            	var total_loan=parseFloat($("#total_loan").val());
		            	var totpay=parseFloat($("#totpay").val());
		            	var remaining=total_loan-totpay
		            	 html +='<label for="Account type" class="col-sm-3 control-label">Rem. amount </label>';
	                        html +='<div class="col-sm-9">';
                            html +='<input type="text" required class="form-control" name="remainingamount" id="remaining" value="'+remaining.toFixed(2)+'" />';
                            html +='</div>';
		            	$("#settlemnt").html(html);
		            	$("#ulti").html("");
		            	$("#death").html("");
		            }
		            if(interestcalculation==3){
		            	var total_loan=parseFloat($("#total_loan").val());
		            	var totpay=parseFloat($("#totpay").val());
		            	var remaining=total_loan-totpay;
		            	var intwithloan=(remaining)+(remaining*.02);
		            	 html +='<label for="Account type" class="col-sm-3 control-label">Rem. amount(With int) </label>';
	                        html +='<div class="col-sm-9">';
                            html +='<input type="text" class="form-control" required name="remainingamount" id="remaining" value="'+intwithloan.toFixed(2)+'" />';
                            html +='</div>';
                            //html +='<br>';
                            html2 +='<label for="Account type" class="col-sm-3 control-label">Ultimate Pay </label>';
	                        html2 +='<div class="col-sm-9">';
                            html2 +='<input type="text" class="form-control" required name="ultimate" id="ultimate" value="0" />';
                            html2 +='</div>';
		            	$("#settlemnt").html(html);
		            	$("#ulti").html(html2);
		            	$("#death").html("");
		            	
		            }
		            if(interestcalculation==4){
		            	var total_loan=parseFloat($("#total_loan").val());
		            	var totpay=parseFloat($("#totpay").val());
		            	var remaining=total_loan-totpay;
		            	//var intwithloan=(remaining)+(remaining*.02);
		            	 html +='<label for="Account type" class="col-sm-3 control-label">Deduct from Ins A/c </label>';
	                        html +='<div class="col-sm-9">';
                            html +='<input type="text" required class="form-control" name="insur" id="insur" value="'+remaining.toFixed(2)+'" />';
                            html +='</div>';
                            //html +='<br>';
                            
		            	$("#death").html(html);
		            	$("#settlemnt").html("");
		            	$("#ulti").html("");
		            	//$("#ulti").html(html2);
		            	
		            }
		            
		            
		            
		          
		        }
      	
      });
      
      
      
      
      
	  
     
    $("#accno").change(function(){
    	var accno=$("#accno").val();
    	//console.log(accno);
    	// var accno=$("#accno").val();
      if(accno==null || accno==""){
          $("#accno").closest("div").parent().addClass("has-error");
          $("#error_accno").text("Please Enter Account No.");
          $("#mesage").html("");
          $("#loanamount").val("");
		  $("#datepicker3").val("");
		  $("#loaninterest").val("");
		  $("#miloan").val("");
		  $("#loanterm").val("");
		  $("#insrate").val("1");
		  $("#insamount").val("");
		  $("#adjust").val("");
          return false;
          //error_code++;
          
          
          
          
          
          
          
          
          
        }
        else{
          //$("#error_ln").text("");
           
             $("#accno").closest("div").parent().removeClass("has-error");

            $("#error_accno").text("");
             $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>manage_accounts/NewAccounts/get_all_loan_take_info",
  			data :{'accno':accno},
  			success : function(data){
  				//console.log(data);
				//$("#district").html(data);
				var json=JSON.parse(data);
				if(json=="" || json==null){
					$("#loanamount").val("");
					$("#datepicker3").val("");
					$("#loaninterest").val("");
					$("#miloan").val("");
					$("#loanterm").val("");
					$("#insrate").val("1");
					$("#insamount").val("");
					$("#adjust").val("");
					$("#mesage").hide();
					
					
				}else{
					
					  var loanamount=json.loan_amount;
					  var datepicker3=json.loan_date;
					  var loaninterest=json.interest_rate;
					  var miloan=json.monthly_installment;
					  var loanterm=json.period;
					  var insurancerate=json.insurance_rate;
					  var insurance=json.insurance_amount;
					  var adjust=json.adjustment;
					  var tbl=json.tabl;
					  var msg="Accno-<b>"+accno+"</b> has already taken a loan agreement. please see left side for details info.You can update all details from left side panel ";
					  /*$("#loanamount").val(loanamount);
						$("#datepicker3").val(datepicker3);
						$("#loaninterest").val(loaninterest);
						$("#miloan").val(miloan);
						$("#loanterm").val(loanterm);
						$("#insrate").val(insurancerate);
						$("#insamount").val(insurance);
						$("#adjust").val(adjust);*/
						$("#loanamount").val("");
						$("#datepicker3").val("");
						$("#loaninterest").val("");
						$("#miloan").val("");
						$("#loanterm").val("");
						$("#insrate").val("1");
						$("#insamount").val("");
						$("#adjust").val("");
						//$("#mesage").hide();
						
					    $("#mesage").html('<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> Alert!</h4>'+msg+'</div>');
						$("#mesage").append(tbl);
					
					
					
					
					
				}
  			  
              }  
           });
            
            ////////////////////////////////////////////////////////////////////////////////////////////////////////
            
            $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>settlement/Settlement/get_all_loan_settlement_info",
  			data :{'accno':accno},
  			success : function(data){
  				//console.log(data);
				//alert(data);
				var json=JSON.parse(data);
				var loan=json.loan;
				var period=json.period;
				var totinterest=json.totinterest;
				var totalpay=json.totalpay;
				var last_update=json.last_update;
				$("#total_loan").val(loan);
				$("#time").val(period+" Months");
				$("#interest").val(totinterest);
				$("#lpd").val(last_update);
				$("#totpay").val(totalpay);
  			  
              }  
           });
            
            
            
            
            
            
            
            
          
        }
    
    	
    });
    
    
    
    

    
    })
   
</script>
