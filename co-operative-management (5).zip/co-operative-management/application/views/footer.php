<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="http://www.dksoftware.co.in" target="_blank">D K Software</a>.</strong> All rights
    reserved.
 </footer>