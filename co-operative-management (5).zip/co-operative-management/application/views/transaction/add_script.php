<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  
 
<script src="<?php  echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php  echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- DataTables -->
<script src="<?php  echo base_url(); ?>assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php  echo base_url(); ?>assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<!-- Select2 -->
<script src="<?php echo base_url(); ?>assets/bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- bootstrap datepicker -->
<script src="<?php echo base_url(); ?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

<script src="<?php  echo base_url(); ?>assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php  echo base_url(); ?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php  echo base_url(); ?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="<?php  echo base_url(); ?>assets/dist/js/demo.js"></script>
<!-- page script -->
 
<script>
  $(function () {
  	 $( ".datepicker1" ).datepicker({
	  	 	    changeMonth: true,
	            changeYear: true,
	            showButtonPanel: true,
	            dateFormat: 'dd-mm-yy'
	  	 });
		
    $('#example1,#example11').DataTable()
    $('#example2').DataTable({
      'paging'      : false,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : false,
      'autoWidth'   : true
    })
  })
</script>
<script src="<?php echo base_url();?>assets/notify/javascripts/jquery.growl.js" type="text/javascript"></script>
<link href="<?php echo base_url();?>assets/notify/stylesheets/jquery.growl.css" rel="stylesheet" type="text/css" />
</body>
</html>