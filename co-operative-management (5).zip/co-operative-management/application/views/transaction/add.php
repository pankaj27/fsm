<?php $this->load->view('transaction/add_style.php'); ?>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Transaction
        <small>Add</small> &nbsp;<!-- <a href="<?php echo base_url(); ?>transaction/Transaction/transaction_list"  class="btn btn-danger">View </a>-->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Transaction </a></li>
        <li class="active">Add</li>
      </ol>
    </section>

    <!-- Main content -->
    
    <section class="content">
    	<div class="row">
	        <!-- left column -->
	        <div class="col-md-12">
	        	
	        	 <?php if($this->session->flashdata('message') != ''){ 
		    	 	  echo $this->session->flashdata('message');
		    	 	}?>
		    	 	<div id="nodeposit">
		    	 		
		    	 	</div>
		    	 	<div id="reqmsg">
		    	 		
		    	 	</div>
	        </div>
		    	
		   

	        <form action="<?php  echo base_url(); ?>transaction/Transaction/transaction_submit" method="post">
	        <div class="col-md-3">
	        	<div class="box box-info">
		            <div class="box-header with-border">
		              	<h3 class="box-title">Accounts Information</h3>
		            </div>
		            <div class="form-horizontal">
			              <div class="box-body">
			              	    <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Accno</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="accno" id="accno" placeholder="Enter Accno" value="" required="required" >
				                    <span class="help-block" id="error_accno"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">ID</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="custid" id="custid" placeholder="Customer ID" value="" readonly>
				                    <span class="help-block" id="error_custid"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Name</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="name" id="name" placeholder="Name Details" value="" readonly>
				                    <span class="help-block" id="error_name"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Op. Date</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="opdate" id="opdate" placeholder="Opening date" value="" readonly>
				                    <span class="help-block" id="error_opdate"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Op. Blnc</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="opbalance" id="opbalance" placeholder="Opening Balance" value="" readonly>
				                    <span class="help-block" id="error_opbalance"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Dep. Ins</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="depinst" id="depinst" placeholder="Installments" value="" readonly>
				                    <span class="help-block" id="error_depinst"></span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Dep. By</label>
				
				                  <div class="col-sm-9">
				                  	<input type="text" class="form-control" name="depositby" id="depositby" placeholder="Deposit By" value="" required="required" >
				                    <span class="help-block" id="error_depositby">*</span>
				                  </div>
				                </div>
				                <div class="form-group">
				                  <label for="Joint Holder" class="col-sm-3 control-label">Coll. By</label>
				
				                  <div class="col-sm-9">
				                    <input type="text" class="form-control" name="collectby" id="collectby" placeholder="Collected By" value="" required="required" >
				                    <span class="help-block" id="error_collectby">*</span>
				                  </div>
				                </div>
				               
					      </div>
				     </div>
	           </div>
           </div>
           <div class="col-xs-9">
        	<?php if(isset($listmsg) && !empty($listmsg)){ echo $listmsg; }  ?>
          <div class="box box-primary">
            <div class="box-header">
              <h3 class="box-title">Add Amount</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="height: 450px;overflow: scroll;">
              <table id="example2" class="table  table-striped"  >
                <thead>
                <tr>
                  <th style="width:20px;">Sl No.</th>
                  <!--
                  <th style="width:100px;">Month</th>
                  -->
                  <th style="width:150px;">Date</th>
                  <th style="width:120px;">Deposit</th>
                  <th style="width:10px;">+</th>
                  <th style="width:120px;">Loan</th>
                  <th style="width:10px;">=</th>
                  <th style="width:120px;">Total</th>
                  <th style="width:120px;">Action</th>
                </tr>
                </thead>
                <tbody id="new_tr_row">
                  <tr>
                  		<td style="width:20px;">
                  			<strong>1</strong>	
                  		</td>
                  		<!--<td >
                  			<input style="width: 100px;" type="text" class="form-control" name="join2" id="join2" placeholder="Month" value="">
							<span class="help-block" id="error_join2"></span>
						    
                  		</td>
                  	    -->
                  		<td>
                  			<input style="width: 150px;" type="text" class="form-control datepicker1" name="date_1" id="date_1" placeholder="Date" value="" onchange="getloandepositinfomew(this.id)">
							<span class="help-block" id="error_join2">*</span>
                  		</td>
                  		<td>
                  			<input style="width: 120px;" type="text" class="form-control" name="deposit_1" id="deposit_1" placeholder="Deposit" onkeyup="getvalidvalue(this.id);" value="">
							<span class="help-block" id="error_join2">*</span>
                  		</td>
                  		 <td style="width:10px;">+</td>
                  		<td>
                  			<input style="width: 120px;" type="text" class="form-control" name="loan_1" id="loan_1" placeholder="Loan" value="" onkeyup="getvalidvalueloan(this.id);">
							<span class="help-block" id="error_join2">*</span>
                  		</td>
                  		<td style="width:10px;">=</td>
                  		<td>
                  			<input style="width: 120px;" type="text" class="form-control" name="total_1" id="total_1" placeholder="Total" value="" readonly="readonly">
							<span class="help-block" id="error_join2">*</span>
                  		</td>
                  		<td>
                  			<input type="hidden" name="total_row" id="total_row" value="1"/>
                  			<a href="#"  id="add_row_<?php echo 1; ?>" onclick="get_new_row(this.id);"><i class="fa fa-plus"></i></a>
                  		</td>
                  </tr>
                </tbody>
                
              </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
				   <button type="reset" class="btn btn-default">Cancel</button>
				                <button type="submit" id="submit" class="btn btn-info pull-right"><?php if(isset($account) && !empty($account)){ echo "Update" ; }else{ echo "Submit" ;}  ?></button>
		    </div>
			              
          </div>
          <!-- /.box -->

        </div>
         </form>  
         </div>
         
     
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
   <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php $this->load->view('transaction/add_script.php');  ?>
<script>
	$(document).ready(function(){
		//Date picker
	       /*$( ".datepicker1" ).datepicker({
	  	 	    changeMonth: true,
	            changeYear: true,
	            showButtonPanel: true,
	            dateFormat: 'dd-mm-yy'
	  	 });*/
		$("#accno").blur(function(){
			//alert('hello');
			var accno=$("#accno").val();
			$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>manage_accounts/NewAccounts/getaccinfo",
  			data :{'accno':accno},
  			success : function(data){
  				//console.log(data);
  				
  				var json=JSON.parse(data);
  				if(json=="" || json==null){
  					$("#custid").val("");
  				$("#name").val("");
  				$("#opdate").val("");
  				$("#opbalance").val("");
  				$("#depinst").val("");
  					
  				}else{
  					var id=json.id;
  				//console.log(id);
  				var fname=json.first_name;
  				var mname=json.middle_name;
  				var lname=json.last_name;
  				var nam=fname+" "+mname+" "+lname;
  				var opbal=json.opening_balance;
  				var opening_date=json.opening_date;
  				var monthly_installment=json.monthly_installment;
  				var depositby=json.deposit;
  				var collectby=json.collect;
  				//var accopen=json.accopdte;
  				$("#custid").val(id);
  				$("#name").val(nam);
  				$("#opdate").val(opening_date);
  				$("#opbalance").val(opbal);
  				$("#depinst").val(monthly_installment);
  				$("#depositby").val(depositby);
  				$("#collectby").val(collectby);
  				
  				}
  				
  				
  				//$("#depsiyby").text(data);
  			  //$("#msg").val(data);
  			   
              }  
           });
           /*------  loan & deposit  due screen---*/
          $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>transaction/Transaction/getloananddepositnodue",
  			data :{'accno':accno},
  			success : function(data){
  				//console.log(data);
  				var json=JSON.parse(data);
  				var totdue=parseFloat(json.totaldue);
  				var msg=json.msg;
  				if(totdue>0){
  					//alert()
  					//$("#nodeposit").html("");
  					//$("#nodeposit").html(msg);
  					//$(".table").show();
  					//$("#submit").show();
  					$.growl.notice({ message: msg,duration: 20000,location: "bc",size: "large"});
					
  				}else{
  					$.growl.notice({ message: msg,duration: 20000,location: "bc",size: "large"});
  					//$("#submit").hide();
  					//$("#nodeposit").html("");
  					//$("#nodeposit").html(msg);
  					//$(".table").hide();
  					
  				}
  				
              }  
           });
          
		});
		




			
		$("#submit").click(function(){
			var rowCount = $('#new_tr_row tr').length;
			console.log(rowCount);
			var accno=$("#accno").val();
			var custid=$("#custid").val();
			var error=0;
			if(accno=="" || accno==null){
				error++;
			}
			if(custid=="" || custid==null){
				error++;
			}
			for(var ik=1;ik<=rowCount;ik++){
				
				var doe=$("#date_"+ik).val();
				var deposit=$("#deposit_"+ik).val();
				var loan=$("#loan_"+ik).val();
				
				if((deposit=="" || deposit==null) && (loan=="" || loan==null)){
					error++;
				}
			}
			if(error>0){
				$("#nodeposit").hide();
				var msgh='* marks are required field';
				//$("#reqmsg").html(msgh);
				$.growl.error({ message: msgh,duration: 10000,location: "tc"});
					
				
				
				return false;
			}else{
				$("#nodeposit,#reqmsg").hide();
				return true;
			}
			
			
			
			
		});
		
	});
	function get_new_row(id){
			//alert(id);
			var idsplit=id.split("_");
			var unqid=idsplit[2];
			
			//$( ".datepicker" ).datepicker("destroy");
			$( ".datepicker1" ).datepicker({
	  	 	    changeMonth: true,
	            changeYear: true,
	            showButtonPanel: true,
	            dateFormat: 'dd-mm-yy'
	  	 });
			var rowCount = $('#new_tr_row tr').length;
			//alert(rowCount);
			//var dateid="";
			
			//var dateid += "#hgf";
			//console.log(dateid);*/
			var newunid=parseInt(rowCount)+1;
			var table_row='<tr id="rowid_'+newunid+'">'
                        table_row +='<td style="width:20px;"><strong>'+newunid+'</strong></td>';
                  		//table_row +='<td><input style="width: 150px;" type="text" class="form-control" name="month_'+newunid+'" id="month_'+newunid+'" placeholder="Month" value=""><span class="help-block" id="error_join2"></span></td>';
                  		table_row +='<td><input style="width: 150px;" type="text" class="form-control datepicker1" name="date_'+newunid+'" id="date_'+newunid+'" placeholder="Date" onchange="getloandepositinfomew(this.id)" ><span class="help-block" id="error_join2">*</span></td>';
                  		table_row +='<td><input style="width: 120px;" type="text" class="form-control" name="deposit_'+newunid+'" id="deposit_'+newunid+'" placeholder="Deposit" value="" onkeyup="getvalidvalue(this.id);"><span class="help-block" id="error_join2">*</span></td>';
                  		table_row +='<td style="width:10px;">+</td>';
                  		table_row +='<td><input style="width: 120px;" type="text" class="form-control" name="loan_'+newunid+'" id="loan_'+newunid+'" placeholder="Loan" value="" onkeyup="getvalidvalueloan(this.id);"><span class="help-block" id="error_join2"></span></td>';
                  		table_row +='<td style="width:10px;">=</td>';
                  		table_row +='<td><input style="width: 120px;" type="text" class="form-control" name="total_'+newunid+'" id="total_'+newunid+'" placeholder="Total" value="" readonly><span class="help-block" id="error_join2"></span></td>';
                  		table_row +='<td><a href="#"  id="add_row_'+newunid+'" onclick="get_new_row(this.id);"><i class="fa fa-plus"></i></a>';
                  		table_row +='&nbsp;&nbsp;<a href="#"  id="delete_row_'+newunid+'" onclick="delete_new_row(this.id);"><i class="fa fa-trash"></i></a>';
                  		table_row +='</td>';
                  table_row +='</tr>';
			$("#new_tr_row").append(table_row);
			$( ".datepicker1" ).datepicker({
	  	 	    changeMonth: true,
	            changeYear: true,
	            showButtonPanel: true,
	            dateFormat: 'dd-mm-yy'
	           
	  	 });
	  	 $("#total_row").val(newunid);
		}

	
		function delete_new_row(id){
			var idsplit=id.split("_");
			var unqid=idsplit[2];
			if(confirm('Are you sure')==true){
				var rowCount = $('#new_tr_row tr').length;
			    $("#rowid_"+unqid).remove();
			    var rowCount = $('#new_tr_row tr').length;
			    $("#total_row").val(rowCount);
			    
			}
			
		}

    function getloandepositinfomew(id){

    	//console.log("hello");
    	var idsplit=id.split("_");
    	//console.log(idsplit);
		var accno=$("#accno").val();
		//var datepick=$("#date_"+idsplit[1]).val();
		var dt=$("#date_"+idsplit[1]).val();
		//console.log(accno);
		//console.log(dt);
	 	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>transaction/Transaction/getdepositloandateinfo",
  			data :{'accno':accno,'dt':dt},
  			success : function(data){
  				console.log(data);
  				var json=JSON.parse(data);
  				var stat=json.returnstate;
  				var opendate=json.opening_date;
  				var matdate=json.maturity_date
  				if(stat==1){
  					$.growl.notice({ message: "Recurring Deposit entry not allowed for this date.Please enter valid date <b> between "+opendate+" (Op. date) & "+matdate+"( maturity date)",duration: 15000,location: "br"});
					$("#deposit_"+idsplit[1]).prop('readonly', true);
					$("#add_row_"+idsplit[1]).hide();
					
  				}else{
  					$("#deposit_"+idsplit[1]).attr('readonly', false);
					$("#add_row_"+idsplit[1]).show();

  				}
  				
              }  
           });

	 	$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>transaction/Transaction/get_loan_date_info",
  			data :{'accno':accno,'dt':dt},
  			success : function(data){
  				console.log(data);
  				var json=JSON.parse(data);
  				var stat=json.returnstate;
  				var loandate=json.opening_date;
  				var aloanadjust=json.maturity_date;
  				if(stat==1){
  					$.growl.warning({ message: "Loan Interest entry not allowed for this date.Please enter a valid date <b> between "+loandate+" (Loan date) & "+aloanadjust+"( adjustment date) ",duration: 15000,location: "br" });
					$("#loan_"+idsplit[1]).prop('readonly', true);
					$("#add_row_"+idsplit[1]).hide();
					
  				}else{
  					$("#loan_"+idsplit[1]).attr('readonly', false);
					$("#add_row_"+idsplit[1]).show();

  				}
  				
              }  
           });
		
		



		

		
    }

		
		function getvalidvalue(id){
			var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
			var idsplit=id.split("_");
			var unid=idsplit[1];
			var deposit=$("#deposit_"+unid).val();
			
			
			console.log(deposit);
			var loan=$("#loan_"+unid).val();
			var total=0;
			
			if(loan=="" || loan==null){
				loan=0;
			}
			if(deposit=="" || deposit==null){
				deposit=0;
				total=parseFloat(deposit)+parseFloat(loan);
            	var totalnew=parseFloat(total.toFixed(2));
               $("#total_"+unid).val(totalnew);
			}else{
			if (!deposit.match(currency_regx) ) {
              //alert('please enter proper value');
           // return false;
             
           
            }else{
            	total=parseFloat(deposit)+parseFloat(loan);
            	var totalnew=parseFloat(total.toFixed(2));
               $("#total_"+unid).val(totalnew);
            }
            console.log(totalnew);
          }
		}
		function getvalidvalueloan(id){
			var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
			var idsplit=id.split("_");
			var unid=idsplit[1];
			var deposit=$("#deposit_"+unid).val();
			
			if(deposit=="" || deposit==null){
				deposit=0;
			}
			console.log(deposit);
			var loan=$("#loan_"+unid).val();
			var total=0;
			if(loan=="" || loan==null){
				loan=0;
				total=parseFloat(deposit)+parseFloat(loan);
            	var totalnew=parseFloat(total.toFixed(2));
               $("#total_"+unid).val(totalnew);
				
			}else{
			if (!loan.match(currency_regx) ) {
              //alert('please enter proper value');
           // return false;
             
           
            }else{
            	total=parseFloat(deposit)+parseFloat(loan);
            	var totalnew=parseFloat(total.toFixed(2));
               $("#total_"+unid).val(totalnew);
            }
           }
            console.log(totalnew);
		}
		
		
</script>
