<?php $this->load->view('newaccounts/list_style.php'); ?>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        View List
        <small>List</small> &nbsp;<a href="<?php echo base_url(); ?>manage_accounts/NewAccounts/addNewaccounts"  class="btn btn-danger">Add New Customer</a>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Manage Accounts</a></li>
        <li class="active">List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
        	<?php if(isset($listmsg) && !empty($listmsg)){ echo $listmsg; }  ?>
          <div class="box box-primary">
            <div class="box-header">
              <!--<h3 class="box-title">Data Table With Full Features</h3>-->
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow: scroll;">
              <table id="example1" class="table table-bordered table-striped" >
                <thead>
                <tr>
                  <th>Sl No.</th>
                  <th>Accno</th>
                  <th>Name</th>
                  <th>DOB</th>
                  <th>Contact info</th>
                  <th>Nominee/<br>Joint Holder</th>
                  <th>Status</th>
                  <th>view</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                		if(isset($viewaccounts) && !empty($viewaccounts)){
                			$sl=1;
                			foreach($viewaccounts as $value){
                				$accid=$value->id;
                  ?>
                  <tr>
                  		<td><?php echo $sl; ?></td>
                  		<td><?php echo "<b>".$value->accno."</b>"; ?></td>
                  		<td><?php 
                  				$fname=$value->first_name; 
                  				$mname=$value->middle_name;
                  				$lname=$value->last_name; 
                  			   echo  $fullname="<b>".$fname." ".$mname." ".$lname."</b>";
                  			
                  			?>
                  		</td>
                  		<td><?php echo $value->dob; ?></td>
                  		<td><?php 
                  				  print_r(master_accounts_contact_info($accid));
								  if(!empty($value->mobile)){
						          	echo "<b<i class='fa fa-phone'></i></b> ".$value->mobile;
								  }
								  if(!empty($value->father_husband_name)){
						          	echo "<br><b>F/H:</b> ".$value->father_husband_name;
								  }
								  if(!empty($value->father_husband_name)){
						          	echo "<br><b>M:</b> ".$value->father_husband_name;
								  }
						     ?>
						</td>
                  		<td>
                  			<?php
                  			    if(!empty($value->joint_holder1)){
                  					echo "<b>JH1</b>: ".$value->joint_holder1;
								}
								if(!empty($value->joint_holder1)){
                  					echo "<br><b>JH2</b>: ".$value->joint_holder2;
								}
								if(!empty($value->nominee)){
                  					echo "<br><b>N</b>: ".$value->nominee;
								}
								if(!empty($value->relation_nominee)){
                  					echo "<br><b>R</b>: ".$value->relation_nominee;
								}
                  			
                  			?>
                  		</td>
                  		<td><?php 
                  		       /*
							    * if st==0 account not acivate
							    * if st==1 account acivate
							    * if st==2 account account suspend
							    * if st==3 account completed
							    */
							    //get user group
							    //$usergroup=get_user_group($this->session->userdata('user_id'));
							    $user_group=$this->session->userdata('user_group');
                  				if(($value->status)==0){
                  					echo '<span class="label label-warning">Pending..</span>';
                  				} 
								if(($value->status)==1){
                  					echo '<span class="label label-success">Activate</span>';
                  				} 
								if(($value->status)==2){
                  					echo '<span class="label label-danger">Suspend</span>';
                  				} 
								if(($value->status)==3){
                  					echo '<span class="label label-info">Completed</span>';
                  				}
                  			?></td>
                  		<td>
                  			<a class="btn btn-app" data-toggle="modal" data-target="#modal-rd_<?php echo $sl; ?>" >
				                <img src="<?php echo base_url(); ?>assets/image/rd.jpg" style="width:25px;height:25px;">
				            </a>
				            <!--- get Rd Account modal  ------>
				            	<div class="modal fade" id="modal-rd_<?php echo $sl; ?>">
						          <div class="modal-dialog">
						            <div class="modal-content">
						              <div class="modal-header">
						                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						                  <span aria-hidden="true">&times;</span></button>
						                <h4 class="modal-title">RD Account info of Account No- <?php echo $value->accno;  ?></h4>
						              </div>
						              <div class="modal-body">
						                <?php
						                 //get rd accounts details info
						                 $rdacoountsinfo=get_rd_accounts_info($accid);
						               // print_r($rdacoountsinfo);
						                ?>
										<div class="row">
									        <div class="col-md-12">
									          <div class="box">
									            <div class="box-header with-border">
									              <h3 class="box-title"> Details info</h3>
									            </div>
									            <!-- /.box-header -->
									            <div class="box-body">
									              <table class="table table-bordered">
									                
									                <tr>
									                  <td><strong>Acc No</strong></td>
									                  <td><?php if(isset($rdacoountsinfo[0]->accno) && !empty($rdacoountsinfo[0]->accno)){echo $rdacoountsinfo[0]->accno; } ?></td>
									                  <td><strong>Op. Date</strong></td>
									                  <td><?php if(isset($rdacoountsinfo[0]->opening_date) && !empty($rdacoountsinfo[0]->opening_date)){echo $rdacoountsinfo[0]->opening_date; } ?></td>
									                </tr>
									                <tr>
									                  <td><strong>Op. Bal.</strong></td>
									                  <td><?php if(isset($rdacoountsinfo[0]->opening_balance) && !empty($rdacoountsinfo[0]->opening_balance)){echo $rdacoountsinfo[0]->opening_balance; } ?></td>
									                  <td><strong>Daily. Inst.</strong></td>
									                  <td><?php if(isset($rdacoountsinfo[0]->monthly_installment) && !empty($rdacoountsinfo[0]->monthly_installment)){echo $rdacoountsinfo[0]->monthly_installment; } ?></td>
									                </tr>
									                <tr>
									                  <td><strong>Interest(%)</strong></td>
									                  <td><?php if(isset($rdacoountsinfo[0]->interest_rate) && !empty($rdacoountsinfo[0]->interest_rate)){echo $rdacoountsinfo[0]->interest_rate; } ?></td>
									                  <td><strong>Period</strong></td>
									                  <td><?php if(isset($rdacoountsinfo[0]->period) && !empty($rdacoountsinfo[0]->period)){echo $rdacoountsinfo[0]->period." Mnths"; } ?></td>
									                </tr>
									                <tr>
									                  <td><strong>Mat. Date</strong></td>
									                  <td><?php if(isset($rdacoountsinfo[0]->maturity_date) && !empty($rdacoountsinfo[0]->maturity_date)){echo $rdacoountsinfo[0]->maturity_date; } ?></td>
									                  <td><strong>DOE</strong></td>
									                  <td><?php if(isset($rdacoountsinfo[0]->doe) && !empty($rdacoountsinfo[0]->doe)){echo $rdacoountsinfo[0]->doe; } ?></td>
									                </tr>
									                <tr>
									                  <td><strong>Status</strong></td>
									                  <td>
									                  	<?php
										                  		/*
															    * if st==0 account not acivate
															    * if st==1 account acivate
															    * if st==2 account account suspend
															    * if st==3 account completed
															    */
															    //get user group
															    //$usergroup=get_user_group($this->session->userdata('user_id'));
															    //$user_group=$this->session->userdata('user_group');
								                  				if((($rdacoountsinfo[0]->status)==0)){
								                  					echo '<span class="label label-warning">Pending..</span>';
								                  				} 
																if( (($rdacoountsinfo[0]->status)==1)){
								                  					echo '<span class="label label-success">Activate</span>';
								                  				} 
																if((($rdacoountsinfo[0]->status)==2)){
								                  					echo '<span class="label label-danger">Suspend</span>';
								                  				} 
																if( (($rdacoountsinfo[0]->status)==3)){
								                  					echo '<span class="label label-info">Completed</span>';
								                  				}
								
								                         ?>
									                  	
									                  </td>
									                  <td></td>
									                  <td></td>
									                </tr>
									              </table>
									            </div>
									            <!-- /.box-body -->
									            
									          </div>
									          <!-- /.box -->
									
									          
									          <!-- /.box -->
									        </div>
									        <!-- /.col -->
									        
									        <!-- /.col -->
									      </div>
						              </div>
						              <div class="modal-footer">
						                <button type="button" class="btn btn-primary pull-left" data-dismiss="modal">Close</button>
						                <!--<button type="button" class="btn btn-primary">Save changes</button>-->
						              </div>
						            </div>
						            <!-- /.modal-content -->
						          </div>
						          <!-- /.modal-dialog -->
						        </div>
				            <!------ End of modal  ---->
				            <a class="btn btn-app" data-toggle="modal" data-target="#modal-loan_<?php echo $sl; ?>">
				                <img src="<?php echo base_url(); ?>assets/image/emi.jpg" style="width:25px;height:25px;">
				            </a>
				            <!--- get Rd Account modal  ------>
				            	<div class="modal fade" id="modal-loan_<?php echo $sl; ?>">
						          <div class="modal-dialog">
						            <div class="modal-content">
						              <div class="modal-header">
						                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						                  <span aria-hidden="true">&times;</span></button>
						                <h4 class="modal-title">Loan Account info of Account No- <?php echo $value->accno;  ?></h4>
						              </div>
						              <div class="modal-body">
						              	<?php
						                 //get rd accounts details info
						                 $loanacoountsinfo=get_loan_accounts_info($accid);
						               // print_r($rdacoountsinfo);
						                ?>
						                <div class="row">
									        <div class="col-md-12">
									          <div class="box">
									            <div class="box-header with-border">
									              <h3 class="box-title"> Details info</h3>
									            </div>
									            <!-- /.box-header -->
									            <div class="box-body">
									              <table class="table table-bordered">
									                
									                <tr>
									                  <td><strong>Acc No</strong></td>
									                  <td><?php if(isset($loanacoountsinfo[0]->accno) && !empty($loanacoountsinfo[0]->accno)){echo $loanacoountsinfo[0]->accno; } ?></td>
									                  <td><strong>Op. Date</strong></td>
									                  <td><?php if(isset($loanacoountsinfo[0]->loan_date) && !empty($loanacoountsinfo[0]->loan_date)){echo $loanacoountsinfo[0]->loan_date; } ?></td>
									                </tr>
									                <tr>
									                  <td><strong>Loan Amount</strong></td>
									                  <td><?php if(isset($loanacoountsinfo[0]->loan_amount) && !empty($loanacoountsinfo[0]->loan_amount)){echo $loanacoountsinfo[0]->loan_amount; } ?></td>
									                  <td><strong>Mnth. Inst.</strong></td>
									                  <td><?php if(isset($loanacoountsinfo[0]->monthly_installment) && !empty($loanacoountsinfo[0]->monthly_installment)){echo $loanacoountsinfo[0]->monthly_installment; } ?></td>
									                </tr>
									                <tr>
									                  <td><strong>Interest(%)</strong></td>
									                  <td><?php if(isset($loanacoountsinfo[0]->interest_rate) && !empty($loanacoountsinfo[0]->interest_rate)){echo $loanacoountsinfo[0]->interest_rate; } ?></td>
									                  <td><strong>Period</strong></td>
									                  <td><?php if(isset($loanacoountsinfo[0]->period) && !empty($loanacoountsinfo[0]->period)){echo $loanacoountsinfo[0]->period." Mnths"; } ?></td>
									                </tr>
									                <tr>
									                  <td><strong>Adjust Date</strong></td>
									                  <td><?php if(isset($loanacoountsinfo[0]->loan_adjust_date) && !empty($loanacoountsinfo[0]->loan_adjust_date)){echo $loanacoountsinfo[0]->loan_adjust_date; } ?></td>
									                  <td><strong>DOE</strong></td>
									                  <td><?php if(isset($loanacoountsinfo[0]->doe) && !empty($loanacoountsinfo[0]->doe)){echo $loanacoountsinfo[0]->doe; } ?></td>
									                </tr>
									                <tr>
									                  <td><strong>Status</strong></td>
									                  <td>
									                  	<?php
										                  		/*
															    * if st==0 account not acivate
															    * if st==1 account acivate
															    * if st==2 account account suspend
															    * if st==3 account completed
															    */
															    //get user group
															    //$usergroup=get_user_group($this->session->userdata('user_id'));
															    //$user_group=$this->session->userdata('user_group');
								                  				if((($loanacoountsinfo[0]->status)==0)){
								                  					echo '<span class="label label-warning">Pending..</span>';
								                  				} 
																if( (($loanacoountsinfo[0]->status)==1)){
								                  					echo '<span class="label label-success">Activate</span>';
								                  				} 
																if((($loanacoountsinfo[0]->status)==2)){
								                  					echo '<span class="label label-danger">Suspend</span>';
								                  				} 
																if( (($loanacoountsinfo[0]->status)==3)){
								                  					echo '<span class="label label-info">Completed</span>';
								                  				}
								
								                         ?>
									                  	
									                  </td>
									                  <td></td>
									                  <td></td>
									                </tr>
									              </table>
									            </div>
									            <!-- /.box-body -->
									            
									          </div>
									          <!-- /.box -->
									
									          
									          <!-- /.box -->
									        </div>
									        <!-- /.col -->
									        
									        <!-- /.col -->
									      </div>
						              </div>
						              <div class="modal-footer">
						                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
						                <button type="button" class="btn btn-primary">Save changes</button>
						              </div>
						            </div>
						            <!-- /.modal-content -->
						          </div>
						          <!-- /.modal-dialog -->
						        </div>
				            <!------ End of modal  ---->
                  		</td>
                  		<td>
                  			<div class="btn-group">
			                  <button type="button" class="btn btn-success">Action</button>
			                  <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
			                    <span class="caret"></span>
			                    <span class="sr-only">Toggle Dropdown</span>
			                  </button>
			                  <ul class="dropdown-menu" role="menu">
			                    <li><a href="<?php echo base_url();  ?>manage_accounts/NewAccounts/edit/<?php echo $value->accno;  ?>"><i class="fa fa-edit"></i> Edit</a></li>
			                    <li><a href="<?php echo base_url();  ?>manage_accounts/NewAccounts/delete/<?php echo $value->accno;  ?>" onclick="return confirm('Are you sure you want to delete?');"><i class="fa fa-trash"></i> Delete</a></li>
			                    
			                  </ul>
			                </div>
                  			
                  		</td>
                  		
                  </tr>
                
                <?php
					$sl++;	}}
                ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Sl No.</th>
                  <th>Accno</th>
                  <th>Name</th>
                  <th>DOB</th>
                  <th>Contact info</th>
                  <th>Nominee/<br>Joint Holder</th>
                  <th>Status</th>
                  <th>view</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
   <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php $this->load->view('newaccounts/list_script.php');  ?>
