<?php $this->load->view('newaccounts/newaccounts-style.php'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        New Accounts
        <small>Add</small> &nbsp;<a href="<?php echo base_url(); ?>manage_accounts/NewAccounts/list_view"  class="btn btn-danger">View List</a>
      </h1>
       
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Manage Accounts</a></li>
        <li><a href="#">New Accounts</a></li>
        <li class="active">Add</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Personal Information</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form <?php if(isset($account) && !empty($account)){ ?> action="<?php echo base_url(); ?>manage_accounts/NewAccounts/update_master_entry" <?php }else{ ?>action="<?php echo base_url(); ?>manage_accounts/NewAccounts/save_master_entry" <?php } ?> method="post" enctype="multipart/form-data">
            <div class="form-horizontal">
              <div class="box-body">
                <div class="form-group">
                  <label for="First Name" class="col-sm-3 control-label">First Name <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="fn" placeholder="First Name" name="first_name" value="<?php if(isset($personalinfo[0]->first_name) && !empty($personalinfo[0]->first_name)){ echo $personalinfo[0]->first_name ;} ?>">
                    <input type="hidden" name="accnoid" value="<?php if(isset($account) && !empty($account)){ echo $account; }  ?>" />
                    <span class="help-block" id="error_firstname"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Middle Name" class="col-sm-3 control-label">Middle Name </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="mn" placeholder="Middle Name" name="middle_name" value="<?php if(isset($personalinfo[0]->middle_name) && !empty($personalinfo[0]->middle_name)){ echo $personalinfo[0]->middle_name ;} ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="Last Name" class="col-sm-3 control-label">Last Name <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="ln" placeholder="Last Name" name="last_name" value="<?php if(isset($personalinfo[0]->last_name) && !empty($personalinfo[0]->last_name)){ echo $personalinfo[0]->last_name ;} ?>">
                    <span class="help-block" id="error_lastname"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="DOB" class="col-sm-3 control-label">DOB <span class="text-red">*</span></label>

                  <div class="col-sm-9">
	                    <div class="input-group date">
	                  <div class="input-group-addon">
	                    <i class="fa fa-calendar"></i>
	                  </div>
	                  <input type="text" class="form-control pull-right" id="datepicker" name="dob" readonly="readonly" value="<?php if(isset($personalinfo[0]->dob) && !empty($personalinfo[0]->dob)){ echo $personalinfo[0]->dob ;} ?>">
	                  
	                </div>
	                <span class="help-block" id="error_dob"></span>
                  </div>
                </div>
                <div class="form-group">
	                <label for="Nationality" class="col-sm-3 control-label">Nationality </label>
	                <div class="col-sm-9">
		                <select id="nationality" class="form-control select2" style="width: 100%;" name="nationality">
		                  <option value="Indian"  <?php if(isset($personalinfo[0]->nationality) && !empty($personalinfo[0]->nationality)){ if($personalinfo[0]->nationality =="Indian"){ echo "Selected";} }?>>Indian</option>
		                  <option value="Others" <?php if(isset($personalinfo[0]->nationality) && !empty($personalinfo[0]->nationality)){ if($personalinfo[0]->nationality =="Others"){ echo "Selected";} }?>>Others</option>
		                  
		                </select>
		                 <span class="help-block" id="error_nationality"></span>
		               </div>
                </div>
                <div class="form-group">
                	 <label for="Nationality" class="col-sm-3 control-label">Gender </label>
	                <div class="col-sm-9">
		                <label>
		                  <input type="radio" <?php if(isset($account) && !empty($account)){  }{ echo "checked" ;}  ?> name="gender" class="flat-red" value="Male" <?php if(isset($personalinfo[0]->gender) && !empty($personalinfo[0]->gender)){ if($personalinfo[0]->gender =="Male"){ echo "Checked";} }?>  >
		                  Male &nbsp;
		                </label>
		                
		                <label>
		                  <input type="radio" name="gender" class="flat-red" value="Female" <?php if(isset($personalinfo[0]->gender) && !empty($personalinfo[0]->gender)){ if($personalinfo[0]->gender =="Female"){ echo "Checked";} }?> >
		                  Female &nbsp;
		                </label>
		                <label>
		                  <input type="radio" name="gender" class="flat-red" value="Others" <?php if(isset($personalinfo[0]->gender) && !empty($personalinfo[0]->gender)){ if($personalinfo[0]->gender =="Others"){ echo "Checked";} }?>  >
		                  Others &nbsp;
		                </label>
		                <span class="help-block" id="error_gender"></span>
	                </div>
              </div>
               <div class="form-group">
                  <label for="Mobile" class="col-sm-3 control-label">Mobile <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" name="mobile" class="form-control" id="mobile" placeholder="Enter Mobile No " value="<?php if(isset($personalinfo[0]->mobile) && !empty($personalinfo[0]->mobile)){ echo $personalinfo[0]->mobile ;} ?>">
                    <span class="help-block" id="error_mobile"></span>
                  </div>
                </div>
              
              <div class="form-group">
                  <label for="Father's Name" class="col-sm-3 control-label">Father's/Husband Name</label>

                  <div class="col-sm-9">
                    <input type="text" name="fatthern" class="form-control" id="father" placeholder="Fathers Name" value="<?php if(isset($personalinfo[0]->father_husband_name) && !empty($personalinfo[0]->father_husband_name)){ echo $personalinfo[0]->father_husband_name ;} ?>">
                    <span class="help-block" id="error_father"></span>
                  </div>
              </div>
              
              <div class="form-group">
                  <label for="Mother's Name" class="col-sm-3 control-label">Mother's Name</label>

                  <div class="col-sm-9">
                    <input type="text" name="mothern" class="form-control" id="mother" placeholder="Mothers Name" value="<?php if(isset($personalinfo[0]->mother_name) && !empty($personalinfo[0]->mother_name)){ echo $personalinfo[0]->mother_name ;} ?>">
                    <span class="help-block" id="error_mother"></span>
                  </div>
              </div>
              
              <div class="form-group">
                	 <label for="Nationality" class="col-sm-3 control-label">Maritorial Status </label>
	                <div class="col-sm-9">
		                <label>
		                  <input type="radio"  name="mstatus" class="flat-red" value="Yes" <?php if(isset($personalinfo[0]->maritorial_status) && !empty($personalinfo[0]->maritorial_status)){ if($personalinfo[0]->maritorial_status =="Yes"){ echo "Checked";} }?>  >
		                  Yes &nbsp;
		                </label>
		                
		                <label>
		                  <input type="radio" <?php if(isset($account) && !empty($account)){  }{ echo "checked" ;}  ?> name="mstatus" class="flat-red" value="No" <?php if(isset($personalinfo[0]->maritorial_status) && !empty($personalinfo[0]->maritorial_status)){ if($personalinfo[0]->maritorial_status =="No"){ echo "Checked";} }?>>
		                  No &nbsp;
		                </label>
		                <label>
		                  <input type="radio" name="mstatus" class="flat-red" value="Others" <?php if(isset($personalinfo[0]->maritorial_status) && !empty($personalinfo[0]->maritorial_status)){ if($personalinfo[0]->maritorial_status =="Others"){ echo "Checked";} }?> >
		                  Others &nbsp;
		                </label>
		                <span class="help-block" id="error_gender"></span>
	                </div>
              </div>
              
              
              
              <div class="form-group">
                  <label for="Joint Holder" class="col-sm-3 control-label">Joint Holder 1</label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="join1" id="join1" placeholder="Joint Holder Name(if any)" value="<?php if(isset($personalinfo[0]->joint_holder1) && !empty($personalinfo[0]->joint_holder1)){ echo $personalinfo[0]->joint_holder1 ;} ?>">
                    <span class="help-block" id="error_join1"></span>
                  </div>
              </div>
              
              <div class="form-group">
                  <label for="Joint Holder" class="col-sm-3 control-label">Joint Holder 2</label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="join2" id="join2" placeholder="Joint Holder Name(if any)" value="<?php if(isset($personalinfo[0]->joint_holder2) && !empty($personalinfo[0]->joint_holder2)){ echo $personalinfo[0]->joint_holder2 ;} ?>">
                    <span class="help-block" id="error_join2"></span>
                  </div>
              </div>
              
              <div class="form-group">
                  <label for="Nominee" class="col-sm-3 control-label">Nominee</label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="nominee" id="nominee" placeholder="Nominee Name(if any)" value="<?php if(isset($personalinfo[0]->nominee) && !empty($personalinfo[0]->nominee)){ echo $personalinfo[0]->nominee ;} ?>">
                    <span class="help-block" id="error_nominee"></span>
                  </div>
              </div>
              
              <div class="form-group">
                  <label for="Relation with Nominee" class="col-sm-3 control-label">Relation with Nominee</label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="rnominee" name="rnominee" placeholder="Relation with Nominee " value="<?php if(isset($personalinfo[0]->relation_nominee) && !empty($personalinfo[0]->relation_nominee)){ echo $personalinfo[0]->relation_nominee ;} ?>">
                    <span class="help-block" id="error_rnominee"></span>
                  </div>
              </div>
              
              
              </div>
              <!-- /.box-body -->
             </div>
              <!-- /.box-footer -->
              <div class="box-header with-border">
              <h3 class="box-title">Contact Information</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
           <div class="form-horizontal">
              <div class="box-body">
                <div class="form-group">
                  <label for="Address" class="col-sm-3 control-label">Address <span class="text-red">*</span> </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="address" id="address" placeholder="Address " value="<?php if(isset($contactinfo[0]->address) && !empty($contactinfo[0]->address)){ echo $contactinfo[0]->address ;} ?>">
                    <span class="help-block" id="error_address"></span>
                  </div>
                </div>
                
                
                <?php $query=$this->db->query("select * from state_list  order by id desc"); ?>
				<?php  $res=$query->result(); ?>
                
                <div class="form-group">
	                <label for="State" class="col-sm-3 control-label">State </label>
	                <div class="col-sm-9">
		                <select  id ="state" class="form-control select2" style="width: 100%;" name="state">
						<?php if(isset($res) && !empty($res)){ ?>
							<?php foreach($res as $val){ ?>
								<option  value="<?php echo $val->state; ?>" <?php if(isset($contactinfo[0]->state) && !empty($contactinfo[0]->state)){ if($contactinfo[0]->state==$val->state){echo "Selected"; } } ?>><?php echo $val->state; ?></option>
		                  
							<?php } } ?> 
		                </select>
		                <span class="help-block" id="error_state"></span>
		               </div>
                </div>
                <?php  if(isset($account) && !empty($account)){?>
                <?php  $query2=$this->db->query("select * from cities ");  ?>
                <?php }else{  ?>
                <?php $query2=$this->db->query("select * from cities where UCASE(city_state) like '%WEST BENGAL%'"); ?>
                <?php } ?>
				<?php  $res2=$query2->result(); ?>
                <div class="form-group">
	                <label for="District" class="col-sm-3 control-label">District </label>
	                <div class="col-sm-9">
		                <select id="district" class="form-control select2" style="width: 100%;" name="district">
		                 <?php if(isset($res2) && !empty($res2)){ ?>
							<?php foreach($res2 as $val2){ ?>
							    <?php if($val2->city_name=="Howrah"){ ?>
								      <option  value="<?php echo $val2->city_name; ?>" <?php if(isset($account) && !empty($account)){}else{ echo "selected" ;} ?> <?php if(isset($contactinfo[0]->district) && !empty($contactinfo[0]->district)){ if($contactinfo[0]->district==$val2->city_name){echo "Selected"; } } ?>><?php echo $val2->city_name; ?></option>
							    <?php }else{ ?> 
								      <option  value="<?php echo $val2->city_name; ?>" <?php if(isset($contactinfo[0]->district) && !empty($contactinfo[0]->district)){ if($contactinfo[0]->district==$val2->city_name){echo "Selected"; } } ?> ><?php echo $val2->city_name; ?></option>
								<?php  } ?>
		                  
							<?php } } ?> 
		                  
		                </select>
		                <span class="help-block" id="error_district"></span>
		               </div>
                </div>
                
                <div class="form-group">
                  <label for="Pincode" class="col-sm-3 control-label">Pincode <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" name="pincode" class="form-control" id="pincode" placeholder="Enter Pincode " value="<?php if(isset($contactinfo[0]->pincode) && !empty($contactinfo[0]->pincode)){ echo $contactinfo[0]->pincode ;} ?>">
                    <span class="help-block" id="error_pincode"></span>
                  </div>
                </div>
                
                
               
                
                
              </div>
              <!-- /.box-body -->
              </div>
             
            
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
          
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">
          <!-- Horizontal Form -->
          <div class="box box-danger">
            
           <?php $query3=$this->db->query("select * from account_master where status='1'"); ?>
			<?php  $res3=$query3->result(); ?>
            <div class="box-header with-border">
              <h3 class="box-title">Recurring Account Information</h3>
            </div>
             <div class="form-horizontal">
              <div class="box-body">
                <div class="form-group">
	                <label for="Account type" class="col-sm-3 control-label">Account type <span class="text-red">*</span></label>
	                <div class="col-sm-9">
		                <select id="acctype" class="form-control select2" style="width: 100%;" name="acctype">
		                  <?php if(isset($res3) && !empty($res3)){ ?>
							<?php foreach($res3 as $val3){ ?>
							    
								      <option  value="<?php echo $val3->id; ?>"><?php echo $val3->code; ?></option>
							    
		                  
							<?php } } ?> 
		                  
		                </select>
		                <span class="help-block" id="error_acctype"></span>
		               </div>
                </div>
                <div class="form-group">
                  <label for="Account No" class="col-sm-3 control-label">Account No <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="accno" id="accno" placeholder="Account No " value="<?php if(isset($rdaccountinfo[0]->accno) && !empty($rdaccountinfo[0]->accno)){ echo $rdaccountinfo[0]->accno ;} ?>" <?php if(isset($account)&& !empty($account)){ echo "readonly"; } ?>>
                    <span class="help-block" id="error_accno"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Opening Balance" class="col-sm-3 control-label">Opening Balance <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="opbalance" placeholder="Opening Balance " name="opbalance" value="<?php if(isset($rdaccountinfo[0]->opening_balance) && !empty($rdaccountinfo[0]->opening_balance)){ echo $rdaccountinfo[0]->opening_balance ;} ?>">
                    <span class="help-block" id="error_opbalance"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="opdate" class="col-sm-3 control-label">Opening Date <span class="text-red">*</span></label>

                  <div class="col-sm-9">
	                    <div class="input-group date">
	                  <div class="input-group-addon">
	                    <i class="fa fa-calendar"></i>
	                  </div>
	                  <input type="text" class="form-control pull-right" id="datepicker2" name="opdate" readonly="readonly" value="<?php if(isset($rdaccountinfo[0]->opening_date) && !empty($rdaccountinfo[0]->opening_date)){ echo $rdaccountinfo[0]->opening_date ; } ?>" >
	                  
	                </div>
	                <span class="help-block" id="error_opdate"></span>
                  </div>
                </div>
                
                
                
                
                <div class="form-group">
                  <label for="Monthly Installment" class="col-sm-3 control-label">Daily Installment <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="mi" id="mi" placeholder="Daily Installment " value="<?php if(isset($rdaccountinfo[0]->monthly_installment) && !empty($rdaccountinfo[0]->monthly_installment)){ echo $rdaccountinfo[0]->monthly_installment ; } ?>" >
                    <span class="help-block" id="error_mi"></span>
                  </div>
                </div>
                <?php $query4=$this->db->query("select * from trem_master where status='1'"); ?>
			    <?php  $res4=$query4->result(); ?>
                <div class="form-group">
	                <label for="Account type" class="col-sm-3 control-label">Period <span class="text-red">*</span></label>
	                <div class="col-sm-9">
		                <select id="term" class="form-control select2" style="width: 100%;" name="period" >
		                  <?php if(isset($res4) && !empty($res4)){ ?>
		                  	          <option  value="">Select Any Term</option>
							<?php foreach($res4 as $val4){ ?>
							    
								      <option  value="<?php echo $val4->term; ?>" <?php if(isset($rdaccountinfo[0]->period) && !empty($rdaccountinfo[0]->period)){ if($rdaccountinfo[0]->period==$val4->term){echo "Selected"; } } ?>> <?php echo $val4->term." ".$val4->termunit ; ?></option>
							    
		                  
							<?php } } ?> 
		                </select>
		                <span class="help-block" id="error_term"></span>
		               </div>
                </div>
                <div class="form-group">
                  <label for="Interest Rate" class="col-sm-3 control-label">Interest Rate(%) <span class="text-red">*</span></label>

                  <div class="col-sm-9">
                    <input type="text" name="interest" class="form-control" id="interest" placeholder="Interest Rate(%) " value="<?php if(isset($rdaccountinfo[0]->interest_rate) && !empty($rdaccountinfo[0]->interest_rate)){ echo $rdaccountinfo[0]->interest_rate ; } ?>"  >
                    <span class="help-block" id="error_interest"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Interest Rate" class="col-sm-3 control-label">Maturity Date </label>

                  <div class="col-sm-9">
                    <input type="text" name="mtdate" class="form-control" id="mtdate" placeholder="Matiruty Date " readonly="readonly" value="<?php if(isset($rdaccountinfo[0]->maturity_date) && !empty($rdaccountinfo[0]->maturity_date)){ echo $rdaccountinfo[0]->maturity_date ; } ?>" >
                    <span class="help-block" id="error_mdtate"></span>
                  </div>
                </div>
                
                <!---<div class="form-group">
                  <label for="Interest Rate" class="col-sm-3 control-label">Maturity Amount </label>

                  <div class="col-sm-9">
                    <input type="text" name="mtamount" class="form-control" id="mtamount" placeholder="Matiruty Amount " readonly="readonly">
                    <span class="help-block" id="error_mtamount"></span>
                  </div>
                </div>-->
                
                <!--<div class="form-group">
                  <label for="Image" class="col-sm-3 control-label">Add Image</label>

                  <div class="col-sm-9">
                    <input type="file" class="form-control" id="image" name="image">
                    <img id="blah" src="<?php echo base_url(); ?>assets/image/profile/profile.jpg" alt="your image" style="width:100px;height:100px;" />


                  </div>
                </div> -->
                
                
               <div class="box-header with-border">
	              <h3 class="box-title">Loan Account Information</h3>
	           </div>
	           &nbsp;
	          <div class="form-group">
                  <label for="Opening Balance" class="col-sm-3 control-label">Loan Amount </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="loanamount" placeholder="Loan Amount " name="loanamount" value="<?php if(isset($loanaccountinfo[0]->loan_amount) && !empty($loanaccountinfo[0]->loan_amount)){ echo $loanaccountinfo[0]->loan_amount ;} ?>">
                    <span class="help-block" id="error_loanamount"></span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="opdate" class="col-sm-3 control-label">Loan Date </label>

                  <div class="col-sm-9">
	                    <div class="input-group date">
	                  <div class="input-group-addon">
	                    <i class="fa fa-calendar"></i>
	                  </div>
	                  <input type="text" class="form-control pull-right" id="datepicker3" name="loandate" readonly="readonly" value="<?php if(isset($loanaccountinfo[0]->loan_date) && !empty($loanaccountinfo[0]->loan_date)){ echo $loanaccountinfo[0]->loan_date ;} ?>" >
	                  
	                </div>
	                <span class="help-block" id="error_loandate"></span>
                  </div>
                </div>
                
                <?php $query5=$this->db->query("select * from trem_master where status='1'"); ?>
			    <?php  $res5=$query5->result(); ?>
                <div class="form-group">
	                <label for="Account type" class="col-sm-3 control-label">Loan Term </label>
	                <div class="col-sm-9">
		                <select id="loanterm" class="form-control select2" style="width: 100%;" name="loanterm" >
		                  <?php if(isset($res5) && !empty($res5)){ ?>
		                  	          <option  value="">Select Any Term</option>
							<?php foreach($res5 as $val5){ ?>
							    
								      <option  value="<?php echo $val5->term; ?>" <?php if(isset($loanaccountinfo[0]->period) && !empty($loanaccountinfo[0]->period)){ if($loanaccountinfo[0]->period==$val5->term){echo "Selected"; } } ?>><?php echo $val5->term." ".$val5->termunit ; ?></option>
							    
		                  
							<?php } } ?> 
		                </select>
		                <span class="help-block" id="error_loanterm"></span>
		               </div>
                </div>
                
                 <?php $query6=$this->db->query("select * from interest_calculate where status='1'"); ?>
			    <?php  $res6=$query6->result(); ?>
                <div class="form-group">
	                <label for="Account type" class="col-sm-3 control-label">Interest Calculate? </label>
	                <div class="col-sm-9">
		                <select id="interestcalculation" class="form-control select2" style="width: 100%;" name="interest_calculate" >
		                  <?php if(isset($res6) && !empty($res6)){ ?>
		                  	          
							<?php foreach($res6 as $val6){ ?>
							    
								      <option  value="<?php echo $val6->name; ?>" <?php if(isset($loanaccountinfo[0]->interest_calculate) && !empty($loanaccountinfo[0]->interest_calculate)){ if($loanaccountinfo[0]->interest_calculate==$val6->name){echo "Selected"; } } ?>><?php echo $val6->name ; ?></option>
							    
		                  
							<?php } } ?> 
		                </select>
		                <span class="help-block" id="error_interest_calculation"></span>
		               </div>
                </div>
                
                
                
                <div class="form-group">
                  <label for="Interest Rate" class="col-sm-3 control-label">Interest Rate(%) </label>

                  <div class="col-sm-9">
                    <input type="text" name="loaninterest" class="form-control" id="loaninterest" placeholder="Loan Interest Rate(%) " value="<?php if(isset($loanaccountinfo[0]->interest_rate) && !empty($loanaccountinfo[0]->interest_rate)){ echo $loanaccountinfo[0]->interest_rate ; } ?>" >
                    <span class="help-block" id="error_loaninterest"></span>
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="Monthly Installment" class="col-sm-3 control-label">Monthly Interest </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="miloan" id="miloan" placeholder="Monthly Installment " value="<?php if(isset($loanaccountinfo[0]->monthly_installment) && !empty($loanaccountinfo[0]->monthly_installment)){ echo $loanaccountinfo[0]->monthly_installment ; } ?>"  >
                    <span class="help-block" id="error_miloan"></span>
                  </div>
                </div>
                
                <div class="form-group" id="insrate_new">
                  <label for="Insurance Rate" class="col-sm-3 control-label">Insurance Rate(%) </label>

                  <div class="col-sm-9">
                    <input type="number" min="1"  step=any class="form-control" name="insrate" id="insrate" placeholder="Insurance Rate" value="<?php if(isset($insurance_master[0]->insurance_rate)){ echo $insurance_master[0]->insurance_rate; }else{ echo 1; } ?>"  >
                    <span class="help-block" id="error_insrate"></span>
                  </div>
                </div>
                <div class="form-group" id="insamount_new">
                  <label for="Insurance Rate" class="col-sm-3 control-label">Insurance Amount </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="insamount" id="insamount" placeholder="Insurance Amount" value="<?php  if(isset($insurance_master[0]->insurance_amount)){ echo $insurance_master[0]->insurance_amount; } ?>" readonly >
                    <span class="help-block" id="error_insamount"></span>
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="Insurance Rate" class="col-sm-3 control-label">Adjustment Date </label>

                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="adjust" id="adjust" placeholder="Adjustment date" value="<?php  if(isset($loanaccountinfo[0]->loan_adjust_date)){ echo $loanaccountinfo[0]->loan_adjust_date; } ?>" readonly >
                    <span class="help-block" id="error_adjust"></span>
                  </div>
                </div>
                
              </div>
              
              
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="reset" class="btn btn-default">Cancel</button>
                <button type="submit" id="submit" class="btn btn-info pull-right"><?php if(isset($account) && !empty($account)){ echo "Update" ; }else{ echo "Submit" ;}  ?></button>
              </div>
             </div>
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
          
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- /.content-wrapper -->

  <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php //$this->load->view('newaccounts/newaccounts-script.php');  ?>
<?php $this->load->view('newaccounts/newaccounts-script.php');  ?>
<script>
  $(document).ready(function(){
	
	 
      $("#submit").click(function(event){
      var fn_regx = /^[-a-zA-Z\s]+$/;
      var phn_regx= /^[0-9]+$/;
      //var date_regx=/^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$;
      var uname_regx= /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
      var error_code=0;
      /*---------------------------------------------------------------------
      --                FISRST NAME VALIDATION
      --
      ---------------------------------------------------------------------*/
      var fn=$("#fn").val();
      if(fn==null || fn==""){
          $("#fn").closest("div").parent().addClass("has-error");
          $("#error_firstname").text("Please Enter First Name.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fn").text("");
          if (!fn.match(fn_regx) ) {
              $("#fn").closest("div").parent().addClass("has-error");
              $('#error_firstname').html(" Please Enter Valid <b>First</b> Name  Ex - Abhijit ");
              error_code++;
            //return false;
          }
          else{
            $("#fn").closest("div").parent().removeClass("has-error");

            $("#error_firstname").text("");
          }


        }


      /*---------------------------------------------------------------------
      --                LAST NAME VALIDATION
      --
      ---------------------------------------------------------------------*/
        var ln=$("#ln").val();
      if(ln==null || ln==""){
          $("#ln").closest("div").parent().addClass("has-error");
          $("#error_lastname").text("Please Enter Last Name.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           if (!ln.match(fn_regx) ) {
              $("#ln").closest("div").parent().addClass("has-error");
              $('#error_ln').html(" Please Enter Valid <b>Last Name</b> Ex - Sanyal ");
            //return false;
            error_code++;
          }
          else{
             $("#ln").closest("div").parent().removeClass("has-error");

            $("#error_ln").text("");
          }
        }
        
        /*---------------------------------------------------------------------
      --                datepicker VALIDATION error_opdate
      --
      ---------------------------------------------------------------------*/
        var datepicker=$("#datepicker").val();
      if(datepicker==null || datepicker==""){
          $("#datepicker").closest("div").parent().addClass("has-error");
          $("#error_dob").text("Please Enter DOB.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#datepicker").closest("div").parent().removeClass("has-error");

            $("#error_dob").text("");
          
        }
        
        
         /*---------------------------------------------------------------------
      --                Opening datepicker VALIDATION 
      --
      ---------------------------------------------------------------------*/
        var opdate=$("#datepicker2").val();
      if(opdate==null || opdate==""){
          $("#datepicker2").closest("div").parent().addClass("has-error");
          $("#error_opdate").text("Please Enter Opening Date");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#datepicker2").closest("div").parent().removeClass("has-error");

            $("#error_opdate").text("");
          
        }
        
           /*---------------------------------------------------------------------
      --                Term  VALIDATION 
      --
      ---------------------------------------------------------------------*/
        var term=$("#term").val();
      if(term==null || term==""){
          $("#term").closest("div").parent().addClass("has-error");
          $("#error_term").text("Please select any term");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#term").closest("div").parent().removeClass("has-error");

            $("#error_term").text("");
          
        }
        
        
		 

      /*---------------------------------------------------------------------
      --                PHONE NO VALIDATION
      --
      ---------------------------------------------------------------------*/
        var phn=$("#mobile").val();
      if(phn==null || phn==""){
          $("#mobile").closest("div").parent().addClass("has-error");
          $("#error_mobile").text("Please Enter Phone No.");
           error_code++;
          //return false;
        }
        else{
          //$("#error_phn").text("");
           if (!phn.match(phn_regx)) {
              $("#mobile").closest("div").parent().addClass("has-error");
              $('#error_mobile').html(" Please Enter valid <b>Phone No.</b> Ex - 9800XXXXXX ");
               error_code++;
            //return false;
          }
          else{
             //alert(phn.length);
             //$("#phn").closest("div").parent().removeClass("has-error");
           // $("#error_phn").text("");
              if (phn.length<10) {
                  $("#mobile").closest("div").parent().addClass("has-error");
                  $('#error_mobile').html(" Please Enter valid <b>Phone No(10 digit).</b> Ex - 9800XXXXXX ");
                   error_code++;
                //return false;
              }
              else{
                 //alert(phn.length);
                 $("#mobile").closest("div").parent().removeClass("has-error");
                $("#error_mobile").text("");
              }
          }
        }

      /*---------------------------------------------------------------------
      --                Address VALIDATION
      --
      ---------------------------------------------------------------------*/
        var address=$("#address").val();
      if(address==null || address==""){
          $("#address").closest("div").parent().addClass("has-error");
          $("#error_address").text("Please Enter Address.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#address").closest("div").parent().removeClass("has-error");

            $("#error_address").text("");
          
        }
	 /*---------------------------------------------------------------------
      --                Account type  VALIDATION
      --
      ---------------------------------------------------------------------*/
        var acctype=$("#acctype").val();
      if(acctype==null || acctype==""){
          $("#acctype").closest("div").parent().addClass("has-error");
          $("#error_acctype").text("Please Select Account type");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#acctype").closest("div").parent().removeClass("has-error");

            $("#error_acctype").text("");
          
        }
        
        /*---------------------------------------------------------------------
      --                Account No  VALIDATION
      --
      ---------------------------------------------------------------------*/
        var accno=$("#accno").val();
      if(accno==null || accno==""){
          $("#accno").closest("div").parent().addClass("has-error");
          $("#error_accno").text("Please Enter Account No.");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#accno").closest("div").parent().removeClass("has-error");

            $("#error_accno").text("");
          
        }
        
        
      /*---------------------------------------------------------------------
      --                Opening Balance validations
      --error_opbalance
      ---------------------------------------------------------------------*/
        var opbalance=$("#opbalance").val();
        var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      if(opbalance==null || opbalance==""){
          $("#opbalance").closest("div").parent().addClass("has-error");
          $("#error_opbalance").text("Please Enter Opening Balance.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!opbalance.match(currency_regx) ) {
              $("#opbalance").closest("div").parent().addClass("has-error");
              $('#error_opbalance').html(" Please Enter valid <b>Opening Balance</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#opbalance").closest("div").parent().removeClass("has-error");
            $("#error_opbalance").text("");
          }
        }
        
        /*---------------------------------------------------------------------
      --                Monthly installment validations
      --error_opbalance
      ---------------------------------------------------------------------*/
        var mi=$("#mi").val();
        //var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      if(mi==null || mi==""){
          $("#mi").closest("div").parent().addClass("has-error");
          $("#error_mi").text("Please Enter Monthly Installment.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!mi.match(currency_regx) ) {
              $("#mi").closest("div").parent().addClass("has-error");
              $('#error_mi').html(" Please Enter valid <b>Monthly Installment</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#mi").closest("div").parent().removeClass("has-error");
            $("#error_mi").text("");
          }
        }

       /*---------------------------------------------------------------------
      --                Interest rate validations
      --error_opbalance
      ---------------------------------------------------------------------*/
        var interest=$("#interest").val();
        //var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      if(interest==null || interest==""){
          $("#interest").closest("div").parent().addClass("has-error");
          $("#error_interest").text("Please Enter Interest Rate.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!interest.match(currency_regx) ) {
              $("#interest").closest("div").parent().addClass("has-error");
              $('#error_interest').html(" Please Enter valid <b>Interest Rate</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#interest").closest("div").parent().removeClass("has-error");
            $("#error_interest").text("");
          }
        }

      
     
      /*---------------------------------------------------------------------
      --                PINCODE VALIDATION
      --
      ---------------------------------------------------------------------*/
       var pin=$("#pincode").val();
      if(pin==null || pin==""){
          $("#pincode").closest("div").parent().addClass("has-error");
          $("#error_pincode").text("Please Enter Pincode.");
           error_code++;
         // return false;
        }
        else{
          //$("#error_pin").text("");
           if (!pin.match(phn_regx)) {
              $("#pincode").closest("div").parent().addClass("has-error");
              $('#error_pincode').html(" Please Enter Valid <b>PINCODE</b> Ex:-721648 ");
               error_code++;
           // return false;
          }
          else{
             //alert(phn.length);
            // $("#pin").closest("div").parent().removeClass("has-error");
            //$("#error_pin").text("");
            if (pin.length<7 ) {
                $("#pincode").closest("div").parent().addClass("has-error");
                $('#error_pincode').html(" Please Enter 7 digit <b>PINCODE</b>");
                 error_code++;
              //return false;
            }
            else{
              $("#pincode").closest("div").parent().removeClass("has-error");
              $("#error_pincode").text("");
            }

          }
        }
  
  
  /*--------------------------------  Loan Calculation---------------------------------------------  */
 
  var loanamount=$("#loanamount").val();
  var datepicker3=$("#datepicker3").val();
  var loaninterest=$("#loaninterest").val();
  var miloan=$("#miloan").val();
  var loanterm=$("#loanterm").val();
  if((loanterm==null || loanterm=="" ) && (loanamount==null || loanamount=="")&&(datepicker3==null || datepicker3=="") && (loaninterest==null || loaninterest=="") && (miloan==null ||miloan=="")){
  	
  }else{
  	
  	if(loanamount==null || loanamount==""){
          $("#loanamount").closest("div").parent().addClass("has-error");
          $("#error_loanamount").text("Please Enter Loan Amount.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
          }
        }
        
         if(datepicker3==null || datepicker3==""){
          $("#datepicker3").closest("div").parent().addClass("has-error");
          $("#error_loandate").text("Please Enter Loan Date");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#datepicker3").closest("div").parent().removeClass("has-error");

            $("#error_loandate").text("");
          
        }
  	
  	
  	  if(loaninterest==null || loaninterest==""){
          $("#loaninterest").closest("div").parent().addClass("has-error");
          $("#error_loaninterest").text("Please Enter Loan Interest rate.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!loaninterest.match(currency_regx) ) {
              $("#loaninterest").closest("div").parent().addClass("has-error");
              $('#error_loaninterest').html(" Please Enter valid <b>Loan Interest Amount</b>. Ex - 5.12 ");
              error_code++;
           // return false;
          }
          else{
            $("#loaninterest").closest("div").parent().removeClass("has-error");
            $("#error_loaninterest").text("");
          }
        }
  	
  	   if(miloan==null || miloan==""){
          $("#miloan").closest("div").parent().addClass("has-error");
          $("#error_miloan").text("Please Enter Loan Monthly Rate.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!miloan.match(currency_regx) ) {
              $("#miloan").closest("div").parent().addClass("has-error");
              $('#error_miloan').html(" Please Enter valid <b>Loan Monthly Amount</b>. Ex - 200.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#miloan").closest("div").parent().removeClass("has-error");
            $("#error_miloan").text("");
          }
        }
  	
  	
  	 if(loanterm==null || loanterm==""){
          $("#loanterm").closest("div").parent().addClass("has-error");
          $("#error_loanterm").text("Please Select Loan Term");
          //return false;
          error_code++;
        }
        else{
          //$("#error_ln").text("");
           
             $("#loanterm").closest("div").parent().removeClass("has-error");

            $("#error_loanterm").text("");
          
        }
  	
  }
         /*---------------------------------------------------------------------
      --                Insurance rate validations
      --error_opbalance
      ---------------------------------------------------------------------*/
        var insrate=$("#insrate").val();
        //var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      if(insrate==null || insrate==""){
          $("#insrate").closest("div").parent().addClass("has-error");
          $("#error_insrate").text("Please Enter Insurance Rate.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fees").text("");

          if (!insrate.match(currency_regx) ) {
              $("#insrate").closest("div").parent().addClass("has-error");
              $('#error_insrate').html(" Please Enter valid <b>Insurance Rate</b>. Ex - 2.00 ");
              error_code++;
           // return false;
          }
          else{
            $("#insrate").closest("div").parent().removeClass("has-error");
            $("#error_insrate").text("");
          }
        }

      
  
        if(error_code>0){

          return false;

        }else{
          return true;

        }





      });
      $("#loanamount").keyup(function(){
      	//alert('hh');
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#insrate").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#insamount").val("");
      	}else{
      		var insrate=$("#insrate").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#insamount").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#insamount").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            $("#insamount").val(insm.toFixed(2));
            
            
          }
        }
      	
      });
      
      
      
      //monthly install ment calculation
      $("#loanamount").keyup(function(){
      	//alert('hh');
      	var intscalcul=$("#interestcalculation").val();
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#loaninterest").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#miloan").val("");
      	}else{
      		var insrate=$("#loaninterest").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#miloan").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#miloan").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            
            if(intscalcul=="Yearly"){
            	var insm=((parseFloat(loanamount)*parseFloat(insrate))/100)/12;
            	$("#miloan").val(insm.toFixed(2));
            }else{
            	var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            	$("#miloan").val(insm.toFixed(2));
            }
            
            
            
          }
        }
      	
      });
      
      
      //interest calculation 
      
      $("#loaninterest").blur(function(){
      	//alert('hh');
      	var intscalcul=$("#interestcalculation").val();
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#loaninterest").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#miloan").val("");
      	}else{
      		var insrate=$("#loaninterest").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#miloan").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#miloan").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            
            if(intscalcul=="Yearly"){
            	var insm=((parseFloat(loanamount)*parseFloat(insrate))/100)/12;
            	$("#miloan").val(insm.toFixed(2));
            }else{
            	var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            	$("#miloan").val(insm.toFixed(2));
            }
            
            
            
          }
        }
      	
      });
      
      $("#interestcalculation").change(function(){
      	//alert('hh');
      	var intscalcul=$("#interestcalculation").val();
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#loaninterest").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#miloan").val("");
      	}else{
      		var insrate=$("#loaninterest").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#miloan").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#miloan").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            
            if(intscalcul=="Yearly"){
            	var insm=((parseFloat(loanamount)*parseFloat(insrate))/100)/12;
            	$("#miloan").val(insm.toFixed(2));
            }else{
            	var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            	$("#miloan").val(insm.toFixed(2));
            }
            
            
            
          }
        }
      	
      });
      
      
      
      
      $("#insrate").blur(function(){
      	//alert('hh');
      	var loanamount=$("#loanamount").val();
      	var currency_regx=/^(?:0|[1-9]\d*)(?:\.(?!.*000)\d+)?$/;
      	var insrate=$("#insrate").val();
      	if(insrate==null || insrate==""){
      		var insrate=0;
      		 $("#insamount").val("");
      	}else{
      		var insrate=$("#insrate").val();
      	}
      	if(loanamount==null || loanamount==""){
          $("#insamount").val("");
          $("#loanamount").closest("div").parent().removeClass("has-error");
           $("#error_loanamount").text("");
        }
        else{
          //$("#error_fees").text("");

          if (!loanamount.match(currency_regx) ) {
              $("#loanamount").closest("div").parent().addClass("has-error");
              $('#error_loanamount').html(" Please Enter valid <b>Loan Amount</b>. Ex - 200.00 ");
              $("#insamount").val("");
              //error_code++;
           // return false;
          }
          else{
            $("#loanamount").closest("div").parent().removeClass("has-error");
            $("#error_loanamount").text("");
            var insm=(parseFloat(loanamount)*parseFloat(insrate))/100;
            $("#insamount").val(insm.toFixed(2));
            
            
          }
        }
      	
      });
     
	  $("#state").change(function(){
		  
		  var state=$("#state").val();
		  $.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>manage_accounts/NewAccounts/get_district",
  			data :{'state':state},
  			success : function(data){
  				//console.log(data);
				$("#district").html(data);
  			  
              }  
           });
		  
	  });
	  /*$("#mi").blur(function(){
	  	
	  	//alert('hello');
	  	var mi=$("#mi").val();
	  	var datepicker2=$("#datepicker2").val();
	  	var term=$("#datepicker2").val();
	  	var interest=$("#datepicker2").val();
		  $.ajax({			
 			type :"POST",
  			url : "<?php //echo base_url();  ?>//manage_accounts/NewAccounts/get_district",
  			data :{'state':state},
  			success : function(data){
  				//console.log(data);
				$("#district").html(data);
  			  
              }  
           });
	  	
	  });*/
	  $("#term,#datepicker2").change(function(){
	  	var dat=$("#datepicker2").val();
	  	//alert(dat);
	  	//console.log(dat);
	  	var opbal=$("#opbalance").val();
	  	var period=$("#term").val();
	  	if((period!="" || period!=null) ){

	  		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>manage_accounts/NewAccounts/get_matdate",
  			data :{'dat':dat,'period':period},
  			success : function(data){
  				//console.log(data);
				$("#mtdate").val(data);
  			  
              }  
           });
	  	}else{
	  		$("#mtdate").val("");
	  	}
	  	
	  	
	  });
	  
	   $("#loanterm,#datepicker3").change(function(){
	  	var dat=$("#datepicker3").val();
	  	//alert(dat);
	  	//console.log(dat);
	  	var opbal=$("#opbalance").val();
	  	var period=$("#loanterm").val();
	  	if((period!="" || period!=null) ){

	  		$.ajax({			
 			type :"POST",
  			url : "<?php echo base_url();  ?>manage_accounts/NewAccounts/get_matdate",
  			data :{'dat':dat,'period':period},
  			success : function(data){
  				//console.log(data);
				$("#adjust").val(data);
  			  
              }  
           });
	  	}else{
	  		$("#adjust").val("");
	  	}
	  	
	  	
	  });
	  
      function readURL(input) {

      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function(e) {
          $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
      }
    }
    
    
    
    
    

    $("#image").change(function() {
      readURL(this);
    });
    })
    function getval(){
    	alert('hhh');
    }
</script>
