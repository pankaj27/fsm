<?php $this->load->view('master_settings/add_edit_view_account_master_style.php'); ?>

	<style>
  .modal-header, h4, .close {
      background-color: #3c8dbc;
      color:white !important;
      text-align: center;
      font-size: 30px;
  }
  .modal-footer {
      background-color: #f9f9f9;
  }
  </style>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('main-header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('nav-menu.php'); ?>
  <?php 
  		$user_grop_prev=array('super_admin','admin');
		$ugrp=$this->session->userdata('user_group');
    ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Account Master 
        <small>List</small> &nbsp;<a href="#"  class="btn btn-danger" data-toggle="modal" data-target="#modal-default">Add New</a>
	        <div class="modal fade" id="modal-default">
	          <div class="modal-dialog">
	            <div class="modal-content">
	              <div class="modal-header">
	                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	                  <span aria-hidden="true">&times;</span></button>
	                <h4 class="modal-title">Add Account Master</h4>
	              </div>
	              <div class="modal-body">
	                	<div class="row">
				        <!-- left column -->
				        <div class="col-md-12">
				          <!-- general form elements -->
				           <!-- form start -->
				            <form role="form" action="<?php echo base_url(); ?>master_setting/Master_setting/save_acc_master" method="post">
					            <div class="form-group">
					              <label for="usrname"> Account Name</label>
					              <input type="text" id="accname" name="accname" class="form-control"  placeholder="Enter account name" required="required">
					              
					            </div>
					            <div class="form-group">
					              <label for="psw"> Code</label>
					              <input type="text" name="code"  class="form-control" id="code" placeholder="Enter code" required="">
					              
					            </div>
					            <div class="form-group">
					              <label for="psw"> Status</label>
					              <select class="form-control" required name="status">
					              	<option value="">--select status--</option>
					              	<option value="1">Active</option>
					              	<option value="0">Inactive</option>
					              	
					              </select>
					            </div>
					            
					              <button type="submit" class="btn btn-primary btn-block"><span class="glyphicon glyphicon-save"></span> Save Changes</button>
				
					              <!-- /.box-body -->
								</form>
					             
					          
					         </div>
					        </div>
		              </div>
	              <div class="modal-footer">
	                <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
	                
	              </div>
	               
	            </div>
	            <!-- /.modal-content -->
	          </div>
	          <!-- /.modal-dialog -->
	        </div>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Account Master</a></li>
        <li class="active">List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
        	<?php if(isset($listmsg) && !empty($listmsg)){ echo $listmsg; }  ?>
          <div class="box box-primary">
            <div class="box-header">
              <!--<h3 class="box-title">Data Table With Full Features</h3>-->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped" >
                <thead>
                <tr>
                  <th>Sl No.</th>
                  <th>Acc. Name</th>
                  <th>Code</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                	<?php  if(isset($accounts_details) && !empty($accounts_details)){ $sl=1; ?>
                		<?php foreach($accounts_details as $val){ ?>
                			<tr>
			                	<td><?php echo $sl; ?></td>
			                	<td><?php echo  $val->accname; ?></td>
			                	<td><?php echo  $val->code; ?></td>
			                	<td>
			                		<?php 
			                			$st=$val->status; 
			                			/*0 inactive;
			                			1 ctive ;*/
			                			if($st==0){
			                				 if(in_array($ugrp, $user_grop_prev)){
			                				 	
			                			?>		<a href="<?php  echo base_url(); ?>master_setting/Master_setting/acc_master_activate/<?php echo $val->id; ?>" onclick="return confirm('Are you sure you want to activate it ?');"><span class="label label-warning">Inactive</span></a>
										<?php	 }else{
										?>
											 	<span class="label label-warning" >Inactive</span>
										<?php	 }
			                			}
										if($st==1){
											if(in_array($ugrp, $user_grop_prev)){
										?>
			                					<a href="<?php  echo base_url(); ?>master_setting/Master_setting/acc_master_inactivate/<?php echo $val->id; ?>" onclick="return confirm('Are you sure you want to Inactivate it ?');"><span class="label label-success" id="active" onclick="update_to_inactive()">Active</span></a>
											
										<?php	}else{
												echo '<span class="label label-success" >Active</span>';
											
											}
			                			}
			                		?></td>
			                	<td>
			                		<div class="btn-group">
					                  <button type="button" class="btn btn-success">Action</button>
					                  <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
					                    <span class="caret"></span>
					                    <span class="sr-only">Toggle Dropdown</span>
					                  </button>
					                  <ul class="dropdown-menu" role="menu">
					                    <li><a href="#" data-toggle="modal" data-target="#modal-default_<?php echo $sl; ?>"><i class="fa fa-edit"></i> Edit</a></li>
					                    <li><a href="<?php echo base_url();  ?>master_setting/Master_setting/delete_acc_master/<?php echo $val->id;  ?>" onclick="return confirm('Are you sure you want to delete?');"><i class="fa fa-trash"></i> Delete</a></li>
					                    
					                  </ul>
					                </div>
					                <div class="modal fade" id="modal-default_<?php echo $sl; ?>">
							          <div class="modal-dialog">
							            <div class="modal-content">
							              <div class="modal-header">
							                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
							                  <span aria-hidden="true">&times;</span></button>
							                <h4 class="modal-title">Edit Account Master</h4>
							              </div>
							              <div class="modal-body">
							                <div class="row">
										        <!-- left column -->
										        <div class="col-md-12">
										          <!-- general form elements -->
										           <!-- form start -->
										            <form role="form" action="<?php echo base_url(); ?>master_setting/Master_setting/update_acc_master" method="post">
											            <div class="form-group">
											              <label for="usrname" class="col-md-4"> Account Name</label>
											              <div class="col-md-8">
												              <input type="text" id="accname" name="accname" class="form-control" value="<?php echo  $val->accname; ?>"  placeholder="Enter account name" required="required">
												              <input type="hidden" name="accid" value="<?php echo  $val->id; ?>"/>
											              </div>
											            </div>
											            <div class="form-group">
											              <label for="psw" class="col-md-4"> Code</label>
											              <div class="col-md-8">
												              <input type="text" name="code"  class="form-control" value="<?php echo  $val->code; ?>" id="code" placeholder="Enter code" required="">
												          </div>
											            </div>
											            <div class="form-group">
											              <label for="psw" class="col-md-4"> Status</label>
											              <div class="col-md-8">
												              <select class="form-control" required name="status">
												              	<option value="">--select status--</option>
												              	<option value="1" <?php  if($st==1){ echo "selected"; } ?>>Active</option>
												              	<option value="0"  <?php  if($st==0){ echo "selected"; } ?>>Inactive</option>
												              	
												              </select>
												             </div>
											            </div>
											             <br>
											              
											              <!-- /.box-body -->
														
											             
											          
											         </div>
											        </div>
							              </div>
							              <div class="modal-footer">
							                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
							               <button type="submit" class="btn btn-primary pull-right"><span class="glyphicon glyphicon-save"></span> Save Changes</button>
										
							              </div>
							            </div>
							            <!-- /.modal-content -->
							            </form>
							          </div>
							          <!-- /.modal-dialog -->
							        </div>
			                	</td>
			                </tr>
                	<?php $sl++; } } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Sl No.</th>
                  <th>Acc. Name</th>
                  <th>Code</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
   <?php  $this->load->view('footer.php'); ?>

  <!-- Control Sidebar -->
  <?php $this->load->view('control-sidebar.php'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php $this->load->view('master_settings/add_edit_view_account_master_script.php');  ?>
<script>
	 $(document).ready(function(){

      $("#add_account").click(function(event){
      var fn_regx = /^[-a-zA-Z\s]+$/;
      var error_code=0;
       var accname=$("#accname").val();
      if(accname==null || accname==""){
          $("#accname").closest("div").parent().addClass("has-error");
          $("#error_accname").text("Please Enter Account Name.");
          error_code++;
          //return false;
        }
        else{
          //$("#error_fn").text("");
          if (!accname.match(fn_regx) ) {
              $("#accname").closest("div").parent().addClass("has-error");
              $('#error_accname').html(" Please Enter Valid <b>Account</b> Name  Ex - Recurring Deposit ");
              error_code++;
            //return false;
          }
          else{
            $("#accname").closest("div").parent().removeClass("has-error");

            $("#error_accname").text("");
          }


        }
        if(error_code>0){

          return false;

        }else{
          return true;

        }


    }
  }
</script>
