<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	if ( ! function_exists('master_accounts_contact_info')){
	   function master_accounts_contact_info($id){
		   	//return "hello";
		   	//get main CodeIgniter object
	       $ci =& get_instance();
	       
	       //load databse library
	       $ci->load->database();
		   $query=$ci->db->get_where('customer_contact_master',array('customer_id'=>$id));
			if($query->num_rows() > 0){
	           $result = $query->result();
			   //print_r($result);
	           //return $result;
	           $contact="";
	           foreach($result as $res){
	           //$name=$res->first_name." ".$res->last_name;
			   //return $name;
			   		$address=$res->address;
					$dist=$res->district;
					$stat=$res->state;
					$pin=$res->pincode;
			   }
			   if(!empty($address)){
			   	 $contact .=$address.", ";
			   }
			   if(!empty($dist)){
			   	 $contact .=$dist.",<br> ";
			   }
			   if(!empty($stat)){
			   	 $contact .=$stat.",<br> ";
			   }
			   if(!empty($pin)){
			   	 $contact .=$pin." <br>";
			   }
			   return $contact;
	       }else{
	           return false;
	       }
	   }
	}
if ( ! function_exists('get_user_group')){
	   function get_user_group($id){
	   	   $ci =& get_instance();
	       
	       //load databse library
	       $ci->load->database();
	       $group="";
		   $query=$ci->db->query("select groups.group_name as group_name from groups,user_group where groups.id=user_group.group_id and user_group.user_id='".trim($id)."' ");
			if($query->num_rows() > 0){
	           $result = $query->result();
				foreach($result as $res){
					$group=$res->group_name;
				}
			}
			return $group;
		
	   }
}
if ( ! function_exists('get_rd_accounts_info')){
	   function get_rd_accounts_info($id){
	   	   $ci =& get_instance();
	       
	       //load databse library
	       $ci->load->database();
	       $result="";
		   $query=$ci->db->query("select * from customer_recurring_master where customer_id='".trim($id)."' ");
			if($query->num_rows() > 0){
	           $result = $query->result();
				
			}
			return $result;
		
	   }
}
if ( ! function_exists('get_loan_accounts_info')){
	   function get_loan_accounts_info($id){
	   	   $ci =& get_instance();
	       
	       //load databse library
	       $ci->load->database();
	       $result="";
		   $query=$ci->db->query("select * from customer_loan_master where customer_id='".trim($id)."' ");
			if($query->num_rows() > 0){
	           $result = $query->result();
				
			}
			return $result;
		
	   }
}


?>