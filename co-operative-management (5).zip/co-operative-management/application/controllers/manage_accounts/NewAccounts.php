<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class NewAccounts extends CI_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->helper(array('form', 'url','security','masteraccounts'));
		$this->load->library('form_validation');
		//$this->load->library('security');
		$this->load->library('tank_auth');
		$this->lang->load('tank_auth');
		$this->load->model(array('newaccountsmodel','transactionmodel'));
		
	}
	public function addNewaccounts(){
		if ($this->tank_auth->is_logged_in()) {
			
			$this->load->view('newaccounts/add');
		} else {
			redirect('/auth/login/');
		}
	}
	public function get_district()
	{
		$state=$this->input->post("state");
		$query=$this->db->query("select * from cities where UCASE(city_state) like '%".$state."%'");
		//echo "select * from cities where city_state like '%".$state."%'";
		$res=$query->result();
		$opt="";
		if(isset($res) && !empty($res)){
			foreach($res as $val)
			{
				if($val->city_name=='Howrah'){
					$opt .="<option value='".$val->city_name."' selected>".$val->city_name."</option>";
				}else{
					$opt .="<option value='".$val->city_name."'>".$val->city_name."</option>";
				}
				
			}
			
		}else{
			
			$opt .="<option value=''>No data ....</option>";
		}
		echo $opt;
		
	}
	public function list_view()
	{
		if ($this->tank_auth->is_logged_in()) {
			
			//$this->load->view('newaccounts/list');
			
			$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			$this->load->view('newaccounts/list', $data);
			
			
		} else {
			redirect('/auth/login/');
		}
		
	}
	/*
	 * Custumer MAster Entry 
	 * 
	 * 
	 */
	 
	 public function save_master_entry(){
	 	
		if ($this->tank_auth->is_logged_in()) {
			
			//$this->load->view('newaccounts/list');
			//get personal info
			
			$first_name=strtoupper($this->input->post("first_name"));
			$middle_name=strtoupper($this->input->post("middle_name"));
			$last_name=strtoupper($this->input->post("last_name"));
			$dob=$this->input->post("dob");
			$nationality=$this->input->post("nationality");
			$gender=$this->input->post("gender");
			$mobile=$this->input->post("mobile");
			$fatthern=strtoupper($this->input->post("fatthern"));
			$mothern=strtoupper($this->input->post("mothern"));
			$mstatus=$this->input->post("mstatus");
			$join1=strtoupper($this->input->post("join1"));
			$join2=strtoupper($this->input->post("join2"));
			$nominee=strtoupper($this->input->post("nominee"));
			$rnominee=strtoupper($this->input->post("rnominee"));
			
			//get contact info  
			
			$address=strtoupper($this->input->post("address"));
			$state=$this->input->post("state");
			$district=$this->input->post("district");
			$pincode=$this->input->post("pincode");
			
			//get recurring account info 
			
			$acctype=$this->input->post("acctype");
			$accno=$this->input->post("accno");
			$opbalance=$this->input->post("opbalance");
			$opdate=$this->input->post("opdate");
			$mi=$this->input->post("mi");
			$period=$this->input->post("period");
			$interest=$this->input->post("interest");
			//$mtdate=$this->input->post("mtdate");
			//$mtamount=$this->input->post("mtamount");
			//$date=date_create($dt);
          //  $maturity=date_add($date,date_interval_create_from_date_string("$rdterm days"));
			$mtdate=$this->input->post('mtdate');
			//$mtamount="15000";
			
			//get loan account info
			$loanamount=$this->input->post("loanamount");
			$loandate=$this->input->post("loandate");
			$interestcalculate=$this->input->post("interest_calculate");
			$loanterm=$this->input->post("loanterm");
			$loaninterest=$this->input->post("loaninterest");
			$miloan=$this->input->post("miloan");
			
			
			$insrate=$this->input->post('insrate');
			$insamount=$this->input->post('insamount');
			
			
			// check accno already exist
			$accnostatus=$this->newaccountsmodel->checkaccnoexist($accno);
			if(isset($accnostatus) && !empty($accnostatus))
			{
				
				
				
			}else{
				// save into customer main table 
				$data_main=array(
							"accno"=>$accno,
							"first_name"=>$first_name,
							"middle_name"=>$middle_name,
							"last_name"=>$last_name,
							"dob"=>$dob,
							"nationality"=>$nationality,
							"gender"=>$gender,
							"mobile"=>$mobile,
							"father_husband_name"=>$fatthern,
							"mother_name"=>$mothern,
							"maritorial_status"	=>$mstatus,
							"joint_holder1"=>$join1,
							"joint_holder2"=>$join2,
							"nominee"=>$nominee,
							"relation_nominee"=>$rnominee,
							"crtdby"=>$this->session->userdata('user_id')
							
				           );
				           
				   $getcustomer_id=$this->newaccountsmodel->save_main_data($data_main);
				   
				   // save into customer Contact information  table
				   $data_contactinfo=array(
				   						"accno"=>$accno,
				   						"customer_id"=>$getcustomer_id,
				   						"address"=>$address,
				   						"state"=>$state,
				   						"district"=>$district,
				   						"pincode"=>$pincode,
				   						"crtdby"=>$this->session->userdata('user_id')
				   
				   						); 
					$contact_save=$this->newaccountsmodel->save_contact_data($data_contactinfo,$getcustomer_id,$accno);
					
					// save into customer Recurring Account information  table
					$data_recurringinfo=array(
										"accno"=>$accno,
										"customer_id"=>$getcustomer_id,
										"opening_balance"=>$opbalance,
										"opening_date"=>$opdate,
										"monthly_installment"=>$mi,
										"period"=>$period,
										"interest_rate"=>$interest,
										"maturity_date"=>$mtdate,
										//"maturity_amount"=>$mtamount,
										"crtdby"=>$this->session->userdata('user_id')
					                   
					                    );
					$recurring_save=$this->newaccountsmodel->save_recurring_data($data_recurringinfo,$getcustomer_id,$accno);
				   // save into customer Loan Account information  table
					$data_loaninfo=array(
										"accno"=>$accno,
										"customer_id"=>$getcustomer_id,
										"loan_amount"=>$loanamount,
										"loan_date"=>$loandate,
										"monthly_installment"=>$miloan,
										"period"=>$loanterm,
										"interest_calculate"=>$interestcalculate,
										"interest_rate"=>$loaninterest,
										"loan_adjust_date"=>$this->input->post('adjust'),
										"crtdby"=>$this->session->userdata('user_id')
					                   
					                    );
					$loan_save=$this->newaccountsmodel->save_loan_data($data_loaninfo,$getcustomer_id,$accno);
					
					//insurance data insert
					$data_insurance=array(
						"customer_id"=>$getcustomer_id,
						"accno"=>$accno,
						"insurance_rate"=>$insrate,
						"insurance_amount"=>$insamount,
						"crtdby"=>$this->session->userdata('user_id')
						
					
					);
					
					$insurance_save=$this->newaccountsmodel->save_data_insurance($data_insurance,$getcustomer_id,$accno);
					
					redirect('/manage_accounts/NewAccounts/list_view','refresh');
				
			}
			
			
			
		} else {
			redirect('/auth/login/');
		}	
		
		
		
	 }
	public function edit($accid){
		$user_grop_prev=array('super_admin','admin');
		$ugrp=$this->session->userdata('user_group');
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$data['personalinfo']=$this->newaccountsmodel->getaccounts_master_info($accid);
				$data['contactinfo']=$this->newaccountsmodel->getaccounts_contact_info($accid);
				$data['rdaccountinfo']=$this->newaccountsmodel->getaccounts_rdaccount_info($accid);
				$data['loanaccountinfo']=$this->newaccountsmodel->getaccounts_loan_info($accid);
				$data['insurance_master']=$this->newaccountsmodel->get_insurance_details($accid);
				$data['account']=$accid;
				$this->load->view('newaccounts/add',$data);
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access edit operation.please contact system admin for more.....
						       </div>';
				
				$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    $this->load->view('newaccounts/list', $data);
			
			}
			//$this->load->view('newaccounts/list');
			
			//
			
		} else {
			redirect('/auth/login/');
		}
	}

	public function update_master_entry(){
	 	   $user_grop_prev=array('super_admin','admin');
		    $ugrp=$this->session->userdata('user_group');
			
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
			//$this->load->view('newaccounts/list');
			//get personal info
			$accnoupdate=$this->input->post("accnoid");
			$first_name=strtoupper($this->input->post("first_name"));
			$middle_name=strtoupper($this->input->post("middle_name"));
			$last_name=strtoupper($this->input->post("last_name"));
			$dob=$this->input->post("dob");
			$nationality=$this->input->post("nationality");
			$gender=$this->input->post("gender");
			$mobile=$this->input->post("mobile");
			$fatthern=strtoupper($this->input->post("fatthern"));
			$mothern=strtoupper($this->input->post("mothern"));
			$mstatus=$this->input->post("mstatus");
			$join1=strtoupper($this->input->post("join1"));
			$join2=strtoupper($this->input->post("join2"));
			$nominee=strtoupper($this->input->post("nominee"));
			$rnominee=strtoupper($this->input->post("rnominee"));
			
			//get contact info  
			
			$address=strtoupper($this->input->post("address"));
			$state=$this->input->post("state");
			$district=$this->input->post("district");
			$pincode=$this->input->post("pincode");
			
			//get recurring account info 
			
			$acctype=$this->input->post("acctype");
			$accno=$this->input->post("accno");
			$opbalance=$this->input->post("opbalance");
			$opdate=$this->input->post("opdate");
			$mi=$this->input->post("mi");
			$period=$this->input->post("period");
			$interest=$this->input->post("interest");
			$mtdate=$this->input->post("mtdate");
			//$mtamount=$this->input->post("mtamount");
			//$mtdate=date('d-m-Y');
			//$mtamount="15000";
			
			//get loan account info
			$loanamount=$this->input->post("loanamount");
			$loandate=$this->input->post("loandate");
			$loanterm=$this->input->post("loanterm");
			$interestcalculate=$this->input->post("interest_calculate");
			$loaninterest=$this->input->post("loaninterest");
			$miloan=$this->input->post("miloan");
			
			
			
			
			
			 $insrate=$this->input->post('insrate');
			 $insamount=$this->input->post('insamount');
			
			
			
			
			// check accno already exist
			//$accnostatus=$this->newaccountsmodel->checkaccnoexist($accno);
			 $getcustid=$this->newaccountsmodel->getcustid($accnoupdate);
				// save into customer main table 
				$data_main=array(
							//"accno"=>$accno,
							"first_name"=>$first_name,
							"middle_name"=>$middle_name,
							"last_name"=>$last_name,
							"dob"=>$dob,
							"nationality"=>$nationality,
							"gender"=>$gender,
							"mobile"=>$mobile,
							"father_husband_name"=>$fatthern,
							"mother_name"=>$mothern,
							"maritorial_status"	=>$mstatus,
							"joint_holder1"=>$join1,
							"joint_holder2"=>$join2,
							"nominee"=>$nominee,
							"relation_nominee"=>$rnominee,
							"updateby"=>$this->session->userdata('user_id')
							
				           );
				           
				   $getcustomer_id=$this->newaccountsmodel->update_main_data($data_main,$accno);
				   
				   // save into customer Contact information  table
				   $data_contactinfo=array(
				   						//"accno"=>$accno,
				   						//"customer_id"=>$getcustomer_id,
				   						"address"=>$address,
				   						"state"=>$state,
				   						"district"=>$district,
				   						"pincode"=>$pincode,
				   						"updateby"=>$this->session->userdata('user_id')
				   
				   						); 
					$contact_save=$this->newaccountsmodel->update_contact_data($data_contactinfo,$getcustomer_id,$accno);
					
					// save into customer Recurring Account information  table
					$data_recurringinfo=array(
										//"accno"=>$accno,
										//"customer_id"=>$getcustomer_id,
										"opening_balance"=>$opbalance,
										"opening_date"=>$opdate,
										"monthly_installment"=>$mi,
										"period"=>$period,
										"interest_rate"=>$interest,
										"maturity_date"=>$mtdate,
										//"maturity_amount"=>$mtamount,
										"updateby"=>$this->session->userdata('user_id')
					                   
					                    );
					$recurring_save=$this->newaccountsmodel->update_recurring_data($data_recurringinfo,$getcustomer_id,$accno);
				   // save into customer Recurring Account information  table
				   //check data  info 
				    $loanacc=$this->newaccountsmodel->get_check_loan_account($accno);
					if(isset($loanacc) && !empty($loanacc)){
						
						$data_loaninfo=array(
										//"accno"=>$accno,
										//"customer_id"=>$getcustomer_id,
										"loan_amount"=>$loanamount,
										"loan_date"=>$loandate,
										"monthly_installment"=>$miloan,
										"period"=>$loanterm,
										"interest_rate"=>$loaninterest,
										"interest_calculate"=>$interestcalculate,
										"loan_adjust_date"=>$this->input->post('adjust'),
										"updateby"=>$this->session->userdata('user_id')
					                   
					                    );
					$loan_save=$this->newaccountsmodel->update_loan_data($data_loaninfo,$getcustomer_id,$accno);
						
						
						
					}else{
					$data_loaninfo=array(
										"accno"=>$accno,
										"customer_id"=>$getcustid,
										"loan_amount"=>$loanamount,
										"loan_date"=>$loandate,
										"monthly_installment"=>$miloan,
										"period"=>$loanterm,
										"interest_rate"=>$loaninterest,
										"interest_calculate"=>$interestcalculate,
										"loan_adjust_date"=>$this->input->post('adjust'),
										"updateby"=>$this->session->userdata('user_id')
					                   
					                    );
					$loan_save=$this->newaccountsmodel->save_loan_data($data_loaninfo,$getcustomer_id,$accno);
					
					}
					//insurence check master
					
					$checkinsuranceexist=$this->newaccountsmodel->get_insurance_details($accno);
					if(isset($checkinsuranceexist) && !empty($checkinsuranceexist)){
								$data_insurance=array(
							"customer_id"=>$getcustid,
							"accno"=>$accno,
							"insurance_rate"=>$insrate,
							"insurance_amount"=>$insamount,
							"updateby"=>$this->session->userdata('user_id')
							
						
						);
					
					$insurance_save=$this->newaccountsmodel->update_insurance($data_insurance,$getcustid,$accno);
					//echo 1;
							
						
					}else{
						
						$data_insurance=array(
							"customer_id"=>$getcustid,
							"accno"=>$accno,
							"insurance_rate"=>$insrate,
							"insurance_amount"=>$insamount,
							"crtdby"=>$this->session->userdata('user_id')
							
						
						);
					
					$insurance_save=$this->newaccountsmodel->save_data_insurance($data_insurance,$getcustid,$accno);
					
					//echo 2;	
						
					}
					
					$data['listmsg']='<div class="alert alert-success alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 Update done succesfully....
						       </div>';
				
				$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    $this->load->view('newaccounts/list', $data);
				
			//}
			
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access edit operation.please contact system admin for more.....
						       </div>';
				
				$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			   // $this->load->view('newaccounts/list', $data);
				
			}
			
		} else {
			//redirect('/auth/login/');
		}	
		
		
		
	 }
public function delete($id){
	
	$user_grop_prev=array('super_admin','admin');
		$ugrp=$this->session->userdata('user_group');
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$delete_master=$this->newaccountsmodel->delete_acc_details($id);
				if($delete_master==true){
					
					$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 Deleted done successfully.
						       </div>';
				}else{
						$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 Error! please try again.
						       </div>';
					
				}
				
				//$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			   // $this->load->view('newaccounts/list', $data);
			   redirect('/manage_accounts/NewAccounts/list_view','refresh');
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access delete operation.please contact system admin for more.....
						       </div>';
				
				$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    $this->load->view('newaccounts/list', $data);
			
			}
			//$this->load->view('newaccounts/list');
			
			//
			
		} else {
			redirect('/auth/login/');
		}
	
}
 public function getaccinfo(){
 	$accno=$this->input->post('accno');
 	$getaccinfo=$this->newaccountsmodel->getaaccnoinfo($accno);
	$res=array();
	$getdeposit_colletedinfo=$this->newaccountsmodel->getdepositcoleted($accno);
	if(isset($getdeposit_colletedinfo) && !empty($getdeposit_colletedinfo)){
		$deposit=$getdeposit_colletedinfo[0]->deposit_by;
		$collect=$getdeposit_colletedinfo[0]->collected_by;
	}else{
		$deposit="";
		$collect="";
	}
	if(isset($getaccinfo) && !empty($getaccinfo)){
		//print_r($getaccinfo);
		
		$id=$getaccinfo[0]->id;
		$first_name=$getaccinfo[0]->first_name;
		$middle_name=$getaccinfo[0]->middle_name;
		$last_name=$getaccinfo[0]->last_name;
		$opening_balance=$getaccinfo[0]->opening_balance;
		$opening_date=$getaccinfo[0]->opening_date;
		$monthly_installment=$getaccinfo[0]->monthly_installment;
		//$accno=$getaccinfo[0]->id;
		$res=array("id"=>"$id","accno"=>"$accno","first_name"=>"$first_name","middle_name"=>"$middle_name","last_name"=>"$last_name","opening_balance"=>"$opening_balance","opening_date"=>"$opening_date","monthly_installment"=>"$monthly_installment","deposit"=>"$deposit","collect"=>"$collect");
		echo json_encode($res);
	}else{
		 echo json_encode($res);
	}
 	
 }
 public function get_matdate(){
 	$dat=$this->input->post("dat");
	 $newDate = date("d-m-Y", strtotime($dat));
	 $period=$this->input->post("period");
	$matdate=date('d-m-Y', strtotime("+$period months", strtotime($dat)));
	echo $matdate;
 }
 public function apply_for_loan(){
 	if ($this->tank_auth->is_logged_in()) {
			
			$this->load->view('newaccounts/loan');
		} else {
			redirect('/auth/login/');
		}
 }
 public function save_loan_apply(){
 	
	$user_grop_prev=array('super_admin','admin');
		    $ugrp=$this->session->userdata('user_group');
			
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$accno=$this->input->post("accno");
			
				$loanamount=$this->input->post("loanamount");
				$loandate=$this->input->post("loandate");
				$interestcalculate=$this->input->post("interest_calculate");
				$loanterm=$this->input->post("loanterm");
				$loaninterest=$this->input->post("loaninterest");
				$miloan=$this->input->post("miloan");
				$loan_adjust=$this->input->post('adjust');
				
				$insrate=$this->input->post('insrate');
				$insamount=$this->input->post('insamount');
				
				
				$loanacc=$this->newaccountsmodel->get_check_loan_account($accno);
				$getcustomer_id=$loanacc[0]->customer_id;
						
				//$loantext=array();
					if(isset($loanacc) && !empty($loanacc)){
						$getcustomer_id=$loanacc[0]->customer_id;
						$getprevloan=$loanacc[0]->loan_amount;
						$loantext=$loanacc[0]->loan_txt;
						$data_loaninfo=array(
										//"accno"=>$accno,
										//"customer_id"=>$getcustomer_id,
										"loan_amount"=>$loanamount,
										"loan_date"=>$loandate,
										"monthly_installment"=>$miloan,
										"period"=>$loanterm,
										"interest_rate"=>$loaninterest,
										"interest_calculate"=>$interestcalculate,
										"loan_adjust_date"=>$loan_adjust,
										
					                    );
										
					/*----------------------New Update ---------------------------------------*/
					$data_loaninfo_implode=implode(",",$data_loaninfo);
					if(!empty($loantext) && isset($loantext)){
						
						$loantext=$loantext.",".$data_loaninfo_implode;
					}else{
						
						$loantext="{$data_loaninfo}";
					}
					
					$data_arr=array(
										"loan_amount"=>floatval($loanamount)+floatval($getprevloan),
										"loan_date"=>$loandate,
										"monthly_installment"=>$miloan,
										"period"=>$loanterm,
										"interest_rate"=>$loaninterest,
										"interest_calculate"=>$interestcalculate,
										"loan_adjust_date"=>$loan_adjust,
										"loan_txt"=>$loantext,
										"crtdby"=>$this->session->userdata('user_id'),
										"updateby"=>$this->session->userdata('user_id')
					
					);
					
					
					
					$loan_save=$this->newaccountsmodel->update_loan_data($data_arr,$getcustomer_id,$accno);
					//add new row in loan master
					
					$get_last_month_transaction=$this->transactionmodel->loan_master_data_check($accno);
					if(isset($get_last_month_transaction) && !empty($get_last_month_transaction)){
					$accid=$get_last_month_transaction[0]->cid;
				    //$interest_due=floatval($get_last_month_transaction[0]->	interest_due);
					$get_principal_due=floatval($get_last_month_transaction[0]->principal_due);
					$londtexplo=explode("/",$loandate);
					$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$londtexplo[2],
										"last_update"=>$loandate,
										"for_the_month"=>$londtexplo[0],
										"principal_add"=>$loanamount,
										"principal_due"=>floatval($get_principal_due)+ floatval($loanamount),
										"status"=>2,
										"approve"=>"Yes"
										
									);		
					
					
					$this->transactionmodel->save_loan_master_data_first_time($data_loan_master);
					}				
					
					}else{
					$cusdetails=$this->newaccountsmodel->get_check_customer_account($accno);	
					$getcustid=$cusdetails[0]->customer_id;
					$data_loaninfo=array(
										
										"loan_amount"=>$loanamount,
										"loan_date"=>$loandate,
										"monthly_installment"=>$miloan,
										"period"=>$loanterm,
										"interest_rate"=>$loaninterest,
										"interest_calculate"=>$interestcalculate,
										"loan_adjust_date"=>$loan_adjust,
										
					                   
					                    );
					$data_loaninfo_implode=implode(",","{$data_loaninfo}");
					$loantext=$data_loaninfo_implode;
					$data_arr=array(
										"accno"=>$accno,
										"customer_id"=>$getcustid,
										"loan_amount"=>$loanamount,
										"loan_date"=>$loandate,
										"monthly_installment"=>$miloan,
										"period"=>$loanterm,
										"interest_rate"=>$loaninterest,
										"interest_calculate"=>$interestcalculate,
										"loan_adjust_date"=>$loan_adjust,
										"loan_txt"=>$loantext,
										"crtdby"=>$this->session->userdata('user_id'),
										"updateby"=>$this->session->userdata('user_id')
					
					);
					
					$loan_save=$this->newaccountsmodel->save_loan_data($data_arr,$getcustid,$accno);
					
					}
					//insurence check master
				//$cusdetails=$this->newaccountsmodel->get_check_customer_account($accno);	
				//$getcustid=$cusdetails[0]->customer_id;
						
				//multiple loan taken
				$data_arr_multiloan=array(
										"accno"=>$accno,
										"customer_id"=>$getcustomer_id,
										"loan_amount"=>$loanamount,
										"loan_date"=>$loandate,
										"monthly_installment"=>$miloan,
										"period"=>$loanterm,
										"interest_rate"=>$loaninterest,
										"interest_calculate"=>$interestcalculate,
										"loan_adjust_date"=>$loan_adjust,
										"crtdby"=>$this->session->userdata('user_id'),
										"updateby"=>$this->session->userdata('user_id')
					
					);
				
				$this->newaccountsmodel->save_multi_loan_data($data_arr_multiloan,$getcustid,$accno);
					
					
					
					
					
					
					
					
					
					
					
					/*$checkinsuranceexist=$this->newaccountsmodel->get_insurance_details($accno);
					if(isset($checkinsuranceexist) && !empty($checkinsuranceexist)){
						
								$data_insurance=array(
							"customer_id"=>$getcustomer_id,
							"accno"=>$accno,
							"insurance_rate"=>$insrate,
							"insurance_amount"=>$insamount,
							"updateby"=>$this->session->userdata('user_id')
							
						
						);
					
					$insurance_save=$this->newaccountsmodel->update_insurance($data_insurance,$getcustomer_id,$accno);
					//echo 1;
							
						
					}else{
						*/
						$data_insurance=array(
							"customer_id"=>$getcustomer_id,
							"accno"=>$accno,
							"insurance_rate"=>$insrate,
							"insurance_amount"=>$insamount,
							"crtdby"=>$this->session->userdata('user_id')
							
						
						);
					
					$insurance_save=$this->newaccountsmodel->save_data_insurance_multi($data_insurance,$getcustomer_id,$accno);
					
					/*--------------------------------------------------------------------------------
					 * 
					 * Loan calculation
					 * 
					 * 
					 --------------------------------------------------------------------------------*/
					
					
					
					
					
					
					
					
					
					
					
					
					//echo 2;	
						
					//}
					redirect('manage_accounts/NewAccounts/list_view');
				
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access edit operation.please contact system admin for more.....
						       </div>';
				
				$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    $this->load->view('newaccounts/list', $data);
				
			}
			
		} else {
			redirect('/auth/login/');
		}	
		
	
	
 	
   }
	public function get_loaninfo(){
		$accno=$this->input->post('accno');
		//echo "select clm.loan_amount,clm.loan_date,clm.monthly_installment,clm.period,clm.interest_calculate,clm.interest_rate,clm.loan_adjust_date,im.insurance_rate,im.insurance_amount from customer_loan_master clm,insurance_master im where clm.accno=im.accno & clm.accno='".trim($accno)."'";
		$get_loan_insurance=$this->newaccountsmodel->get_loan_insurence_info($accno);
		$res=array();
		if(isset($get_loan_insurance) && !empty($get_loan_insurance)){
			//print_r($get_loan_insurance);
			//$res=$get_loan_insurance;
			$loan_amount=$get_loan_insurance[0]->loan_amount;
			$loan_date=$get_loan_insurance[0]->loan_date;
			$monthly_installment=$get_loan_insurance[0]->monthly_installment;
			$period=$get_loan_insurance[0]->period;
			$interest_rate=$get_loan_insurance[0]->interest_rate;
			$insurance_rate=$get_loan_insurance[0]->insurance_rate;
			$insurance_amount=$get_loan_insurance[0]->insurance_amount;
			$adjust=$get_loan_insurance[0]->loan_adjust_date;
			$res=array("loan_amount"=>"$loan_amount","loan_date"=>"$loan_date","monthly_installment"=>"$monthly_installment","period"=>"$period","interest_rate"=>"$interest_rate","insurance_rate"=>"$insurance_rate","insurance_amount"=>"$insurance_amount","adjustment"=>"$adjust");
		    echo json_encode($res);
			
			
		}else{
			 echo json_encode($res);
		}
		//echo json_encode(array($res));
	}
  public function get_all_loan_take_info(){
  	
	$accno=$this->input->post('accno');
	$get_loan_take=$this->newaccountsmodel->get_loan_take($accno);
	$table="";
	if(isset($get_loan_take) && !empty($get_loan_take)){
		
		$table .='<div class="box box-success">';
		$table .='<div class="box-header with-border">
	              <h3 class="box-title">Previous Loan Information</h3>
	            </div>';
		$table .='<div class="box-body">';
		$table .='<table class="table table-bordered">';
		$table .='<thead>';
		$table .='<tr>
						<th>Sl No.</th>
						<th>Accno</th>
						<th>Loan Amount</th>
						<th>Date</th>
				  </tr>
				  </thead><tbody>';
		$sl=1;
		foreach($get_loan_take as $val){
			$table .='<tr>';
			$table .='<td>'.$sl.'</td>';
			$table .='<td>'.$val->accno.'</td>';
			$table .='<td>'.$val->loan_amount.'</td>';
			$table .='<td>'.$val->loan_date.'</td>';
			$table .='</tr>';
			$sl++;
		}
		$table .='</tbody>';
		$table .='</table></div>';
		$table .='</div>';
		
	}
	$get_loan_insurance=$this->newaccountsmodel->get_loan_insurence_info($accno);
		$res=array();
		if(isset($get_loan_insurance) && !empty($get_loan_insurance)){
			//print_r($get_loan_insurance);
			//$res=$get_loan_insurance;
			$loan_amount=$get_loan_insurance[0]->loan_amount;
			$loan_date=$get_loan_insurance[0]->loan_date;
			$monthly_installment=$get_loan_insurance[0]->monthly_installment;
			$period=$get_loan_insurance[0]->period;
			$interest_rate=$get_loan_insurance[0]->interest_rate;
			$insurance_rate=$get_loan_insurance[0]->insurance_rate;
			$insurance_amount=$get_loan_insurance[0]->insurance_amount;
			$adjust=$get_loan_insurance[0]->loan_adjust_date;
			$res=array("loan_amount"=>"$loan_amount","loan_date"=>"$loan_date","monthly_installment"=>"$monthly_installment","period"=>"$period","interest_rate"=>"$interest_rate","insurance_rate"=>"$insurance_rate","insurance_amount"=>"$insurance_amount","adjustment"=>"$adjust","tabl"=>$table);
		    echo json_encode($res);
			
			
		}else{
			 echo json_encode($res);
		}
	
	
  }
    
	
}