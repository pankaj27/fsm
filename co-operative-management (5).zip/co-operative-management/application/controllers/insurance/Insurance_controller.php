<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Insurance_controller extends CI_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->helper(array('form', 'url','security','masteraccounts'));
		$this->load->library('form_validation');
		//$this->load->library('security');
		$this->load->library('tank_auth');
		$this->lang->load('tank_auth');
		$this->load->model(array('newaccountsmodel','insurance_model'));
		
	}
	public function addNewaccounts(){
		
		
	}
	public function pay_insurence(){
		if ($this->tank_auth->is_logged_in()) {
			
			$this->load->view('insurence/ins');
		} else {
			redirect('/auth/login/');
		}
	}
	public function get_all_ins_take_info(){
		
  	
	$accno=$this->input->post('accno');
	$get_loan_take=$this->insurance_model->get_insurence_take($accno);
	$table="";
	if(isset($get_loan_take) && !empty($get_loan_take)){
		
		$table .='<div class="box box-success">';
		$table .='<div class="box-header with-border">
	              <h3 class="box-title">Insurence Information</h3>
	            </div>';
		$table .='<div class="box-body">';
		$table .='<table class="table table-bordered">';
		$table .='<thead>';
		$table .='<tr>
						<th>Sl No.</th>
						<th>Accno</th>
						<th>Loan Amount</th>
						<th>Ins. (%)</th>
						<th>Ins. Amount</th>
						<th>Status</th>
				  </tr>
				  </thead><tbody>';
		$sl=1;
		foreach($get_loan_take as $val){
			
			$insrate=$val->insurance_rate;
			$insamnt=$val->insurance_amount;
			$loanamount=(floatval($insamnt)/floatval($insrate))*100;
			if($val->paid=='N'){
				$button='<input type="hidden" value="'.$val->id.'" id="cusid_'.$sl.'"> <div id="btnn_'.$sl.'"><button class="btn btn-danger pull-right" id="button_'.$sl.'" onclick="pay_insurence(this.id)">Pay Now</button></div>';
			
			}else{
				$button='<button class="btn btn-success pull-right" >Paid</button>';
			
			}
			$table .='<tr>';
			$table .='<td>'.$sl.'</td>';
			$table .='<td>'.$val->accno.'</td>';
			$table .='<td>'.$loanamount.'</td>';
			$table .='<td>'.$insrate.'</td>';
			$table .='<td>'.$insamnt.'</td>';
			$table .='<td id="btn_'.$sl.'">'.$button.'</td>';
			$table .='</tr>';
			$sl++;
		}
		$table .='</tbody>';
		$table .='</table></div>';
		$table .='</div>';
		$table .='<script>
					function pay_insurence(id){
				    	var idsplit=id.split("_");
						var idnew=$("#cusid_"+idsplit[1]).val();
				    	 $.ajax({			
			 			type :"POST",
			  			url : "'.base_url().'insurance/Insurance_controller/save_insurance",
			  			data :{"id":idnew},
			  			success : function(data){
			  				alert(data);
			  				var json=JSON.parse(data);
							var insst=json.insst;
							if(json=="" || json==null){
								
							}else{
								$("#btnn_"+idsplit[1]).html(insst);
							}
						}
						});
							    	
				    	
				    }
		
		
				</script>';
		
	}
	$get_loan_insurance=$this->newaccountsmodel->get_loan_insurence_info($accno);
		$res=array();
		if(isset($get_loan_insurance) && !empty($get_loan_insurance)){
			//print_r($get_loan_insurance);
			//$res=$get_loan_insurance;
			$loan_amount=$get_loan_insurance[0]->loan_amount;
			$loan_date=$get_loan_insurance[0]->loan_date;
			$monthly_installment=$get_loan_insurance[0]->monthly_installment;
			$period=$get_loan_insurance[0]->period;
			$interest_rate=$get_loan_insurance[0]->interest_rate;
			$insurance_rate=$get_loan_insurance[0]->insurance_rate;
			$insurance_amount=$get_loan_insurance[0]->insurance_amount;
			$adjust=$get_loan_insurance[0]->loan_adjust_date;
			$res=array("loan_amount"=>"$loan_amount","loan_date"=>"$loan_date","monthly_installment"=>"$monthly_installment","period"=>"$period","interest_rate"=>"$interest_rate","insurance_rate"=>"$insurance_rate","insurance_amount"=>"$insurance_amount","adjustment"=>"$adjust","tabl"=>$table);
		    echo json_encode($res);
			
			
		}else{
			 echo json_encode($res);
		}
	
	
	}
	public function save_insurance(){
	   $idn=$this->input->post('id');
	   $rest=$this->insurance_model->update_insurence($idn);
	   $btn='<button class="btn btn-success pull-right" >Paid</button>';
	   $res=array();
	   //con
	   if($rest==1){
	   $res=array("insst"=>"$btn");
		    echo json_encode($res);
	   	
	   }else{
	   	 echo json_encode($res);
	   }
	   
	   
	}
	
}