<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Settlement extends CI_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->helper(array('form', 'url','security','masteraccounts'));
		$this->load->library('form_validation');
		//$this->load->library('security');
		$this->load->library('tank_auth');
		$this->lang->load('tank_auth');
		$this->load->model(array('newaccountsmodel','Settlement_model','statement_model'));
		
	}
	public function loan_settlement(){
		$user_grop_prev=array('super_admin','admin');
		    $ugrp=$this->session->userdata('user_group');
			
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$data['allaccno']=$this->Settlement_model->get_all_accounts();
				//print_r($data['allaccno']);
				$this->load->view('settlement/loan_settlement',$data);
				
				
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access edit operation.please contact system admin for more.....
						       </div>';
				
				//$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    redirect('/auth/login/');
			}
		}else{
			redirect('/auth/login/');
		}
	}
	
	public function get_all_loan_settlement_info(){
		
		$acno=$this->input->post('accno');
		//get total loan info
		$loan=$this->Settlement_model->get_total_info($acno);
		$loanamnt=$loan[0]->loan;
		$period=$loan[0]->period;
		$res=array();
		//other info get total interest and total principal pay
		//echo $period;
		$loanoth=$this->Settlement_model->get_other_info($acno);
		$tot_intrst=$loanoth[0]->totinterest;
		$tot_pay=$loanoth[0]->totalpay;
		//get last payment date
		$loanlastpay=$this->Settlement_model->get_loan_last_pay($acno);
		$last_py=$loanlastpay[0]->last_update;
		
		$res=array("loan"=>"$loanamnt","period"=>"$period","totinterest"=>"$tot_intrst","totalpay"=>"$tot_pay","last_update"=>"$last_py");
		echo json_encode($res);
		
		
	}
	public function loan_settlement_save(){
		$accno=$this->input->post("accno");
		$total_loan=$this->input->post("total_loan");
		$time=$this->input->post("time");
		$interest=$this->input->post("interest");
		//$lpd=$this->input->post("lpd");
		$totpay=$this->input->post("totpay");
		$typeofsettlement=$this->input->post("typeofsettlement");
		if($typeofsettlement==1){
			$data_arr=array(
				"accno"=>$accno,
				"loanamount"=>$total_loan,
				"period"=>$time,
				"interest"=>$interest,
				"total_paid"=>$totpay,
				"type_of_settlement"=>1,
				"crtdby"=>$this->session->userdata('user_id'),
				"status"=>2
			);
			$this->db->insert('loan_settlement',$data_arr);
			$dataup=array("status"=>"2");
		   $this->db->where('accno',$accno);
		   $this->db->update('customer_loan_master',$dataup);
		}
		if($typeofsettlement==2){
			$remainingamount=$this->input->post("remainingamount");
			$data_arr=array(
				"accno"=>$accno,
				"loanamount"=>$total_loan,
				"period"=>$time,
				"interest"=>$interest,
				"total_paid"=>$totpay,
				"type_of_settlement"=>2,
				"due_amount"=>$remainingamount,
				"crtdby"=>$this->session->userdata('user_id'),
				"status"=>2
			);
			$this->db->insert('loan_settlement',$data_arr);
			$dataup=array("status"=>"2");
		   $this->db->where('accno',$accno);
		   $this->db->update('customer_loan_master',$dataup);
			
		}
		if($typeofsettlement==3){
			$remainingamount=$this->input->post("remainingamount");
			$ultimate=$this->input->post("ultimate");
			$data_arr=array(
				"accno"=>$accno,
				"loanamount"=>$total_loan,
				"period"=>$time,
				"interest"=>$interest,
				"total_paid"=>$totpay,
				"type_of_settlement"=>3,
				"due_amount"=>$remainingamount,
				"ultimate_pay"=>$ultimate,
				"crtdby"=>$this->session->userdata('user_id'),
				"status"=>2
			);
			$this->db->insert('loan_settlement',$data_arr);
			$dataup=array("status"=>"2");
		   $this->db->where('accno',$accno);
		   $this->db->update('customer_loan_master',$dataup);
		   //$this->db->update('customer_loan_master',$dataup);
		   
		}
		if($typeofsettlement==4){
			$ultimate=$this->input->post("insur");
			
			$data_arr=array(
				"accno"=>$accno,
				"loanamount"=>$total_loan,
				"period"=>$time,
				"interest"=>$interest,
				"total_paid"=>$totpay,
				"type_of_settlement"=>4,
				"ultimate_pay"=>$ultimate,
				"deduct_from"=>"Insurance",
				"crtdby"=>$this->session->userdata('user_id'),
				"status"=>2
			);
			
			$this->db->insert('loan_settlement',$data_arr);
			$dataup=array("status"=>"2");
		   $this->db->where('accno',$accno);
		   $this->db->update('customer_loan_master',$dataup);
			$data_arr_ins=array(
				"accno"=>$accno,
				"amount"=>$ultimate,
				"crtdby"=>$this->session->userdata('user_id')
			
			);
			$this->db->insert('settlement_from_insurance',$data_arr_ins);
			
			
		}
		//print_r($data_arr);
		redirect('settlement/Settlement/loan_settlement','refresh');
	}
	
	public function ddsettlement(){
		$user_grop_prev=array('super_admin','admin');
		    $ugrp=$this->session->userdata('user_group');
			
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$data['allaccno']=$this->Settlement_model->get_all_ddaccounts();
				//print_r($data['allaccno']);
				$this->load->view('settlement/deposit_settlement',$data);
				
				
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access edit operation.please contact system admin for more.....
						       </div>';
				
				//$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    redirect('/auth/login/');
			}
		}else{
			redirect('/auth/login/');
		}
		
	}
	public function get_all_dd_info(){
		$accno=$this->input->post('accno');
		//echo "select clm.loan_amount,clm.loan_date,clm.monthly_installment,clm.period,clm.interest_calculate,clm.interest_rate,clm.loan_adjust_date,im.insurance_rate,im.insurance_amount from customer_loan_master clm,insurance_master im where clm.accno=im.accno & clm.accno='".trim($accno)."'";
		$getaccinfo=$this->Settlement_model->get_dd_acc_info($accno);
		//print_r($getaccinfo);
		//$getaccinfo=$this->newaccountsmodel->getaaccnoinfo_statement($accno);
		$res=array();
		if(isset($getaccinfo) && !empty($getaccinfo)){
			//print_r($get_loan_insurance);
			//$res=$get_loan_insurance;
			$opening_balance=$getaccinfo[0]->opening_balance;
			$opening_date=$getaccinfo[0]->opening_date;
			$interest_rate=floatval($getaccinfo[0]->interest_rate);
			$monthly_installment=$getaccinfo[0]->monthly_installment;
			$get_recurring_transaction_info=$this->statement_model->get_recurring_transaction_info($accno);
			 $totalbl=0;
			 $bal=0;
			 foreach($get_recurring_transaction_info as $trval){
				  $bal=$bal+$trval->amount_paid;
				  $totalbl=$totalbl+$bal;
			 }
			//echo $totalbl;
			 $deposit=floatval($getaccinfo[0]->amount_paid);
			 //$deposit="";
			 $balance=floatval($getaccinfo[0]->balance);
			 $inst=(floatval($totalbl)*$interest_rate/100)/12;
			 $peri=$getaccinfo[0]->period;
			 $othrp=floatval($getaccinfo[0]->tranfer_from_loan_acc);
			 $totpa=floatval($deposit)+floatval($inst)+floatval($othrp);
			 $maturity_date=$getaccinfo[0]->maturity_date;
			 $table="";
			 $table .='<div class="box box-success">';
			$table .='<div class="box-header with-border">
		              <h3 class="box-title">DD Deposit Info</h3>
		            </div>';
			$table .='<div class="box-body">';
			$table .='<table class="table table-bordered">';
			$table .='<thead>';
			$table .='<tr>
							<th>Total Deposit</th>
							<th>Interest</th>
							<th>Others Pay</th>
							<th>Total Pay</th>
					  </tr>
					  </thead><tbody>';
			
				$table .='<tr>';
				$table .='<td>'.number_format((float)$deposit, 2, '.', '').'</td>';
				$table .='<td>'.number_format((float)$inst, 2, '.', '').'</td>';
				$table .='<td>'.number_format((float)$othrp, 2, '.', '').'</td>';
				$table .='<td>'.number_format((float)$totpa, 2, '.', '').'</td>';
				$table .='</tr>';
				
			$table .='</tbody>';
			$table .='</table></div>';
			$table .='</div>';
			 
			 
			
			
			$res=array("interest_rate"=>"$interest_rate","total_dd"=>"$deposit","time"=>"$peri","interest"=>number_format((float)$inst, 2, '.', ''),"opd"=>"$opening_date","mdt"=>"$maturity_date","tbl"=>"$table","othp"=>number_format((float)$othrp, 2, '.', ''));
			echo json_encode($res);
			
			
		}else{
			 echo json_encode($res);
		}
	}
	public function dd_settlement_save(){
		$accno=$this->input->post("accno");
		//$totdepo=$this->input->post("total_dd");
		$total_dd=$this->input->post("total_dd");
		$interest_rate=$this->input->post("interest_rate");
		$time=$this->input->post("time");
		$interest=$this->input->post("interest");
		$opd=$this->input->post("opd");
		$mdt=$this->input->post("mdt");
		$othp=$this->input->post("othp");
		$data_arr=array(
			"accno"=>$accno,
			"totdd"=>$total_dd,
			"interest"=>$interest,
			"totpay"=>floatval($total_dd)+floatval($interest)+floatval($othp),
			"othepay"=>$othp,
			"crtdby"=>$this->session->userdata('user_id'),
			
		
		);
		$chkdataexs=$this->Settlement_model->checkdata_exist($accno);
		if(isset($chkdataexs) && !empty($chkdataexs)){
			
			$msg='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                Already done
						       </div>';
			
			
		}else{
			$this->Settlement_model->save_dd_stee($data_arr);
			$this->db->query("update customer_recurring_master set status='2' where accno='".$accno."'");
			$msg='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 Succesfully done
						       </div>';
		}
		redirect('settlement/Settlement/ddsettlement','refresh');
		
	}
	
}