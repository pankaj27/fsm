<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Transaction extends CI_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->helper(array('form', 'url','security','masteraccounts'));
		$this->load->library('form_validation');
		//$this->load->library('security');
		$this->load->library('tank_auth');
		$this->lang->load('tank_auth');
		$this->load->model('transactionmodel');
		
	}
	public function add_new_transaction()
	{
		 $user_grop_prev=array('super_admin','admin');
		    $ugrp=$this->session->userdata('user_group');
			
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$data['allaccno']=$this->transactionmodel->get_all_accounts();
				//print_r($data['allaccno']);
				$this->load->view('transaction/add',$data);
				
				
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access edit operation.please contact system admin for more.....
						       </div>';
				
				//$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    redirect('/auth/login/');
			}
		}else{
			redirect('/auth/login/');
		}
	}
	public function transaction_submit(){
		$user_grop_prev=array('super_admin','admin');
		 $ugrp=$this->session->userdata('user_group');
			
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				//gett info from transaction insert page
				$accno=$this->input->post("accno");
				$accid=$this->input->post("custid");
				$depositby=$this->input->post("depositby");
				$collectby=$this->input->post("collectby");
				$total_row=$this->input->post("total_row");
				$deposit=0;
				$loanamnt=0;
				$msg="";
				for($i=1;$i<=$total_row;$i++){
					$dat=$this->input->post("date_$i");
					$formonth=explode("-",$dat);
					$dep=$this->input->post("deposit_$i");
					$formon=$formonth[1];
					$yrt=$formonth[2];
					if(!empty($dep) && isset($dep)){
						//$dep=0;
						$deposit=$deposit+$dep;
						$data_array_deposit=array(
							"cid"=>$accid,
							"accno"=>$accno,
							"amount"=>$dep,
							"datee"=>$dat,
							"for_the_month"=>intval($formonth[1]),
							"deposit_by"=>$depositby,
							"collected_by"=>$collectby,
							"type"=>"R",
							"approve"=>"No"
						);
						
						$res=$this->transactionmodel->save_deposit_entry($data_array_deposit);
						if($res==true){
							
							$chk_recurring_data_exist=$this->transactionmodel->check_recurring_exist($formon,$yrt,$accno,$accid);
							if(isset($chk_recurring_data_exist) && !empty($chk_recurring_data_exist)){
								$balance=floatval($chk_recurring_data_exist[0]->balance);
								$amot_paid=floatval($chk_recurring_data_exist[0]->amount_paid);
								$newbal=floatval($balance)+floatval($dep);
								$newamount=floatval($amot_paid)+floatval($dep);
								$data_array_recurring_master_update=array(
									"cid"=>$accid,
									"accno"=>$accno,
									"fyear"=>$yrt,
									"last_update"=>$dat,
									"for_the_month"=>$formon,
									"amount_paid"=>$newamount,
									"balance"=>$newbal,
									"deposit_by"=>$depositby,
									"collected_by"=>$collectby,
									"approve"=>"Yes"
								
								);
								$this->transactionmodel->update_recurring_master($data_array_recurring_master_update,$formon,$yrt,$accno,$accid);
								
							}else{
								
								$data_array_recurring_master_insert=array(
									"cid"=>$accid,
									"accno"=>$accno,
									"fyear"=>$yrt,
									"last_update"=>$dat,
									"for_the_month"=>$formon,
									"amount_paid"=>floatval($dep),
									"balance"=>floatval($dep),
									"deposit_by"=>$depositby,
									"collected_by"=>$collectby,
									"approve"=>"Yes"
								
								);
								$this->transactionmodel->save_recurring_master($data_array_recurring_master_insert);
								
								
							}
							
							//$get_all_month=$this->transactionmodel->get_all_insert_month($yrt,$accno,$accid);
							
							
							
							$get_all_month=$this->transactionmodel->get_all_insert_month($yrt,$accno,$accid);
                            if(isset($get_all_month) && !empty($get_all_month)){
                            	//$i=1;
								$finalbal=0;
                            	foreach($get_all_month as $getval){
                            		
                            			$month=$getval->for_the_month;
										$yerat=$getval->fyear;
										$accno=$getval->accno;
										$cid=$getval->cid;
										$amount=floatval($getval->amount_paid);
									    $finalbal=floatval($finalbal)+floatval($getval->amount_paid);
										$data_array_recurring_master_update=array(
											"balance"=>$finalbal
										);
										//if($mnth)
                            		    $this->transactionmodel->update_recurring_master($data_array_recurring_master_update,$month,$yerat,$accno,$cid);
                            		
									
                            	}
                            }
							
							
							
						}
						
						
						
						
						
						
					}

                   //#####################################################################################
                   
                   
                   
                   
                   
                   
                   //########################################################################################


				
					//print_r($data_array_deposit);
					//if(isset($data_array_deposit) &&)
					//echo "<br>";
					$loan=$this->input->post("loan_$i");
					if(!empty($loan) && isset($loan)){
						//$loan=0;
						$loanamnt=$loanamnt+$loan;
						$data_array_loan=array(
							"cid"=>$accid,
							"accno"=>$accno,
							"amount"=>$loan,
							"datee"=>$dat,
							"for_the_month"=>intval($formonth[1]),
							"deposit_by"=>$depositby,
							"collected_by"=>$collectby,
							"type"=>"L",
							"approve"=>"No"
						);
						
						$res_loan=$this->transactionmodel->save_loan_entry($data_array_loan);
						if($res_loan==true){
						
						/*-----------------------------------------------------------*/
						 /* 
						 *	LOAN CALCULATION
						 *
						 * 
						 * 
						 * 
						 ---------------------------------------------------------------*/
						 
						 //check loan exist
						 $accnoloanexist=$this->transactionmodel->getloandetails($accno);
						 $loanamount=$accnoloanexist[0]->loan_amount;
						 $loan_date=$accnoloanexist[0]->loan_date;
						 $interest_rate=$accnoloanexist[0]->interest_rate;
						 $interest_calculate=$accnoloanexist[0]->interest_calculate;
						 
						 //$monthly_installment=$accnoloanexist[0]->monthly_installment;
						 $period=$accnoloanexist[0]->period;
						 
						 //check loan master data exist or not
						 
						 $loan_master_exist=$this->transactionmodel->loan_master_data_check($accno);
						if(isset($loan_master_exist) && !empty($loan_master_exist)){
							
							//get month wise transaction---//
							
							$get_last_month_transaction=$this->transactionmodel->get_loan_master_data($formon,$yrt,$accno,$accid);
							
							
							if(isset($get_last_month_transaction) && !empty($get_last_month_transaction) && ($get_last_month_transaction[0]->status==1)){
								//echo 1;exit;
								
							$get_last_month_transaction_new=$this->transactionmodel->loan_master_data_check_previous($accno);
								//print_r($get_last_month_transaction_new);
							if(isset($get_last_month_transaction_new) && !empty($get_last_month_transaction_new)){
								$get_principal_due=$get_last_month_transaction_new[0]->principal_due;
							}else{
								$get_principal_due=$loanamount;
							}		
							//check no of install ment due
							//$getprenomnth=$this->transactionmodel->getlastpaidinstallmnt();
							
							if($interest_calculate=="Monthly"){
							 	$monthly_installment=(floatval($get_principal_due)*floatval($interest_rate)/100);
							 }else{
							 	$monthly_installment=(floatval($get_principal_due)*floatval($interest_rate)/100)/12 ;
							 }
							 
							 
							 /*
							  * 
							  * get loan calculation
							  */
						  $tot_due=floatval($monthly_installment)+floatval($get_principal_due);
								if($tot_due>=$loan){
  /*---------------------------------------------  Start of loan master transaction------------------------*/
	
								if(floatval($loan)>floatval($monthly_installment) ){
									
									$interest_received=	$get_last_month_transaction[0]->interest_received;
									$total=$get_last_month_transaction[0]->total;
									
									
									
									$principal_paid=(floatval($loan)+floatval($interest_received))-floatval($monthly_installment);
									$principal_due=floatval($get_principal_due)-floatval($principal_paid);
									
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										"principal_received"=>round($principal_paid),
										"principal_due"=>round($principal_due),
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($monthly_installment),
										"interest_due"=>0.00,
										"total"=>round(floatval($loan)+floatval($total)),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->update_loan_master_data_first_time($data_loan_master,$formon,$yrt,$accno,$accid);
									
									
									
									
									
									
								}else if(floatval($loan)==floatval($monthly_installment)){
									$interest_received=	$get_last_month_transaction[0]->interest_received;
									$total=$get_last_month_transaction[0]->total;
									
									
									
									$principal_paid=(floatval($loan)+floatval($interest_received))-floatval($monthly_installment);
									$principal_due=floatval($get_principal_due)-floatval($principal_paid);
									
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										"principal_received"=>round($principal_paid),
										"principal_due"=>round($principal_due),
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($monthly_installment),
										"interest_due"=>0.00,
										"total"=>round(floatval($loan)+floatval($total)),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->update_loan_master_data_first_time($data_loan_master,$formon,$yrt,$accno,$accid);
									
									
									
									
								}else{
									$interest_received=	$get_last_month_transaction[0]->interest_received;
									$total=$get_last_month_transaction[0]->total;
									//$principal_paid=(floatval($loan)+floatval($interest_received))-floatval($monthly_installment);
									//$principal_due=floatval($get_principal_due)-floatval($principal_paid);
									$new_interest_received=floatval($interest_received)+floatval($loan);
									if(floatval($monthly_installment)>floatval($new_interest_received)){
										//echo 1;
										$new_interest_recev=$new_interest_received;
										$total_new=floatval($total)+floatval($loan);
										$new_interest_due=floatval($monthly_installment)-floatval($new_interest_received);
										
										$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										/*"principal_received"=>$principal_paid,
										"principal_due"=>$principal_due,*/
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($new_interest_recev),
										"interest_due"=>round($new_interest_due),
										"total"=>round($total_new),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->update_loan_master_data_first_time($data_loan_master,$formon,$yrt,$accno,$accid);
									
										
									}else{
										//echo 2; 
										//echo "<br>";
										 $new_interest_recev=$new_interest_received;
										//echo "<br>";
										 $total_new=floatval($total)+floatval($loan);
										//echo "<br>";
										 $principal_paid=(floatval($loan)+floatval($interest_received))-floatval($monthly_installment);
										//echo "<br>";
										 $principal_due=floatval($get_principal_due)-floatval($principal_paid);
										
										$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										"principal_received"=>round($principal_paid),
										"principal_due"=>round($principal_due),
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($monthly_installment),
										"interest_due"=>0.00,
										"total"=>round($total_new),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->update_loan_master_data_first_time($data_loan_master,$formon,$yrt,$accno,$accid);
									
										
										
										
										
									}
									
									
									
									
									
								}
/*--------------------------------------------------------------------------------------------
 * if any one give greater than principal due amount than it will be tranfer to reccuring account
 -----------------------------------------------------------------------------------------------*/
								}else{
													
									$tranftorec=floatval($loan)-floatval($tot_due);	
									$principal_paid=		
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										"principal_received"=>round($get_principal_due),
										"principal_due"=>0,
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($monthly_installment),
										"interest_due"=>0.00,
										"total"=>round($tot_due),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);			
												
									$this->transactionmodel->save_loan_master_data_first_time($data_loan_master);
									$data_tranfer_recr=array("tranfer_from_loan_acc"=>$tranftorec);		
									$this->transactionmodel->update_tranfer_to_recurring($data_tranfer_recr,$accno);
											
										
										
									
									
								}
								
							}else{
								//echo 2;exit;
								$get_last_month_transaction=$this->transactionmodel->loan_master_data_check($accno);
								$interest_due=floatval($get_last_month_transaction[0]->	interest_due);
								$get_principal_due=$get_last_month_transaction[0]->principal_due;
								
								//get difference between two dates
								$date1 = $get_last_month_transaction[0]->last_update;
								$date2 = $dat;
								
								$ts1 = strtotime($date1);
								$ts2 = strtotime($date2);
								
								$year1 = date('Y', $ts1);
								$year2 = date('Y', $ts2);
								
								$month1 = date('m', $ts1);
								$month2 = date('m', $ts2);
								
								$diff = (($year2 - $year1) * 12) + ($month2 - $month1);
																
								if($diff>0){
									$diff=$diff;
								}else{
									$diff=1;
								}
								
								
							if($interest_calculate=="Monthly"){
							 	$monthly_installment=((floatval($get_principal_due)*floatval($interest_rate)/100)+floatval($interest_due))* $diff;
							 }else{
							 	$monthly_installment=((floatval($get_principal_due)*floatval($interest_rate)/100)/12 +floatval($interest_due))*$diff ;
							 }
								//echo $diff;exit;
								
								
								
  /*---------------------------------------------  Start of loan master transaction------------------------*/
                                $tot_due=floatval($monthly_installment)+floatval($get_principal_due);
									if($tot_due>=$loan){  
								if(floatval($loan)>floatval($monthly_installment) ){
									
									//$interest_received=$get_last_month_transaction[0]->interest_received;
									//$total=$get_last_month_transaction[0]->total;
									
									
									
									$principal_paid=floatval($loan)-floatval($monthly_installment);
									$principal_due=floatval($get_principal_due)-floatval($principal_paid);
									
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										"principal_received"=>round($principal_paid),
										"principal_due"=>round($principal_due),
										"monthly_interest"=>round($monthly_installment/$diff),
										"interest_received"=>round($monthly_installment),
										"interest_due"=>0.00,
										"total"=>round(floatval($loan)),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->save_loan_master_data_first_time($data_loan_master);
									
									
									
									
									
									
								}else if(floatval($loan)==floatval($monthly_installment)){
									//$interest_received=	$get_last_month_transaction[0]->interest_received;
									//$total=$get_last_month_transaction[0]->total;
									
									
									
									//$principal_paid=(floatval($loan)+floatval($interest_received))-floatval($monthly_installment);
									//$principal_due=floatval($get_principal_due)-floatval($principal_paid);
									
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										//"principal_received"=>$principal_paid,
										"principal_due"=>round($get_principal_due),
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($monthly_installment),
										"interest_due"=>0.00,
										"total"=>round($monthly_installment),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->save_loan_master_data_first_time($data_loan_master);
									
									
									
									
								}else{
									$interest_due=floatval($monthly_installment)-floatval($loan);
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										/*"principal_received"=>$principal_paid,*/
										"principal_due"=>round($get_principal_due),
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($loan),
										"interest_due"=>round($interest_due),
										"total"=>round($loan),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->save_loan_master_data_first_time($data_loan_master);
									
									
								}
								}else{
									
									$tranftorec=floatval($loan)-floatval($tot_due);	
									$principal_paid=		
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										"principal_received"=>round($get_principal_due),
										"principal_due"=>0,
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($monthly_installment),
										"interest_due"=>0.00,
										"total"=>round($tot_due),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);			
												
									$this->transactionmodel->save_loan_master_data_first_time($data_loan_master);
									$data_tranfer_recr=array("tranfer_from_loan_acc"=>$tranftorec);		
									$this->transactionmodel->update_tranfer_to_recurring($data_tranfer_recr,$accno);
										
									
									
									
									
								}
								
							
								
							}	
	/*---------------------------------------------  End of loan master transaction------------------------*/
								
						}else{
							//echo 3; exit;
							if($interest_calculate=="Monthly"){
							 	$monthly_installment=(floatval($loanamount)*floatval($interest_rate)/100);
							 }else{
							 	$monthly_installment=(floatval($loanamount)*floatval($interest_rate)/100)/12 ;
							 }
							 
							 $totalloan_paid=$loan;
  /*---------------------------------------------  Start of loan master transaction if loan master table data not exist in a particular accno------------------------*/
	
								if(floatval($loan)>floatval($monthly_installment) ){
									$principal_paid=floatval($loan)-floatval($monthly_installment);
									$principal_due=floatval($loanamount)-floatval($principal_paid);
									
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										"principal_received"=>round($principal_paid),
										"principal_due"=>round($principal_due),
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($monthly_installment),
										/*"interest_due"=>,*/
										"total"=>round($loan),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->save_loan_master_data_first_time($data_loan_master);
									
								}else if(floatval($loan)==floatval($monthly_installment)){
									
									
									
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										/*"principal_received"=>$principal_paid,*/
										"principal_due"=>round($loanamount),
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($loan),
										/*"interest_due"=>,*/
										"total"=>round($loan),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->save_loan_master_data_first_time($data_loan_master);
									
									
									
									
								}else{
											
										
									$interest_due=floatval($monthly_installment)-floatval($loan);
									$data_loan_master=array(
										"cid"=>$accid,
										"accno"=>$accno,
										"fyear"=>$yrt,
										"last_update"=>$dat,
										"for_the_month"=>$formon,
										"principal"=>round($loanamount),
										/*"principal_received"=>$principal_paid,*/
										"principal_due"=>round($loanamount),
										"monthly_interest"=>round($monthly_installment),
										"interest_received"=>round($loan),
										"interest_due"=>round($interest_due),
										"total"=>round($loan),
										"deposit_by"=>$depositby,
										"collected_by"=>$collectby,
										"status"=>1,
										"approve"=>"Yes"
										
									);
									
									$this->transactionmodel->save_loan_master_data_first_time($data_loan_master);
									
									
								}
								
								
	/*---------------------------------------------  End of loan master transaction if loan master table data not exist in a particular accno------------------------*/
							 
							 
							
						}
												
						
						
						
						
						
						}
						
					}
					
					
					
					
					
					//print_r($data_array_loan);
					//$total=floatval($dep)+floatval($loan);
					
				}
				
				if($deposit>0){
					$msg .='<b>Total Deposit Paid -'.$deposit ."</b> ";
				}
				if($loanamnt>0){
					$msg .='<b> Total Loan Paid- '.$loanamnt. "</b> ";
				}
				
				$message='<div class="alert alert-success alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 Your submission are '.$msg.' . pending for admin  approval ........
						       </div>';
				$this->session->set_flashdata('message',$message);
		        redirect('transaction/Transaction/add_new_transaction','refresh');
				//$this->load->view('transaction/add',$data);
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access these operation.please contact system admin for more.....
						       </div>';
				
				//$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    redirect('/auth/login/');
			}
		}else{
			redirect('/auth/login/');
		}
	}
	public function getloananddepositnodue(){
		//echo "helloworld";
		$accno=$this->input->post('accno');	
		$recurringinfo=$this->transactionmodel->getopeningdate($accno);
		
		if(isset($recurringinfo) && !empty($recurringinfo)){
		$period=$recurringinfo[0]->period;
		//echo $period;
		//get no of recurring data inserted month wise;
		$get_paid_no_of_recurring=$this->transactionmodel->get_paid_no_of_recurring($accno);
		$totaldue=intval($period)-intval($get_paid_no_of_recurring);
		if($totaldue>0){
		$msg= '
			
                Accno-'.$accno.' Total no of installment-<b>'.$period.'</b>.No of Paid installment-<b>'.$get_paid_no_of_recurring.'</b>. 
                No of Due installment-<b>'.$totaldue.'</b>
             
		';
		}else{
			$msg= '
			
                Accno-'.$accno.' had completed all recurring installment. 
                please check details in settelement page<a href="#"> Click here </a>
             
		
		';
		}
		//}else{
			
		//}
		$res=array("msg"=>$msg,"totaldue"=>$totaldue);
		}
		else{
			$msg='
				 Accno-'.$accno.' has been closed . 
               please check details in settelement page<a href="#"> Click here </a>
             
			';
			$res=array("msg"=>$msg,"totaldue"=>"");
			
			//$res=array("msg"=>$msg,"totaldue"=>"");
		}
		echo json_encode($res);
		
		//echo $get_paid_no_of_recurring;
		
	}
	public function getdepositloandateinfo(){
		$accno=$this->input->post('accno');
		$dt=$this->input->post('dt');
		
		$getaccinfo=$this->transactionmodel->get_accinfo_recurring($accno);
		 $opdate=strtotime($getaccinfo[0]->opening_date);
		//echo "<br>";
		$opdat2=date("d-m-Y", strtotime($getaccinfo[0]->opening_date));
		 $matudate=strtotime($getaccinfo[0]->maturity_date);
		//echo "<br>";
		$matudate2=$getaccinfo[0]->maturity_date;
		 $selctdate=strtotime($dt);
		//echo "<br>";
		if(($opdate<=$selctdate) && ($selctdate<=$matudate)){
			
			$dt_explode=explode("-",$dt);
				$mnth=$dt_explode[1];
				$year=$dt_explode[2];
				if($mnth==12){
					$prevmonth=1;
					$year=intval($mnth)+1;
					
					
				}else{
					$prevmonth=intval($mnth)+1;
					$year=$year;
				}
				$getrecurringdate=$this->transactionmodel->get_last_recurring_date_info($accno,$year,$prevmonth);
				if(isset($getrecurringdate) && !empty($getrecurringdate)){
					$res=array("returnstate"=>"1","opening_date"=>"$opdat2","maturity_date"=>"$matudate2");
					
				}else{
					$get_minyear=$this->transactionmodel->get_min_recurring_year($accno);
					$yer=$get_minyear[0]->year;
					if($yer>$year){
						$res=array("returnstate"=>"1","opening_date"=>"$opdat2","maturity_date"=>"$matudate2");
					}else{
						$res=array("returnstate"=>"0");
					}
					
					
				}
			
			
			
		}else{
			
			$res=array("returnstate"=>"1","opening_date"=>"$opdat2","maturity_date"=>"$matudate2");
			
		}
		
		
		
		echo json_encode($res);
		//echo 
		//print_r($getrecurringdate);
	}
	public function get_loan_date_info(){
		
		$accno=$this->input->post('accno');
		$dt=$this->input->post('dt');
		
		$getloanaccinfo=$this->transactionmodel->get_accinfo_loan($accno);
		$opdate=strtotime($getloanaccinfo[0]->loan_date);
		$opdat2=date("d-m-Y", strtotime($getloanaccinfo[0]->loan_date));
		$matudate=strtotime($getloanaccinfo[0]->loan_adjust_date);
		$matudate2=$getloanaccinfo[0]->loan_adjust_date;
		$selctdate=strtotime($dt);
		
		if(($opdate<=$selctdate)){
			
					$dt_explode=explode("-",$dt);
					$mnth=$dt_explode[1];
					$year=$dt_explode[2];
					if($mnth==12){
						$prevmonth=1;
						$year=intval($mnth)+1;
						
						
					}else{
						$prevmonth=intval($mnth)+1;
						$year=$year;
					}
				
				$getloandate=$this->transactionmodel->get_last_loan_date_info($accno,$year,$prevmonth);
				if(isset($getloandate) && !empty($getloandate)){
					$res=array("returnstate"=>"1","opening_date"=>"$opdat2","maturity_date"=>"$matudate2");
					
				}else{
				$get_minyear=$this->transactionmodel->get_min_loan_year($accno);
					$yer=$get_minyear[0]->year;
					if($yer>$year){
						$res=array("returnstate"=>"2","opening_date"=>"$opdat2","maturity_date"=>"$matudate2");
					}else{
						$res=array("returnstate"=>"0");
					}
					
				}
			
		}else{
			
			$res=array("returnstate"=>"3","opening_date"=>"$opdat2","maturity_date"=>"$matudate2");
			
		}
		
		echo json_encode($res);
		
		
		
		
	}
	
	
}