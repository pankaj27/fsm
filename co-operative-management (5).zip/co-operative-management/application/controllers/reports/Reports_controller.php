<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Reports_controller extends CI_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->helper(array('form', 'url','security','masteraccounts'));
		$this->load->library('form_validation');
		//$this->load->library('security');
		$this->load->library('tank_auth');
		$this->lang->load('tank_auth');
		$this->load->model(array('reports_model','transactionmodel'));
		
	}
	
	public function get_total_month_wise_deposit(){
		
		 $user_grop_prev=array('super_admin','admin');
		    $ugrp=$this->session->userdata('user_group');
			
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$data['allaccno']=$this->transactionmodel->get_all_accounts();
				//print_r($data['allaccno']);
				$this->load->view('reports/total_month_wise_deposit',$data);
				
				
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access edit operation.please contact system admin for more.....
						       </div>';
				
				//$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    redirect('/auth/login/');
			}
		}else{
			redirect('/auth/login/');
		}
		
		
	}
	public function get_results(){
		
		
	}
}