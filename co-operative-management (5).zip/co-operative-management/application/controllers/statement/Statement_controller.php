<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Statement_controller extends CI_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->helper(array('form', 'url','security','masteraccounts'));
		$this->load->library('form_validation');
		//$this->load->library('security');
		$this->load->library('tank_auth');
		$this->lang->load('tank_auth');
		$this->load->model('statement_model');
		$this->load->model('newaccountsmodel');
		
	}
	public function index(){
		 $user_grop_prev=array('super_admin','admin');
		    $ugrp=$this->session->userdata('user_group');
			
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$this->load->view('statement/list');
				//echo "hello";
				
			}
		}else{
			
			redirect('/auth/login/');
		}
	}
	public function get_acc_details(){
		$accno=$this->input->post("accno");
		$getaccinfo=$this->newaccountsmodel->getaaccnoinfo_statement($accno);
	
		$res=array();
		if(isset($getaccinfo) && !empty($getaccinfo)){
			
			$id=$getaccinfo[0]->id;
			$first_name=$getaccinfo[0]->first_name;
			$middle_name=$getaccinfo[0]->middle_name;
			$last_name=$getaccinfo[0]->last_name;
			$opening_balance=$getaccinfo[0]->opening_balance;
			$opening_date=$getaccinfo[0]->opening_date;
			$interest_rate=floatval($getaccinfo[0]->interest_rate);
			$monthly_installment=$getaccinfo[0]->monthly_installment;
			//calculate  recurring details
			  //$getrecurringinfo=$this->
			  $get_recurring_transaction_info=$this->statement_model->get_recurring_transaction_info($accno);
			  $totalbl=0;
			 $bal=0;
			 foreach($get_recurring_transaction_info as $trval){
				  $bal=$bal+$trval->amount_paid;
				  $totalbl=$totalbl+$bal;
			 }
			//echo $totalbl;
			 $deposit=floatval($getaccinfo[0]->amount_paid);
			 //$deposit="";
			 $balance=floatval($getaccinfo[0]->balance);
			 $inst=(floatval($totalbl)*$interest_rate/100)/12;
			 
			 
			//$accno=$getaccinfo[0]->id;
			$res=array("deposit"=>number_format((float)$deposit, 2, '.', ''),"interest"=>number_format((float)$inst, 2, '.', ''),"id"=>"$id","accno"=>"$accno","first_name"=>"$first_name","middle_name"=>"$middle_name","last_name"=>"$last_name","opening_balance"=>"$opening_balance","opening_date"=>"$opening_date","monthly_installment"=>number_format((float)$monthly_installment, 2, '.', ''));
			echo json_encode($res);
		}else{
			 echo json_encode($res);
		}
		}
	public function get_recurring_info(){
		
		$accno=$this->input->post("accno");
		$get_recurring_transaction_info=$this->statement_model->get_recurring_transaction_info($accno);
		$html="";
		if(isset($get_recurring_transaction_info) && !empty($get_recurring_transaction_info)){
			$html .='
			        <b>Recurring Details:</b>
					<table id="example1" class="table table-bordered table-striped" >
		                <thead>
		                <tr>
		                  <th style="width: 100px;">Date</th>
		                  <th style="width: 300px;">Particulars</th>
		                  <th style="width: 100px;text-align: right;">Withdrawn</th>
		                  <th style="width: 100px;text-align: right">Deposit</th>
		                  <th style="width: 100px;text-align: right">Balance</th>
		                  
		                </tr>
		                </thead>
		                <tbody>
		                
			
					';
			
			$bal=0;
			$im=1;
			foreach($get_recurring_transaction_info as $trval){
				  $bal=$bal+$trval->amount_paid;
				  $mnth=$trval->for_the_month;
				  $mnthname=date('F', mktime(0, 0, 0, $mnth, 3));
				  $html .="<tr>";
				  $html .="<td><a href='#' data-toggle='modal' data-target='#modal-loan_".$im."' >$mnthname-".$trval->fyear."</a>";
				  $html .='<div class="modal fade" id="modal-loan_$im">
						          <div class="modal-dialog">
						            <div class="modal-content">
						              <div class="modal-header">
						                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						                  <span aria-hidden="true">&times;</span></button>
						                <h4 class="modal-title">Details Deposit of Accno- '.$trval->accno.' for the month '.$mnthname.'-'.$trval->fyear.'</h4>
						              </div>
						              <div class="modal-body">
						              
						                <div class="row">
									        <div class="col-md-12">
									          <div class="box">
									            <div class="box-header with-border">
									              <h3 class="box-title"> Details Deposit Info </h3>
									            </div>
									            <!-- /.box-header -->
									            <div class="box-body">
									              <table class="table table-bordered">
									                
									               
									              </table>
									            </div>
									            <!-- /.box-body -->
									            
									          </div>
									          <!-- /.box -->
									
									          
									          <!-- /.box -->
									        </div>
									        <!-- /.col -->
									        
									        <!-- /.col -->
									      </div>
						              </div>
						              <div class="modal-footer">
						                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
						                <button type="button" class="btn btn-primary">Save changes</button>
						              </div>
						            </div>
						            <!-- /.modal-content -->
						          </div>
						          <!-- /.modal-dialog -->
						        </div>';
				  
				  
				  
				  
				  
				  $html .="</td><td>By Cash</td>";
				  $html .="<td style='width: 100px;text-align: right;'></td>";
				  $html .="<td style='width: 100px;text-align: right;'>".$trval->amount_paid."</td>";
				  $html .="<td style='width: 100px;text-align: right;'>".number_format((float)$bal, 2, '.', '')."</td>";
				  $html .="</tr>";
				  $im++;
				  
			}
             $html .='
             		</tbody>
		                <tfoot>
		                <tr>
		                  <th style="width: 100px;">Date</th>
		                  <th style="width: 300px;">Particulars</th>
		                  <th style="width: 100px;text-align: right;">Withdrawn</th>
		                  <th style="width: 100px;text-align: right">Deposit</th>
		                  <th style="width: 100px;text-align: right">Balance</th>
		                  
		                </tr>
		                </tfoot>
		              </table>
             		
             		';
			echo $html;
			
		}else{
			 $html .="<tr>";
			 $html .="</tr>";
			 echo $html;
		}
	}
	public function get_loan_info(){
		$accno=$this->input->post("accno");
		$get_loan_transaction_info=$this->statement_model->get_loan_transaction_info($accno);
		$html="";
		if(isset($get_loan_transaction_info) && !empty($get_loan_transaction_info)){
			$html .='
						<table id="example11" class="table table-bordered table-striped" >
		                <thead>
		                <tr>
		                  <th>Date</th>
		                  <th>Loan</th>
		                  <th>Received</th>
		                  <th>Due</th>
		                  <th>Interest</th>
		                  <th>Received</th>
		                  <th>Due</th>
		                  <th>Total</th>
		                  
		                </tr>
		                </thead>
		                <tbody>
			
			
			
			
			';
			$lk=1;
			$lkk=1;
			$loan_prev=0;
			foreach($get_loan_transaction_info as $trval){
				$mnth=$trval->for_the_month;
				 $mnthname=date('F', mktime(0, 0, 0, $mnth, 3));
				 $loan= $trval->principal;
				 $principal_received=$trval->principal_received;
				 $principal_due=$trval->principal_due;
				 $principaladd=$trval->principal_add;
				 $monthly_interest=$trval->monthly_interest;
				 $interest_received=$trval->interest_received;
				 $interest_due=$trval->interest_due;
				 $total=$trval->total;
				
				$html .= "<tr style='text-align:right;'>
								<td style='text-align:left;'>$mnthname-".$trval->fyear ."</td>";
			   if($lk==1){ 
								$html .="<td>".$loan."</td>";
				   
			   }else{
			   	    if($principaladd>0){
			   	    	//$loanne=floatval($loan_prev)-floatval($loan);
			   	    	$html .="<td>$principaladd</td>";
			   	    	//$lkk++;
			   	    }else{
			   	    	$html .="<td></td>";
						//$lkk=1;
			   	    }
				  
				
			   	         
			   }
			   if(floatval($principal_received)>0){
			   	  $html .="<td>$principal_received</td>";
			   }else{
			   	$html .="<td></td>";
			   }
			   if(floatval($principal_due)>0){
			   	  $html .="<td>$principal_due</td>";
			   }else{
			   	$html .="<td></td>";
			   }
			   if(floatval($monthly_interest)>0){
			   	  $html .="<td>$monthly_interest</td>";
			   }else{
			   	$html .="<td></td>";
			   }
			   if(floatval($interest_received)>0){
			   	  $html .="<td>$interest_received</td>";
			   }else{
			   	$html .="<td></td>";
			   }
			   if(floatval($interest_due)>0){
			   	  $html .="<td>$interest_due</td>";
			   }else{
			   	$html .="<td></td>";
			   }
			   if(floatval($total)>0){
			   	  $html .="<td>$total</td>";
			   }else{
			   	$html .="<td></td>";
			   }
			   
						
				           $html .="</tr>
				
				";
				
				$lk++;
				$loan_prev=$loan;
			}
			
			$html .='
             		</tbody>
		                <tfoot>
		                <tr>
		                 <th>Date</th>
		                  <th>Loan</th>
		                  <th>Received</th>
		                  <th>Due</th>
		                  <th>Interest</th>
		                  <th>Received</th>
		                  <th>Due</th>
		                  <th>Total</th>
		                  
		                </tr>
		                </tfoot>
		              </table>
             		
             		';
			
			echo $html;
			
			
		}else{
			$html .="<tr><td colspan='8'>No data available</td>";
			 $html .="</tr>";
			 echo $html;
			 
			 
		}
		
	}
}