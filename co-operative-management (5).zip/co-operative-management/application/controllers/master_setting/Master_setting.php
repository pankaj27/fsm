<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Master_setting extends CI_Controller
{
	function __construct()
	{
		parent::__construct();

		$this->load->helper(array('form', 'url','security','masteraccounts'));
		$this->load->library('form_validation');
		//$this->load->library('security');
		$this->load->library('tank_auth');
		$this->lang->load('tank_auth');
		$this->load->model(array('master_settings_model','newaccountsmodel'));
		
	}
	public function index(){
		$user_grop_prev=array('super_admin','admin');
		$ugrp=$this->session->userdata('user_group');
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$data['accounts_details']=$this->master_settings_model->get_all_accounts_details();
				$this->load->view('master_settings/add_edit_view_account_master',$data);
				
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access delete operation.please contact system admin for more.....
						       </div>';
				
				$data['viewaccounts']=$this->newaccountsmodel->getallaccounts();
			    $this->load->view('newaccounts/list', $data);
			}
		}else{
			redirect('/auth/login/');
		}
				
		
	}
	public function acc_master_activate($id){
		$user_grop_prev=array('super_admin','admin');
		$ugrp=$this->session->userdata('user_group');
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$stats_array=array(
					"status"=>1
				);
				$this->master_settings_model->update_acc_master_status($stats_array,$id);
				$data['listmsg']='<div class="alert alert-success alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 Update done made successfully..
						       </div>';
				
				$data['accounts_details']=$this->master_settings_model->get_all_accounts_details();
				$this->load->view('master_settings/add_edit_view_account_master',$data);
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access delete operation.please contact system admin for more.....
						       </div>';
				
				$data['accounts_details']=$this->master_settings_model->get_all_accounts_details();
				$this->load->view('master_settings/add_edit_view_account_master',$data);
			}
		}else{
				redirect('/auth/login/');
		}
		
	}
	public function acc_master_inactivate($id){
		$user_grop_prev=array('super_admin','admin');
		$ugrp=$this->session->userdata('user_group');
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$stats_array=array(
					"status"=>0
				);
				$this->master_settings_model->update_acc_master_status($stats_array,$id);
				$data['listmsg']='<div class="alert alert-success alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 Update done made successfully..
						       </div>';
				
				$data['accounts_details']=$this->master_settings_model->get_all_accounts_details();
				$this->load->view('master_settings/add_edit_view_account_master',$data);
				
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access delete operation.please contact system admin for more.....
						       </div>';
				
				$data['accounts_details']=$this->master_settings_model->get_all_accounts_details();
				$this->load->view('master_settings/add_edit_view_account_master',$data);
			}
		}else{
				redirect('/auth/login/');
		}
		
	}
	public function save_acc_master(){
		$user_grop_prev=array('super_admin','admin');
		$ugrp=$this->session->userdata('user_group');
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				
				$accname=$this->input->post('accname');
				$code=$this->input->post('code');
				$status=$this->input->post('status');
				$save_data_array=array(
					"accname"=>strtoupper($accname),
					"code"=>strtoupper($code),
					"crtdby"=>$this->session->userdata('user_id'),
					"status"=>$status
				);
				$this->master_settings_model->save_acc_master($save_data_array);
				redirect('master_setting/Master_setting');
				
		
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access delete operation.please contact system admin for more.....
						       </div>';
				
				$data['accounts_details']=$this->master_settings_model->get_all_accounts_details();
				$this->load->view('master_settings/add_edit_view_account_master',$data);
			}
		}else{
			redirect('/auth/login/');
		}
	}
	public function update_acc_master(){
		$user_grop_prev=array('super_admin','admin');
		$ugrp=$this->session->userdata('user_group');
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				$accid=$this->input->post('accid');
				$accname=$this->input->post('accname');
				$code=$this->input->post('code');
				$status=$this->input->post('status');
				$update_data_array=array(
					"accname"=>strtoupper($accname),
					"code"=>strtoupper($code),
					"updateby"=>$this->session->userdata('user_id'),
					"status"=>$status
				);
				$this->master_settings_model->update_acc_master($update_data_array,$accid);
				redirect('master_setting/Master_setting');
				
		
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access delete operation.please contact system admin for more.....
						       </div>';
				
				$data['accounts_details']=$this->master_settings_model->get_all_accounts_details();
				$this->load->view('master_settings/add_edit_view_account_master',$data);
			}
		}else{
			redirect('/auth/login/');
		}
	}
	public function delete_acc_master($id){
		$user_grop_prev=array('super_admin','admin');
		$ugrp=$this->session->userdata('user_group');
		if ($this->tank_auth->is_logged_in()) {
			if(in_array($ugrp, $user_grop_prev)){
				$this->master_settings_model->delete_acc_master($id);
				redirect('master_setting/Master_setting');
				
		
			}else{
				$data['listmsg']='<div class="alert alert-danger alert-dismissible">
						                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						                 You are not allowed to access delete operation.please contact system admin for more.....
						       </div>';
				
				$data['accounts_details']=$this->master_settings_model->get_all_accounts_details();
				$this->load->view('master_settings/add_edit_view_account_master',$data);
			}
		}else{
			redirect('/auth/login/');
		}
		
	}
}
