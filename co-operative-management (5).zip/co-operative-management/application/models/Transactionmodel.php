<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Transactionmodel extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function get_all_accounts(){
		return $this->db->query("select * from customer_master where status='1'")->result();
	}
	public function save_deposit_entry($data_array_deposit){
		$res=$this->db->insert('transaction',$data_array_deposit);
		if($res==true){
			return true;
		}else{
			return false;
		}
		
	}
	public function save_loan_entry($data_array_loan){
		$res=$this->db->insert('transaction',$data_array_loan);
		if($res==true){
			return true;
		}else{
			return false;
		}
	}
	public function check_recurring_exist($formon,$yrt,$accno,$accid){
		$sql="select * from recurring_master where accno='".trim($accno)."' and cid='".trim($accid)."' and fyear='".trim($yrt)."' and for_the_month='".trim($formon)."'";
		return $this->db->query($sql)->result();
		
	}
	public function save_recurring_master($data_array_recurring_master_insert){
		$this->db->insert('recurring_master',$data_array_recurring_master_insert);
	}
	public function update_recurring_master($data_array_recurring_master_update,$formon,$yrt,$accno,$accid){
		$where=array(
			"accno"=>$accno,
			"cid"=>$accid,
			"fyear"=>$yrt,
			"for_the_month"=>$formon
		);
		$this->db->where($where);
		$this->db->update('recurring_master',$data_array_recurring_master_update);
	}
	public function get_all_insert_month($yrt,$accno,$accid){
		$sql="select * from recurring_master where accno='".trim($accno)."' and cid='".trim($accid)."' and fyear='".trim($yrt)."' order by for_the_month asc";
		return $this->db->query($sql)->result();
	}
	public function getopeningdate($accno){
		$sql="select * from customer_recurring_master where accno='".trim($accno)."' and status='1'";
		return $this->db->query($sql)->result();
	}
	public function get_paid_no_of_recurring($accno){
		$sql="select * from recurring_master where accno='".trim($accno)."'  order by fyear asc";
		return $this->db->query($sql)->num_rows();
	}
	public function getloandetails($accno){
		$sql="select * from customer_loan_master where accno='".trim($accno)."'";
		return $this->db->query($sql)->result();
	}
	public function loan_master_data_check($accno){
		$sql="select * from loan_master where accno='".trim($accno)."' and (status='1' or status='2') order by loan_id desc limit 1 ";
		return $this->db->query($sql)->result();
	}
	public function loan_master_data_check_previous($accno){
		$sql="select * from loan_master where accno='".trim($accno)."' order by loan_id desc limit 1,1 ";
		return $this->db->query($sql)->result();
	}
		public function get_loan_master_data($formon,$yrt,$accno,$accid){
		$sql="select * from loan_master where accno='".trim($accno)."' and cid='".trim($accid)."' and fyear='".trim($yrt)."' and for_the_month='".trim($formon)."'";
		return $this->db->query($sql)->result();
	}
	public function save_loan_master_data_first_time($data_loan_master){
		$this->db->insert("loan_master",$data_loan_master);
	}
	public function update_loan_master_data_first_time($data_loan_master,$formon,$yrt,$accno,$accid){
		$this->db->where(array(
					"cid"=>$accid,
					"accno"=>$accno,
					"fyear"=>$yrt,
					"for_the_month"=>$formon
		
		));
		
		$this->db->update("loan_master",$data_loan_master);
	}
	/*public function get_loan_master_data_through_accno($accno){
		$sql=""
	}
	 * */
	public function get_last_recurring_date_info($accno,$year,$prevmonth){
		//$sql="select * from transaction where accno='".trim($accno)."' and `datee` >='".$dt."' and type='R' ";
		$sql="select * from recurring_master where accno='".trim($accno)."' and fyear='".trim($year)."' and for_the_month='".trim($prevmonth)."' ";
		return $this->db->query($sql)->result();
	}
	public function get_last_loan_date_info($accno,$year,$prevmonth){
		$sql="select * from loan_master where accno='".trim($accno)."' and fyear='".trim($year)."' and for_the_month='".trim($prevmonth)."' ";
		return $this->db->query($sql)->result();
	}
	public function get_min_recurring_year($accno){
		$sql="select min(fyear) as year from recurring_master where accno='".trim($accno)."' ";
		return $this->db->query($sql)->result();
	}
	public function get_min_loan_year($accno){
		$sql="select min(fyear) as year from loan_master where accno='".trim($accno)."' ";
		return $this->db->query($sql)->result();
	}
	public function get_accinfo_recurring($accno){
		$sql="select * from customer_recurring_master where accno='".trim($accno)."'";
		return $this->db->query($sql)->result();
	}
	public function get_accinfo_loan($accno){
		$sql="select * from customer_loan_master where accno='".trim($accno)."'";
		return $this->db->query($sql)->result();
	}
	public function update_tranfer_to_recurring($data_tranfer_recr,$accno){
		//$sql="update customer_recurring_master set "
		$this->db->where('accno',$accno);
		$this->db->update('customer_recurring_master',$data_tranfer_recr);
	}
	 
}