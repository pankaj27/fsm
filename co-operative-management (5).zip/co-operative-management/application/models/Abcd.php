<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Abcd extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function getabcd_test()
	{
		date_default_timezone_set('Asia/Kolkata');
		$today=date('d-m-Y');
		/*return $this->db->select('*')
		                ->from('subscription')
						->where('startdate <', md5($today))
						->where('enddate <', md5($today))
						->get()
						->result();
			*/
			$query=$this->db->query("select * from subscription where STR_TO_DATE(yourdatefield, '%d-%m-%Y')  ");			
	}
	
	
}