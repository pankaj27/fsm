<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settlement_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function get_all_accounts(){
		$sql="select * from customer_loan_master where status='1'";
		return $this->db->query($sql)->result();
	}
	public function get_total_info($acno){
		$sql="select sum(loan_amount)as loan , sum(period) as period from loan_take where accno='".$acno."'";
		return $this->db->query($sql)->result();
	}
	public function get_other_info($acno){
		$sql="select sum(interest_received)as totinterest , sum(principal_received) as totalpay from loan_master where accno='".$acno."'";
		return $this->db->query($sql)->result();
	}
	public function get_loan_last_pay($acno){
		$sql="select * from loan_master where accno='".$acno."' order by loan_id desc limit 1";
		return $this->db->query($sql)->result();
	}
	public function get_all_ddaccounts(){
		$sql="select * from customer_recurring_master where status='1'";
		return $this->db->query($sql)->result();
	}
	public function get_dd_acc_info($accno){
		$sql="select cm.id,cm.accno,cm.first_name,cm.middle_name,cm.last_name,crm.period,crm.maturity_date,crm.opening_balance,crm.opening_date,crm.monthly_installment,crm.interest_rate,crm.tranfer_from_loan_acc,sum(rm.amount_paid) as amount_paid ,sum(rm.balance) as balance from customer_master cm inner join customer_recurring_master crm on crm.accno=cm.accno inner join recurring_master rm on rm.accno=cm.accno  and cm.accno='".trim($accno)."'";
		//$sql="select cm.id,cm.accno,cm.first_name,cm.middle_name,cm.last_name,crm.opening_balance,crm.opening_date,crm.monthly_installment,crm.interest_rate from customer_master cm inner join customer_recurring_master crm on crm.accno=cm.accno where cm.accno='".trim($accno)."'";
		//echo $sql;
		return $this->db->query($sql)->result();
	}
	public function checkdata_exist($accno){
		$sql="select * from dd_settlement where accno='".$accno."'";
		return $this->db->query($sql)->result();
	}
	public function save_dd_stee($data_arr){
		$this->db->insert('dd_settlement',$data_arr);
	}
}