<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Statement_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function get_recurring_info($accno){
		$sql="select sum(rm.amount_paid),sum(rm.balance) from  recurring_master rm where rm.accno='".trim($accno)."'";
		return $this->db->query($sql)->result();
	}
	public function get_recurring_transaction_info($accno){
		return $this->db->query("select * from recurring_master where accno='".trim($accno)."' order by fyear asc,for_the_month asc ")->result();
	}
	public function get_loan_transaction_info($accno){
		return $this->db->query("select * from loan_master where accno='".trim($accno)."' order by fyear asc,for_the_month asc ")->result();
	
	}
}
