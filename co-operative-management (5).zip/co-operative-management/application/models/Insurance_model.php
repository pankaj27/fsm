<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Insurance_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function get_insurence_take($accno){
		$sql="select * from insurance_master where  insurance_master.accno='".trim($accno)."'";
		return $this->db->query($sql)->result();
	}
	public function update_insurence($idn){
		//$sql="update insurance_master set paid='Y' where id='".trim($idn)."'";
		//$res=$this->db->query($sql)->result();
		//return $res;
		$dst=array("paid"=>"Y");
		$this->db->where('id',$idn);
		$res=$this->db->update('insurance_master',$dst);
		if($res==true){
			return 1;
		}else{
			return 0;
		}
	}
	
}