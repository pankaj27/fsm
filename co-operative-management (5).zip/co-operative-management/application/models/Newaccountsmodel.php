<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Newaccountsmodel extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function checkaccnoexist($accno){
		
		$sql=$this->db->query("select * from customer_master where accno='".trim($accno)."'");
		return $sql->result();
		
	}
	public function save_main_data($data_main){
		
		   $this->db->insert('customer_master', $data_main);
		   $insert_id = $this->db->insert_id();
		
		   return  $insert_id;
	}
	public function save_contact_data($data_contactinfo,$getcustomer_id,$accno){
		
		$sql=$this->db->query("select * from customer_contact_master where accno='".trim($accno)."' and customer_id='".trim($getcustomer_id)."'");
		$res=$sql->result();
		if(empty($res))
		{
			$this->db->insert('customer_contact_master', $data_contactinfo);
			return 1;
		}else{
			return 0;
		}
		
	}
	public function save_recurring_data($data_recurringinfo,$getcustomer_id,$accno){
		
		$sql=$this->db->query("select * from customer_recurring_master where accno='".trim($accno)."' and customer_id='".trim($getcustomer_id)."'");
		$res=$sql->result();
		if(empty($res))
		{
			$this->db->insert('customer_recurring_master', $data_recurringinfo);
			return 1;
		}else{
			return 0;
		}
	}
	public function save_loan_data($data_loaninfo,$getcustomer_id,$accno){
		
		$sql=$this->db->query("select * from customer_loan_master where accno='".trim($accno)."' and customer_id='".trim($getcustomer_id)."'");
		$res=$sql->result();
		if(empty($res))
		{
			$this->db->insert('customer_loan_master', $data_loaninfo);
			return 1;
		}else{
			return 0;
		}
		
	}
	public function save_data_insurance($data_insurance,$getcustomer_id,$accno){
		$sql=$this->db->query("select * from  insurance_master where accno='".trim($accno)."' and customer_id='".trim($getcustomer_id)."'");
		$res=$sql->result();
		if(empty($res))
		{
			$this->db->insert('insurance_master', $data_insurance);
			return 1;
		}else{
			return 0;
		}
	}
	public function getallaccounts(){
		
		$sql="select * from customer_master";
		return $this->db->query($sql)->result();
		
	}
	public function getaccounts_master_info($accid){
		$sql="select * from customer_master where accno='".trim($accid)."'";
		return $this->db->query($sql)->result();
	}
	public function getaccounts_contact_info($accid){
		$sql="select * from customer_contact_master where accno='".trim($accid)."'";
		return $this->db->query($sql)->result();
	}
	public function getaccounts_rdaccount_info($accid){
		$sql="select * from customer_recurring_master where accno='".trim($accid)."'";
		return $this->db->query($sql)->result();
	}
	public function getaccounts_loan_info($accid){
		$sql="select * from  customer_loan_master where accno='".trim($accid)."'";
		return $this->db->query($sql)->result();
	}
	public function get_check_loan_account($accno){
		$sql="select * from customer_loan_master where accno='".trim($accno)."'";
		return $this->db->query($sql)->result();
	}
	public function update_main_data($data_main,$accno){
		$this->db->where('accno',$accno);
		$this->db->update('customer_master',$data_main);
	}
	public function update_contact_data($data_contactinfo,$getcustomer_id,$accno){
		$this->db->where('accno',$accno);
		$this->db->update('customer_contact_master',$data_contactinfo);
	}
	public function update_recurring_data($data_recurringinfo,$getcustomer_id,$accno){
		$this->db->where('accno',$accno);
		$this->db->update('customer_recurring_master',$data_recurringinfo);
	}
	public function update_loan_data($data_loaninfo,$getcustomer_id,$accno){
		$this->db->where('accno',$accno);
		$this->db->update('customer_loan_master',$data_loaninfo);
	}
	public function delete_acc_details($id){
		 $sql="delete customer_master,customer_contact_master,customer_recurring_master
					 from customer_master 
					 inner join customer_contact_master 
					 	on customer_contact_master.accno=customer_master.accno 
					 inner join customer_recurring_master 
					    on customer_recurring_master.accno=customer_master.accno
					 where customer_master.accno='".trim($id)."'";
					 
		//$sql2="delete from "
		$sql2="select * from customer_loan_master where accno='".$id."'";
		$res2=$this->db->query($sql2)->result();
		if(isset($res2) && !empty($res2)){
			$this->db->query("delete from customer_loan_master where accno='".trim($id)."'");
		}
		 $this->db->query($sql);
		 return true;
	}
	public function getaaccnoinfo($accno){
		//$sql="select cm.id,cm.accno,cm.first_name,cm.middle_name,cm.last_name,crm.opening_balance,crm.opening_date,crm.monthly_installment,crm.interest_rate,sum(rm.amount_paid) as amount_paid ,sum(rm.balance) as balance from customer_master cm inner join customer_recurring_master crm on crm.accno=cm.accno inner join recurring_master rm on rm.accno=cm.accno  and cm.accno='".trim($accno)."'";
		$sql="select cm.id,cm.accno,cm.first_name,cm.middle_name,cm.last_name,crm.opening_balance,crm.opening_date,crm.monthly_installment,crm.interest_rate from customer_master cm inner join customer_recurring_master crm on crm.accno=cm.accno where cm.accno='".trim($accno)."'";
		//echo $sql;
		return $this->db->query($sql)->result();
	}
	public function get_insurance_details($accid){
		$sql="select * from insurance_master where accno='".trim($accid)."'";
		return $this->db->query($sql)->result();
	}
	public function update_insurance($data_insurance,$getcustomer_id,$accno){
		$this->db->where(array("accno"=>$accno,"customer_id"=>$getcustomer_id));
		$this->db->update('insurance_master',$data_insurance);
	}
	public function getcustid($accnoupdate){
		$sql="select * from customer_master where accno='".trim($accnoupdate)."'";
		$res=$this->db->query($sql)->result();
		if(isset($res)&&!empty($res)){
			return $res[0]->id;
		}
	}
	public function get_loan_insurence_info($accno){
		$sql="select clm.loan_amount,clm.loan_date,clm.monthly_installment,clm.period,clm.interest_calculate,clm.interest_rate,clm.loan_adjust_date,im.insurance_rate,im.insurance_amount from customer_loan_master clm,insurance_master im where clm.accno=im.accno and clm.accno='".trim($accno)."'";
		return $this->db->query($sql)->result();
	}
	public function get_check_customer_account($accno){
		$sql="select * from customer_master where accno='".trim($accno)."'";
		return $this->db->query($sql)->result();
	}
	public function get_loan_take($accno){
		$sql="select * from loan_take where  loan_take.accno='".trim($accno)."'";
		return $this->db->query($sql)->result();
		
	}
	public function save_multi_loan_data($data_arr_multiloan,$getcustid,$accno){
		
		$this->db->insert('loan_take', $data_arr_multiloan);
	}
	public function save_data_insurance_multi($data_insurance,$getcustomer_id,$accno){
		
			$this->db->insert('insurance_master', $data_insurance);
			
	}
	public function getdepositcoleted($accno){
		$sql="select * from transaction where accno='".trim($accno)."' order by trans_id desc limit 1 ";
		return $this->db->query($sql)->result();
	}
	public function getaaccnoinfo_statement($accno){
		$sql="select cm.id,cm.accno,cm.first_name,cm.middle_name,cm.last_name,crm.opening_balance,crm.opening_date,crm.monthly_installment,crm.interest_rate,sum(rm.amount_paid) as amount_paid ,sum(rm.balance) as balance from customer_master cm inner join customer_recurring_master crm on crm.accno=cm.accno inner join recurring_master rm on rm.accno=cm.accno  and cm.accno='".trim($accno)."'";
		//$sql="select cm.id,cm.accno,cm.first_name,cm.middle_name,cm.last_name,crm.opening_balance,crm.opening_date,crm.monthly_installment,crm.interest_rate from customer_master cm inner join customer_recurring_master crm on crm.accno=cm.accno where cm.accno='".trim($accno)."'";
		//echo $sql;
		return $this->db->query($sql)->result();
	}
	
}