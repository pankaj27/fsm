<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Master_settings_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}
	public function get_all_accounts_details(){
		$sql="select * from account_master ";
		return $this->db->query($sql)->result();
	}
	public function update_acc_master_status($stats_array,$id){
		$this->db->where('id',$id);
		$this->db->update('account_master',$stats_array);
	}
	public function save_acc_master($save_data_array){
		$this->db->insert('account_master',$save_data_array);
	}
	public function update_acc_master($update_data_array,$accid){
		$this->db->where('id',$accid);
		$this->db->update('account_master',$update_data_array);
	}
	public function delete_acc_master($id){
		$sql="delete from account_master where id='".trim($id)."'";
		$this->db->query($sql);
	}
	
}